package it.avea.app;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

/**
 * Carattere VLW: lo stesso identico file di font che usa il firmware dello strumento.
 * I .vlw negli assets sono estratti dagli header Arduino (UiFont32.h, UiFont24.h,
 * ClockFonts.h, VarioNumbers80.h), quindi i glifi, le larghezze e le spaziature
 * sono gli stessi byte, non un'imitazione con un carattere di sistema.
 *
 * Formato (come TFT_eSPI / LovyanGFX), tutti interi a 32 bit big-endian:
 *   intestazione: numero glifi, versione, corpo in px, mboxY, ascent, descent
 *   per ogni glifo: unicode, altezza, larghezza, avanzamento, dY, dX, riservato
 *   poi, nello stesso ordine, i bitmap: altezza x larghezza byte di trasparenza
 */
public class VlwFont {

    private static final class Glyph {
        int w, h, adv, dX, dY, off;
        Bitmap bmp;   // ALPHA_8, creato solo al primo uso
    }

    private final HashMap<Integer, Glyph> glyphs = new HashMap<>();
    private final byte[] data;
    public final int sizePx, ascent, descent;

    private VlwFont(byte[] b) {
        data = b;
        final int n = i32(0);
        sizePx = i32(8);
        ascent = i32(16);
        descent = i32(20);
        int off = 24;
        final int[] codes = new int[n];
        for (int i = 0; i < n; i++) {
            final Glyph g = new Glyph();
            final int u = i32(off);
            g.h = i32(off + 4);
            g.w = i32(off + 8);
            g.adv = i32(off + 12);
            g.dY = i32(off + 16);
            g.dX = i32(off + 20);
            off += 28;
            codes[i] = u;
            glyphs.put(u, g);
        }
        for (int i = 0; i < n; i++) {
            final Glyph g = glyphs.get(codes[i]);
            if (g == null) continue;
            g.off = off;
            off += g.w * g.h;
        }
    }

    private int i32(int p) {
        return ((data[p] & 0xFF) << 24) | ((data[p + 1] & 0xFF) << 16) | ((data[p + 2] & 0xFF) << 8) | (data[p + 3] & 0xFF);
    }

    public static VlwFont fromAsset(AssetManager am, String name) {
        try {
            final InputStream in = am.open("fonts/" + name);
            final ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
            final byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            in.close();
            return new VlwFont(bo.toByteArray());
        } catch (IOException e) {
            return null;
        }
    }

    /** Altezza del corpo, come fontHeight() di LovyanGFX. */
    public int height() { return ascent + descent; }

    /** Larghezza del testo alla scala 1, come textWidth() di LovyanGFX. */
    public float width(String s) {
        float w = 0;
        for (int i = 0; i < s.length(); i++) {
            final Glyph g = glyphs.get((int) s.charAt(i));
            if (g != null) w += g.adv;
        }
        return w;
    }

    private Bitmap bitmapOf(Glyph g) {
        if (g.bmp == null && g.w > 0 && g.h > 0) {
            final Bitmap b = Bitmap.createBitmap(g.w, g.h, Bitmap.Config.ALPHA_8);
            final byte[] row = new byte[g.w * g.h];
            System.arraycopy(data, g.off, row, 0, Math.min(row.length, data.length - g.off));
            final java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(row);
            b.copyPixelsFromBuffer(bb);
            g.bmp = b;
        }
        return g.bmp;
    }

    /**
     * Scrive il testo con la linea di base a baseY e il bordo sinistro a leftX, scalato.
     * Il colore viene dal Paint: il bitmap del glifo e' solo trasparenza, come nel firmware.
     */
    public void draw(Canvas c, String s, float leftX, float baseY, float sx, float sy, Paint p) {
        float x = leftX;
        final Rect src = new Rect();
        final RectF dst = new RectF();
        for (int i = 0; i < s.length(); i++) {
            final Glyph g = glyphs.get((int) s.charAt(i));
            if (g == null) continue;
            final Bitmap b = bitmapOf(g);
            if (b != null) {
                src.set(0, 0, g.w, g.h);
                final float gx = x + g.dX * sx;
                final float gy = baseY - g.dY * sy;
                dst.set(gx, gy, gx + g.w * sx, gy + g.h * sy);
                c.drawBitmap(b, src, dst, p);
            }
            x += g.adv * sx;
        }
    }
}
