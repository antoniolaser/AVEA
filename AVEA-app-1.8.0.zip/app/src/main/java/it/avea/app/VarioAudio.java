package it.avea.app;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/**
 * Toni del variometro, come lo strumento: in salita bip sempre piu' acuti e veloci,
 * in discesa forte un tono basso continuo, oltre -5,1 m/s l'allarme a due toni.
 * Gira in un thread suo e scrive l'audio a blocchi di 20 ms.
 */
public class VarioAudio implements Runnable {
    private static final int RATE = 22050;
    private static final int CHUNK = RATE / 50;          // 20 ms

    private final FlightData d;
    private volatile boolean running = false;
    private Thread thread;
    private AudioTrack track;

    // soglie (m/s)
    public static final float CLIMB = 0.3f;
    public static final float SINK = -2.0f;
    public static final float EMERGENCY = -5.1f;

    private double phase = 0;
    private long cycleStartMs = 0;

    public VarioAudio(FlightData d) { this.d = d; }

    public synchronized void start() {
        if (running) return;
        running = true;
        thread = new Thread(this, "VarioAudio");
        thread.start();
    }

    public synchronized void stop() {
        running = false;
        if (thread != null) {
            try { thread.join(300); } catch (InterruptedException ignored) { }
            thread = null;
        }
    }

    /** Breve bip dei tocchi (solo con AUDIO ON). */
    public volatile int clickFreq = 0;
    public volatile int clickMsLeft = 0;
    public void click(int freq, int ms) {
        if (!d.audioOn) return;
        clickFreq = freq;
        clickMsLeft = ms;
    }

    @Override
    public void run() {
        final int minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        try {
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(Math.max(minBuf, CHUNK * 2 * 3))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            track.play();
        } catch (Exception e) {
            running = false;
            return;
        }
        final short[] buf = new short[CHUNK];
        double amp = 0;
        while (running) {
            final long now = System.currentTimeMillis();
            int freq = 0;
            boolean on = false;
            if (clickMsLeft > 0) {
                freq = clickFreq; on = true;
                clickMsLeft -= 20;
            } else if (d.audioOn && d.baroValid) {
                final float v = d.varioMs;
                if (v < EMERGENCY) {
                    // allarme: 2000 / 1000 Hz alternati ogni 250 ms
                    freq = ((now / 250) % 2 == 0) ? 2000 : 1000;
                    on = true;
                } else if (v > CLIMB && v < 15f) {
                    // bip: periodo 350 ms che si accorcia con la salita, tono che sale
                    final long period = (long) Math.max(50f, 350f - v * 10f) + 100;
                    if (cycleStartMs == 0 || now - cycleStartMs >= period) cycleStartMs = now;
                    on = (now - cycleStartMs) < period / 2;
                    freq = (int) Math.min(2000f, 700f + v * 120f);
                } else if (v < SINK) {
                    freq = (int) Math.max(200f, 420f + v * 20f);   // tono basso continuo
                    on = true;
                    cycleStartMs = 0;
                } else {
                    cycleStartMs = 0;
                }
            }
            // tono sinusoidale con attacco e rilascio morbidi (niente click)
            final double target = on ? 0.55 : 0.0;
            final double step = 2 * Math.PI * (freq > 0 ? freq : 440) / RATE;
            for (int i = 0; i < CHUNK; i++) {
                amp += (target - amp) * 0.01;
                phase += step;
                if (phase > 2 * Math.PI) phase -= 2 * Math.PI;
                buf[i] = (short) (Math.sin(phase) * amp * 32767);
            }
            track.write(buf, 0, CHUNK);   // blocca finche' c'e' spazio: il ritmo lo da' l'audio
        }
        try { track.stop(); } catch (Exception ignored) { }
        track.release();
        track = null;
    }
}
