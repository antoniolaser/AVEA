package it.avea.app;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;

/**
 * Vista pista della pagina FIELDS, portata riga per riga da frDrawRunwayView() del firmware.
 *
 * La camera del firmware e' una vista dall'alto pura (cth = 0, sth = 1, px = py = 0, y0 = 180),
 * quindi la proiezione prospettica si riduce a una rotazione piana piu' una scala:
 *      k  = F / h          pixel per metro
 *      sx = 180 + k * (dx * rtx + dy * rty)
 *      sy = 180 - k * (dx * fwx + dy * fwy)
 * Qui si usa direttamente questa forma: stessi pixel, senza il ritaglio a zc >= 5 m che
 * nel firmware serve solo alla vecchia vista prospettica.
 */
public class RunwayView {

    // colori del firmware
    static final int BG = G.color565(214, 203, 170);      // fondo sabbia
    static final int GRASS = G.color565(192, 180, 146);   // fascia attorno alla pista
    static final int ASPH = G.color565(22, 22, 24);       // asfalto
    static final int BOX_BLUE = G.color565(0, 70, 160);   // bordo dei riquadri
    static final int PLANE = G.color565(175, 0, 120);     // aereo magenta
    static final int N_RED = G.color565(190, 25, 25);     // N della bussola

    private static Bitmap plane;
    public static void load(AssetManager am) {
        if (plane != null) return;
        try {
            final InputStream in = am.open("img/airplane.png");
            plane = BitmapFactory.decodeStream(in);
            in.close();
        } catch (IOException ignored) { }
    }

    // posizioni dei due riquadri, per nascondere i numeri della bussola che ci finiscono sotto
    private static final float[] lblX = new float[2], lblY = new float[2];
    private static int lblN = 0;

    /**
     * @param freqStr frequenza gia' formattata, es. "122.500" (vuota se sconosciuta)
     * @param rwyDeg direzione vera della pista in gradi (airfieldRwyDeg del firmware)
     * @param rwy    numero della prima testata in decine di gradi (1..18), 0 = sconosciuta
     * @param lenM   lunghezza vera della pista in metri (0 = sconosciuta)
     * @param brgAc  rilevamento vero dal campo verso l'aereo, in gradi
     */
    public static void draw(G g, String name, String freqStr, int rwy, float rwyDeg, int lenM,
                            float course, float brgAc, boolean havePos) {
        final float LREAL = lenM > 0 ? lenM : 600f;
        final float LENF = Math.min(LREAL, 1000f);
        final float rw = (float) Math.toRadians(rwyDeg);
        final float ux = (float) Math.sin(rw), uy = (float) Math.cos(rw);
        final float lx = uy, ly = -ux;
        final float hd = (float) Math.toRadians(course);
        final float fwx = (float) Math.sin(hd), fwy = (float) Math.cos(hd);
        final float rtx = (float) Math.cos(hd), rty = (float) -Math.sin(hd);

        // scala fissa: mezza pista sempre 135 px, qualunque rotta, distanza e lunghezza vera
        final float k = 135f / (LENF / 2f);
        final float WID = 48f / k;     // larghezza disegnata: 48 px
        final float LEN = LENF;

        g.fillScreen(BG);

        // quadrilatero nel piano della pista: s lungo la pista, t laterale (metri)
        final float[] qx = new float[4], qy = new float[4];

        g.fillScreen(BG);
        quad(g, qx, qy, ux, uy, lx, ly, rtx, rty, fwx, fwy, k,
                -LEN / 2 - 25, LEN / 2 + 25, -WID / 2 - 25, WID / 2 + 25, GRASS);
        quad(g, qx, qy, ux, uy, lx, ly, rtx, rty, fwx, fwy, k,
                -LEN / 2, LEN / 2, -WID / 2, WID / 2, ASPH);
        quad(g, qx, qy, ux, uy, lx, ly, rtx, rty, fwx, fwy, k,
                -LEN / 2, LEN / 2, -WID / 2 + WID * 0.03f, -WID / 2 + WID * 0.06f, G.WHITE);
        quad(g, qx, qy, ux, uy, lx, ly, rtx, rty, fwx, fwy, k,
                -LEN / 2, LEN / 2, WID / 2 - WID * 0.06f, WID / 2 - WID * 0.03f, G.WHITE);

        // asse tratteggiato
        {
            final float dash = LEN / 30f, step = LEN / 16f;
            final float sEnd = LEN / 2 - LEN * 0.08f;
            final int nD = (int) Math.floor((2 * sEnd - dash) / step) + 1;
            final float s0 = -((nD - 1) * step + dash) / 2f;
            for (int i = 0; i < nD; i++)
                quad(g, qx, qy, ux, uy, lx, ly, rtx, rty, fwx, fwy, k,
                        s0 + i * step, s0 + i * step + dash, -WID * 0.015f, WID * 0.015f, G.WHITE);
        }
        // testate: 3 barre sottili per lato, staccate dai bordi
        for (int e = -1; e <= 1; e += 2) {
            final float s0 = e * (LEN / 2 - LEN * 0.01f), s1 = e * (LEN / 2 - LEN * 0.06f);
            final float bw = WID * 0.026f, st = (WID * 0.40f - bw - WID * 0.16f) / 2f;
            for (int sg = -1; sg <= 1; sg += 2)
                for (int i = 0; i < 3; i++) {
                    final float t = sg * (WID * 0.16f + i * st);
                    quad(g, qx, qy, ux, uy, lx, ly, rtx, rty, fwx, fwy, k,
                            Math.min(s0, s1), Math.max(s0, s1), Math.min(t, t + sg * bw), Math.max(t, t + sg * bw), G.WHITE);
            }
        }

        // inclinazione della pista sullo schermo, sempre verso destra
        float rvx = 1f, rvy = 0f;
        {
            final float[] a0 = proj(-ux * LEN / 2, -uy * LEN / 2, rtx, rty, fwx, fwy, k);
            final float[] a1 = proj(ux * LEN / 2, uy * LEN / 2, rtx, rty, fwx, fwy, k);
            float vx = a1[0] - a0[0], vy = a1[1] - a0[1];
            final float vl = (float) Math.hypot(vx, vy);
            if (vl > 10f) {
                vx /= vl; vy /= vl;
                if (vx < -0.05f || (Math.abs(vx) <= 0.05f && vy > 0)) { vx = -vx; vy = -vy; }
                rvx = vx; rvy = vy;
            }
        }
        final float rwyAng = (float) Math.toDegrees(Math.atan2(rvy, rvx));

        // numeri delle testate: riquadro quadrato parallelo alla pista, numero sempre dritto
        lblN = 0;
        if (rwy > 0) {
            final int nPlus = (rwy + 18 - 1) % 36 + 1, nMinus = rwy;
            final float inM = 38f / k;
            final int BS = 46;
            for (int e = -1; e <= 1; e += 2) {
                final int num = e > 0 ? nPlus : nMinus;
                final float[] s = proj(ux * e * (LEN / 2 - inM), uy * e * (LEN / 2 - inM), rtx, rty, fwx, fwy, k);
                final float bx = Math.round(s[0]), by = Math.round(s[1]);
                g.save();
                g.rotateAbout(bx, by, rwyAng);
                g.fillRoundRect(bx - BS / 2f, by - BS / 2f, BS, BS, 8, G.WHITE);
                g.drawRoundRect(bx - BS / 2f, by - BS / 2f, BS, BS, 8, BOX_BLUE);
                g.drawRoundRect(bx - BS / 2f + 1, by - BS / 2f + 1, BS - 2, BS - 2, 7, BOX_BLUE);
                g.restore();
                // numero il piu' grande che ci sta: 1 px dal riquadro, dentro il bordo da 2 px
                final String t = String.format(java.util.Locale.US, "%02d", num);
                float nsc = 0.8f;
                if (G.UI32 != null) {
                    final float w1 = G.UI32.width(t), h1 = G.UI32.height();
                    final float sw = w1 > 0 ? (BS - 6) / w1 : 0.8f;
                    final float sh = h1 > 0 ? (BS - 6) / (0.75f * h1) : 0.8f;
                    nsc = Math.min(sw, sh);
                }
                g.ui(t, bx, by + 1, G.MC, G.BLACK, nsc);
                if (lblN < 2) { lblX[lblN] = bx; lblY[lblN] = by; lblN++; }
            }
        }

        // nome da una parte della pista e frequenza dall'altra, girati come la pista
        {
            String nm = name == null ? "" : name.toUpperCase(java.util.Locale.US);
            if (nm.length() > 24) nm = nm.substring(0, 24);
            final String fq = freqStr == null ? "" : freqStr;
            final float[] a0 = proj(-ux * LEN / 2, -uy * LEN / 2, rtx, rty, fwx, fwy, k);
            final float[] a1 = proj(ux * LEN / 2, uy * LEN / 2, rtx, rty, fwx, fwy, k);
            final float vl = (float) Math.hypot(a1[0] - a0[0], a1[1] - a0[1]);
            if (vl > 10f) {
                final float sc = 0.66f;                       // nome e frequenza +20 %
                final float avail = Math.min(300f, Math.max(90f, vl));
                // nome troppo lungo per la pista: si accorcia l'ultima parola alla sola iniziale
                for (int guard = 0; guard < 4 && G.UI32 != null && G.UI32.width(nm) * sc > avail; guard++) {
                    final int sp = nm.lastIndexOf(' ');
                    if (sp <= 0 || sp + 1 >= nm.length()) break;
                    final String last = nm.substring(sp + 1);
                    if (last.length() == 2 && last.charAt(1) == '.') {
                        final String head = nm.substring(0, sp);
                        final int sp2 = head.lastIndexOf(' ');
                        if (sp2 <= 0) break;
                        nm = head.substring(0, sp2 + 2) + ".";
                    } else {
                        nm = nm.substring(0, sp + 2) + ".";
                    }
                }
                final float side = WID / 2 * k + 16f;         // px dal centro pista
                final float mx = (a0[0] + a1[0]) / 2f, my = (a0[1] + a1[1]) / 2f;
                for (int i = 0; i < 2; i++) {
                    final String txt = i == 0 ? nm : fq;
                    if (txt.isEmpty()) continue;
                    final int sg = i == 0 ? +1 : -1;
                    final float cx = mx + sg * rvy * side, cy = my - sg * rvx * side;
                    g.save();
                    g.rotateAbout(cx, cy, rwyAng);
                    g.ui(txt, cx, cy, G.MC, G.BLACK, sc);
                    g.restore();
                }
            }
        }

        // aereo magenta col bordino nero, a 2 px dal bordo del display
        float apx = -1000, apy = -1000;
        if (havePos) {
            final float rr = (float) Math.toRadians(brgAc - course);
            apx = 180f + 154f * (float) Math.sin(rr);
            apy = 180f - 154f * (float) Math.cos(rr);
            if (plane != null) {
                g.tintedBitmap(plane, apx, apy, 0f, 0.43f * 1.10f, G.BLACK);   // bordino
                g.tintedBitmap(plane, apx, apy, 0f, 0.43f, PLANE);
            } else {
                g.fillCircle(apx, apy, 14, PLANE);
                g.drawCircle(apx, apy, 14, G.BLACK);
            }
        }

        // bussola intera sul bordo, come GO TO HOME: gira con la rotta
        for (int angle = 0; angle < 360; angle += 10) {
            final float a = (float) Math.toRadians(angle - course - 90);
            final float co = (float) Math.cos(a), si = (float) Math.sin(a);
            final boolean major = angle % 30 == 0;
            final float tkx = 180 + 165f * co, tky = 180 + 165f * si;
            if (Math.hypot(tkx - apx, tky - apy) < 30) continue;            // sotto l'aereo
            final float rIn = major ? 155f : 165f;
            g.drawWideLine(180 + rIn * co, 180 + rIn * si, 180 + 175 * co, 180 + 175 * si, major ? 2f : 1.5f, G.BLACK);
            if (!major) continue;
            final float nx = 180 + Math.round(145f * co), ny = 180 + Math.round(145f * si);
            boolean hidden = false;
            for (int i = 0; i < lblN; i++)
                if (Math.abs(nx - lblX[i]) < 43 && Math.abs(ny - lblY[i]) < 43) hidden = true;
            if (Math.hypot(nx - apx, ny - apy) < 36) hidden = true;
            if (hidden) continue;
            if (angle % 90 == 0) {
                final String s = angle == 0 ? "N" : (angle == 90 ? "E" : (angle == 180 ? "S" : "W"));
                g.setFont(G.F_B18); g.setTextSize(1f); g.setTextDatum(G.MC);
                g.setTextColor(angle == 0 ? N_RED : G.BLACK);
                g.drawString(s, nx, ny);
            } else {
                g.ui(String.valueOf(angle / 10), nx, ny, G.MC, G.BLACK, 0.34f);
            }
        }
    }

    /** punto (metri est/nord dal centro pista) -> schermo */
    private static float[] proj(float x, float y, float rtx, float rty, float fwx, float fwy, float k) {
        return new float[]{ 180f + k * (x * rtx + y * rty), 180f - k * (x * fwx + y * fwy) };
    }

    private static void quad(G g, float[] qx, float[] qy, float ux, float uy, float lx, float ly,
                             float rtx, float rty, float fwx, float fwy, float k,
                             float s0, float s1, float t0, float t1, int col) {
        final float[] ss = { s0, s0, s1, s1 }, tt = { t0, t1, t1, t0 };
        for (int i = 0; i < 4; i++) {
            final float dx = ux * ss[i] + lx * tt[i], dy = uy * ss[i] + ly * tt[i];
            qx[i] = 180f + k * (dx * rtx + dy * rty);
            qy[i] = 180f - k * (dx * fwx + dy * fwy);
        }
        g.polygon(qx, qy, 4, col);
    }
}
