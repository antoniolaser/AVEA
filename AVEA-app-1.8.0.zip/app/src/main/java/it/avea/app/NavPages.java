package it.avea.app;

import android.os.SystemClock;

import java.util.Locale;

/**
 * Pagine di navigazione copiate dal firmware: COMPASS, GO TO HOME (con le linee lubber del corridoio),
 * LUBBER LINE e HOME FIELD. Coordinate e colori come sul display tondo.
 */
public class NavPages {

    // ---------- corridoio fuori rotta (lubber line), come nel firmware ----------
    static final float[] LUBBER_WIDTH_KM = {1f, 2f, 3f, 5f};
    static final float[] LUBBER_YELLOW_KM = {1f, 2f, 3f};
    static final double LUBBER_MIN_LEG_KM = 0.5, LUBBER_OFF_DEG = 100, LUBBER_ON_DEG = 80, LUBBER_REANCHOR_DEG = 20,
            LUBBER_FUNNEL_REF_KM = 10, LUBBER_REANCHOR_KM = 2.0;
    static final float LUBBER_MIN_SPEED_KMH = 10f, LUBBER_MIN_GREEN_KM = 0.5f, LUBBER_MIN_YELLOW_KM = 0.3f;
    static final float GS_ZERO_THRESHOLD_KMH = 8f;

    private static double angDist(double la1, double lo1, double la2, double lo2) {
        final double dLa = la2 - la1, dLo = lo2 - lo1;
        final double a = Math.sin(dLa / 2) * Math.sin(dLa / 2) + Math.cos(la1) * Math.cos(la2) * Math.sin(dLo / 2) * Math.sin(dLo / 2);
        return 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }
    private static double brg(double la1, double lo1, double la2, double lo2) {
        final double dLo = lo2 - lo1;
        return Math.atan2(Math.sin(dLo) * Math.cos(la2), Math.cos(la1) * Math.sin(la2) - Math.sin(la1) * Math.cos(la2) * Math.cos(dLo));
    }
    static double tLat(FlightData d) { return d.gotoField ? d.gotoLat : d.homeLat; }
    static double tLon(FlightData d) { return d.gotoField ? d.gotoLon : d.homeLon; }
    static boolean navTargetValid(FlightData d) { return d.gotoField || d.homeSet; }

    /** Fuori rotta in km (positivo = a destra della tratta guardando verso la meta), NaN se non definito. */
    static float crossTrackKm(FlightData d, double lat, double lon) {
        if (!d.lubberLegValid || !navTargetValid(d)) return Float.NaN;
        final double R = 6371.0;
        final double la1 = Math.toRadians(d.lubberLegLat), lo1 = Math.toRadians(d.lubberLegLon);
        final double la2 = Math.toRadians(tLat(d)), lo2 = Math.toRadians(tLon(d));
        final double la3 = Math.toRadians(lat), lo3 = Math.toRadians(lon);
        if (angDist(la1, lo1, la2, lo2) * R < LUBBER_MIN_LEG_KM) return Float.NaN;
        final double d13 = angDist(la1, lo1, la3, lo3);
        double sx = Math.sin(d13) * Math.sin(brg(la1, lo1, la3, lo3) - brg(la1, lo1, la2, lo2));
        sx = Math.max(-1, Math.min(1, sx));
        return (float) (Math.asin(sx) * R);
    }
    static void reanchorIfNeeded(FlightData d, double lat, double lon) {
        if (!d.lubberLegValid || !navTargetValid(d)) return;
        final double R = 6371.0, la2 = Math.toRadians(tLat(d)), lo2 = Math.toRadians(tLon(d));
        final double legKm = angDist(Math.toRadians(d.lubberLegLat), Math.toRadians(d.lubberLegLon), la2, lo2) * R;
        if (legKm >= LUBBER_REANCHOR_KM) return;
        final double nowKm = angDist(Math.toRadians(lat), Math.toRadians(lon), la2, lo2) * R;
        if (nowKm >= LUBBER_REANCHOR_KM) { d.lubberLegLat = lat; d.lubberLegLon = lon; }
    }

    // ---------- tacche e numeri della bussola (COMPASS e GO HOME) ----------
    private static void rose(G g, float refAngle, int tickColor, int numColor) {
        final int cx = 180, cy = 180, tickR = 175, numR = 145;
        for (int angle = 0; angle < 360; angle += 10) {
            final double rad = Math.toRadians(angle - refAngle - 90);
            final float xo = (float) (cx + tickR * Math.cos(rad)), yo = (float) (cy + tickR * Math.sin(rad));
            if (angle % 30 == 0) {
                final float xi = (float) (cx + (tickR - 20) * Math.cos(rad)), yi = (float) (cy + (tickR - 20) * Math.sin(rad));
                g.thickLine(xi, yi, xo, yo, tickColor, 3);
                final float nx = (float) (cx + numR * Math.cos(rad)), ny = (float) (cy + numR * Math.sin(rad));
                if (angle % 90 == 0) {
                    g.setFont(G.F_B18);
                    g.setTextDatum(G.MC);
                    g.setTextColor(angle == 0 ? G.ORANGE : numColor);
                    g.drawString(angle == 0 ? "N" : (angle == 90 ? "E" : (angle == 180 ? "S" : "W")), nx, ny);
                } else {
                    g.num(String.valueOf(angle / 10), nx, ny, G.MC, numColor, 0.34f);
                }
            } else {
                final float xi = (float) (cx + (tickR - 10) * Math.cos(rad)), yi = (float) (cy + (tickR - 10) * Math.sin(rad));
                g.thickLine(xi, yi, xo, yo, tickColor, 3);
            }
        }
    }

    /** Aereo come la sagoma bitmap del firmware (circa 115 x 112 px). */
    // Sagoma dell'aereo come nel firmware (bitmap 115 x 112 px): ala dritta con estremita' arrotondate,
    // elica a barra, fusoliera che si stringe, piano di coda arrotondato. Con s = 1.25 e' larga 115 px.
    private static final float[] PLANE_X = {1, 1, 12, 13.5f, 12, 3.5f, 5, 5.8f, 6, 43.5f, 45.5f, 46, 46, 45, 43, 5, 4.3f, 3.4f, 2.4f, 17, 19, 19.5f, 18, 1.2f, 1, -1, -1.2f, -18, -19.5f, -19, -17, -2.4f, -3.4f, -4.3f, -5, -43, -45, -46, -46, -45.5f, -43.5f, -6, -5.8f, -5, -3.5f, -12, -13.5f, -12, -1, -1};
    private static final float[] PLANE_Y = {-45, -41.5f, -41.5f, -40.7f, -39, -39, -35, -31, -25.5f, -25.5f, -24, -21, -11, -8.5f, -7.5f, -4.5f, -2, 10, 24.5f, 25.5f, 27.5f, 34.5f, 36.8f, 37.2f, 44, 44, 37.2f, 36.8f, 34.5f, 27.5f, 25.5f, 24.5f, 10, -2, -4.5f, -7.5f, -8.5f, -11, -21, -24, -25.5f, -25.5f, -31, -35, -39, -39, -40.7f, -41.5f, -41.5f, -45};
    static void airplane(G g, float cx, float cy, int color, float s) {
        final int n = PLANE_X.length;
        final float[] xs = new float[n], ys = new float[n];
        for (int i = 0; i < n; i++) { xs[i] = cx + PLANE_X[i] * s; ys[i] = cy + PLANE_Y[i] * s; }
        g.polygon(xs, ys, n, color);
    }

    // ---------- COMPASS ----------
    static float lastCompassCourse = -999f;

    static void compass(G g, FlightData d) {
        float course = d.courseDeg;
        final boolean gpsValid = d.gpsValid;
        final boolean usable = gpsValid && d.speedKmh >= GS_ZERO_THRESHOLD_KMH;
        if (gpsValid && !usable && lastCompassCourse > -360f) course = lastCompassCourse;
        lastCompassCourse = course;
        final boolean useRed = !gpsValid;
        final int tickColor = useRed ? G.RED : G.WHITE, numColor = tickColor;
        g.fillSprite(G.BLACK);
        final int cx = 180, cy = 180;
        rose(g, gpsValid ? course : 0f, tickColor, numColor);
        g.thickTriangle(cx, 7, cx - 8, 27, cx + 8, 27, G.CYAN, 3);
        g.thickTriangle(cx, 353, cx - 8, 333, cx + 8, 333, G.CYAN, 3);
        final int centerShift = 13;
        airplane(g, cx, cy - 60 + centerShift, G.YELLOW, 1.25f);
        // riquadro A.V.E.A*
        final float w = g.ui("A.V.E.A*", 180, 280, G.MC, G.CYAN, 0.62f);
        final float boxW = Math.max(100, w + 16);
        g.drawRect(180 - boxW / 2, 280 - 13 - 4, boxW, 26 + 8 + 1, G.CYAN);
        if (gpsValid) {
            final String cs = String.valueOf(Math.round(course) % 360);
            final int numY = cy + 35 + centerShift, numX = cx - 10;
            final float cw = g.num(cs, numX, numY, G.MC, useRed ? G.RED : G.YELLOW, 0.72f);
            final float degX = numX + cw / 2 + 14, degY = numY - 16;
            g.drawCircle(degX, degY, 5, G.YELLOW);
            g.drawCircle(degX, degY, 4, G.YELLOW);
        } else {
            g.setFont(G.F_B18); g.setTextSize(1.35f); g.setTextDatum(G.MC); g.setTextColor(G.RED);
            g.drawString("NO GPS FIX", cx, cy + 35 + centerShift);
        }
    }

    // ---------- GO TO HOME ----------
    static void goHome(G g, FlightData d) {
        final boolean gpsValid = d.gpsValid;
        final double lat = d.lat, lon = d.lon;
        final float course = d.courseDeg, speedKmh = d.speedKmh;
        double distanceKm = 0, bearing = 0;
        long etaSeconds = -1;
        final boolean navigationValid = navTargetValid(d) && gpsValid;
        int xteState = 0, arrowStage = 6;
        if (navigationValid) {
            distanceKm = FlightData.distanceKm(lat, lon, tLat(d), tLon(d));
            bearing = FlightData.bearingDeg(lat, lon, tLat(d), tLon(d));
            final double closing = speedKmh * Math.cos(Math.toRadians(course - bearing));
            etaSeconds = closing > 1.0 ? (long) Math.ceil(distanceKm / closing * 3600.0) : -1;
            if (!d.lubberLegValid) { d.lubberLegLat = lat; d.lubberLegLon = lon; d.lubberLegValid = true; }
            final boolean blink = (SystemClock.uptimeMillis() / 300) % 2 == 0;
            if (distanceKm > 2.0) arrowStage = 6;
            else if (distanceKm >= 1.5) arrowStage = blink ? 7 : 8;
            else if (distanceKm >= 0.9) arrowStage = 9;
            else if (distanceKm >= 0.5) arrowStage = 10;
            else if (distanceKm >= 0.4) arrowStage = blink ? 11 : 12;
            else arrowStage = 13;
            reanchorIfNeeded(d, lat, lon);
            float xte = crossTrackKm(d, lat, lon);
            double courseDiff = ((course - bearing) % 360 + 360) % 360;
            if (courseDiff > 180) courseDiff = 360 - courseDiff;
            if (speedKmh >= LUBBER_MIN_SPEED_KMH) {
                if (d.lubberActive && courseDiff > LUBBER_OFF_DEG) d.lubberActive = false;
                else if (!d.lubberActive && courseDiff < LUBBER_ON_DEG) d.lubberActive = true;
            }
            if (!Float.isNaN(xte) && d.lubberActive) {
                float widthKm = LUBBER_WIDTH_KM[d.lubberEdit ? d.lubberWidthIdx : 0];
                float yellowKm = LUBBER_YELLOW_KM[d.lubberEdit ? d.lubberYellowIdx : 0];
                if (distanceKm < LUBBER_FUNNEL_REF_KM) {
                    final float k = (float) (distanceKm / LUBBER_FUNNEL_REF_KM);
                    widthKm = Math.min(widthKm, Math.max(widthKm * k, LUBBER_MIN_GREEN_KM));
                    yellowKm = Math.min(yellowKm, Math.max(yellowKm * k, LUBBER_MIN_YELLOW_KM));
                }
                float absXte = Math.abs(xte);
                if (absXte > widthKm && courseDiff < LUBBER_REANCHOR_DEG && speedKmh >= LUBBER_MIN_SPEED_KMH
                        && distanceKm >= LUBBER_MIN_LEG_KM) {
                    d.lubberLegLat = lat; d.lubberLegLon = lon; xte = 0; absXte = 0;
                }
                if (absXte <= widthKm) xteState = 1;
                else xteState = (xte > 0 ? 2 : 4) + (absXte > widthKm + yellowKm ? 1 : 0);
            }
        }
        g.fillSprite(G.BLACK);
        // linee lubber: corridoio verticale
        int leftColor = G.WHITE, rightColor = G.WHITE, leftThick = 2, rightThick = 2, correctDir = 0, correctColor = G.WHITE;
        if (xteState >= 1) {
            leftColor = rightColor = G.GREEN;
            if (xteState >= 2) {
                final boolean isRed = xteState == 3 || xteState == 5;
                final int warn = isRed ? G.RED : G.YELLOW, wt = isRed ? 6 : 4;
                if (xteState <= 3) { rightColor = warn; rightThick = wt; }
                else { leftColor = warn; leftThick = wt; }
                correctColor = warn;
            }
        }
        // Freccetta: da che parte virare per portare la freccia grande al centro tra le linee lubber
        // (verso la meta). Solo con la linea gialla o rossa, dello stesso colore, oltre 10 gradi.
        if (navigationValid && xteState >= 2) {
            final int rel = (int) ((((bearing - course) % 360) + 540) % 360) - 180;
            if (rel > 10) correctDir = 1;
            else if (rel < -10) correctDir = -1;
        }
        // Dal primo cerchio rosso (sotto 1.5 km) le linee lubber diventano la pista della meta:
        // ruotano con la rotta e alle testate compaiono i numeri della pista.
        final int rwyTens = (navigationValid && arrowStage >= 9) ? d.navRwyTens : 0;
        if (rwyTens > 0) runwayLines(g, rwyTens, course, 172f, leftThick, rightThick, leftColor, rightColor);
        else {
            g.fillRect(172 - leftThick, 8, leftThick, 345, leftColor);
            g.fillRect(190, 8, rightThick, 345, rightColor);
        }

        if (!navigationValid) {
            g.setTextDatum(G.MC);
            if (d.gotoField) {
                g.setFont(G.F_B12); g.setTextSize(0.85f); g.setTextColor(G.ORANGE);
                g.drawString("GO TO " + d.gotoName, 180, 62);
            } else {
                g.setFont(G.F_B12); g.setTextSize(1.2f); g.setTextColor(G.CYAN);
                g.drawString("GO TO HOME", 180, 62);
            }
            if (navTargetValid(d)) {
                g.setFont(G.F_B18); g.setTextSize(1.35f); g.setTextColor(G.RED);
                g.drawString("NO GPS FIX", 180, 215);
            } else {
                g.setFont(G.F_B12); g.setTextSize(1f); g.setTextColor(G.YELLOW);
                g.drawString("HOME NOT SET", 180, 150);
                g.drawString("Tap to center", 180, 198);
                g.drawString("to set home", 180, 230);
            }
            return;
        }
        final int cx = 180, cy = 180;
        rose(g, course, G.WHITE, G.WHITE);
        final double arrowAngle = Math.toRadians(bearing - course - 90.0);
        final float ca = (float) Math.cos(arrowAngle), sa = (float) Math.sin(arrowAngle);
        final float tipX = cx + 124 * ca, tipY = cy + 124 * sa, neckX = cx + 84 * ca, neckY = cy + 84 * sa;
        final float baseX = cx + 14 * ca, baseY = cy + 14 * sa;
        final double leftA = arrowAngle + 2.55, rightA = arrowAngle - 2.55;
        g.thickTriangle(cx, 27, cx - 8, 7, cx + 8, 7, G.CYAN, 3);
        g.thickTriangle(cx, 353, cx - 8, 333, cx + 8, 333, G.CYAN, 3);
        final int navLeftX = cx - 60, navRightX = cx + 60, navLabelY = cy - 20, navValueY = cy + 22;
        if (arrowStage < 9) {
            g.ui("Km to", navLeftX, navLabelY, G.MC, G.YELLOW, 0.87f);
            g.ui(String.format(Locale.ROOT, "%.1f", distanceKm), navLeftX, navValueY, G.MC, G.YELLOW, 1.05f);
            g.ui("ETA", navRightX, navLabelY, G.MC, G.YELLOW, 0.87f);
            final String eta = etaSeconds >= 0 ? String.format(Locale.ROOT, "%02d:%02d", etaSeconds / 3600, (etaSeconds % 3600) / 60) : "--:--";
            g.ui(eta, navRightX, navValueY, G.MC, G.YELLOW, 1.05f);
            g.ui("HH", navRightX - 21, navValueY + 21, G.MC, G.YELLOW, 0.48f);
            g.ui("MM", navRightX + 21, navValueY + 21, G.MC, G.YELLOW, 0.48f);
        }
        final float tailBaseX = cx - 14 * ca, tailBaseY = cy - 14 * sa, tailEndX = cx - 140 * ca, tailEndY = cy - 140 * sa;
        if (arrowStage < 9) {
            if (arrowStage != 8) {
                g.thickLine(tailBaseX, tailBaseY, tailEndX, tailEndY, G.YELLOW, 11);
                g.thickLine(baseX, baseY, neckX, neckY, G.YELLOW, 11);
                g.fillTriangle(tipX, tipY, neckX + 25 * (float) Math.cos(leftA), neckY + 25 * (float) Math.sin(leftA),
                        neckX + 25 * (float) Math.cos(rightA), neckY + 25 * (float) Math.sin(rightA), G.YELLOW);
            }
            g.fillCircle(cx, cy, 8, G.CYAN);
        } else {
            final boolean yellowOn = arrowStage >= 10, greenOn = arrowStage == 11 || arrowStage == 13;
            g.fillCircle(cx, cy, 76, G.RED);
            g.fillCircle(cx, cy, 62, G.BLACK);
            if (yellowOn) { g.fillCircle(cx, cy, 50, G.YELLOW); g.fillCircle(cx, cy, 36, G.BLACK); }
            else g.drawCircle(cx, cy, 43, G.DARKGREY);
            if (greenOn) g.fillCircle(cx, cy, 24, G.GREEN); else g.drawCircle(cx, cy, 24, G.DARKGREY);
            if (rwyTens > 0) runwayLines(g, rwyTens, course, 132f, leftThick, rightThick, leftColor, rightColor);
            int courseTens = (int) ((course + 5f) / 10f) % 36;
            if (courseTens == 0) courseTens = 36;
            int opp = (courseTens + 18) % 36;
            if (opp == 0) opp = 36;
            if (rwyTens <= 0) {
                g.ui(String.format(Locale.ROOT, "%02d", opp), cx, cy - 114, G.MC, G.GREEN, 0.95f);
                g.ui(String.format(Locale.ROOT, "%02d", courseTens), cx, cy + 114, G.MC, G.GREEN, 0.95f);
            }
            if (arrowStage == 9 || arrowStage == 10) {
                final float sTipX = cx + 74 * ca, sTipY = cy + 74 * sa, sNeckX = cx + 48 * ca, sNeckY = cy + 48 * sa;
                final float sTailX = cx - 70 * ca, sTailY = cy - 70 * sa;
                g.thickLine(sTailX, sTailY, sNeckX, sNeckY, G.BLACK, 11);
                g.fillTriangle(cx + 80 * ca, cy + 80 * sa, sNeckX + 20 * (float) Math.cos(leftA), sNeckY + 20 * (float) Math.sin(leftA),
                        sNeckX + 20 * (float) Math.cos(rightA), sNeckY + 20 * (float) Math.sin(rightA), G.BLACK);
                g.thickLine(sTailX, sTailY, sNeckX, sNeckY, G.WHITE, 7);
                g.fillTriangle(sTipX, sTipY, sNeckX + 16 * (float) Math.cos(leftA), sNeckY + 16 * (float) Math.sin(leftA),
                        sNeckX + 16 * (float) Math.cos(rightA), sNeckY + 16 * (float) Math.sin(rightA), G.WHITE);
            }
            if (rwyTens > 0) {   // numeri della pista alle testate, in una cornice verde, sopra tutto
                final int r1 = rwyTens, r2 = (rwyTens + 18 - 1) % 36 + 1;
                final double ra = Math.toRadians(rwyTens * 10.0 - course);
                final float ux = (float) Math.sin(ra), uy = (float) -Math.cos(ra);
                final float NUM_SCALE = 0.95f * 1.3f, NUM_R = 105f;
                for (int e = 0; e < 2; e++) {
                    final String b = String.format(Locale.ROOT, "%02d", e == 0 ? r1 : r2);
                    final float sgn = e == 0 ? -1f : 1f;
                    final float nx = cx + sgn * NUM_R * ux, ny = cy + sgn * NUM_R * uy;
                    g.setFont(G.F_UI32); g.setTextSize(NUM_SCALE);
                    final float w = g.textWidth(b) + 14, h = 26f * NUM_SCALE + 12;
                    g.fillRoundRect(nx - w / 2, ny - h / 2, w, h, 7, G.BLACK);
                    g.ui(b, nx, ny + 1, G.MC, G.GREEN, NUM_SCALE);
                    g.drawRoundRect(nx - w / 2, ny - h / 2, w, h, 7, G.GREEN);
                    g.drawRoundRect(nx - w / 2 + 1, ny - h / 2 + 1, w - 2, h - 2, 6, G.GREEN);
                }
            }
        }
        if (d.gotoField && arrowStage < 9) {
            g.fillRoundRect(cx - 82, 233, 164, 28, 8, G.BLACK);
            g.drawRoundRect(cx - 82, 233, 164, 28, 8, G.ORANGE);
            g.ui(d.gotoName, cx, 247, G.MC, G.ORANGE, 0.55f);
            g.fillRoundRect(cx - 44, 286, 88, 28, 8, G.BLACK);
            g.drawRoundRect(cx - 44, 286, 88, 28, 8, G.YELLOW);
            g.drawRoundRect(cx - 43, 287, 86, 26, 7, G.YELLOW);
            g.ui("HOME", cx, 300, G.MC, G.YELLOW, 0.55f);
        }
        if (correctDir != 0 && arrowStage < 9) {
            final int ay = 125, ax = correctDir < 0 ? 230 : 130;
            g.thickLine(ax - correctDir * 23, ay, ax + correctDir * 5, ay, correctColor, 5);
            g.fillTriangle(ax + correctDir * 23, ay, ax + correctDir * 5, ay - 13, ax + correctDir * 5, ay + 13, correctColor);
        }
    }

    /** Linee lubber ruotate come la pista della meta (rwyTens decine di gradi), lunghe 2 x half. */
    private static void runwayLines(G g, int rwyTens, float course, float half, int lt, int rt, int lc, int rc) {
        final double ra = Math.toRadians(rwyTens * 10.0 - course);
        final float ux = (float) Math.sin(ra), uy = (float) -Math.cos(ra), px = -uy, py = ux;
        final float offL = -(8f + lt / 2f), offR = 10f + rt / 2f;
        g.drawWideLine(180 + px * offL - ux * half, 180 + py * offL - uy * half, 180 + px * offL + ux * half, 180 + py * offL + uy * half, lt / 2f, lc);
        g.drawWideLine(180 + px * offR - ux * half, 180 + py * offR - uy * half, 180 + px * offR + ux * half, 180 + py * offR + uy * half, rt / 2f, rc);
    }

    // ---------- LUBBER LINE ----------
    static void lubberLine(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.setTextDatum(G.MC);
        g.setFont(G.F_B12); g.setTextSize(1.1f); g.setTextColor(G.CYAN);
        g.drawString("LUBBER LINE", 180, 42);
        g.setFont(G.F_B9); g.setTextColor(G.WHITE);
        g.drawString("GREEN WIDTH (km)", 180, 80);
        g.drawString("YELLOW MARGIN (+km)", 180, 176);
        g.setFont(G.F_B12);
        final String[] w = {"1", "2", "3", "5"}, y = {"+1", "+2", "+3"};
        for (int row = 0; row < 2; row++) {
            final int count = row == 0 ? 4 : 3, boxW = row == 0 ? 60 : 80, stepX = row == 0 ? 68 : 90;
            final int x0 = row == 0 ? 48 : 50, boxY = row == 0 ? 96 : 192, boxH = 44;
            final int sel = row == 0 ? d.lubberWidthIdx : d.lubberYellowIdx;
            for (int i = 0; i < count; i++) {
                final int bx = x0 + i * stepX;
                final boolean s = i == sel;
                final int accent = s ? G.GREEN : G.DARKGREY;
                if (s) g.fillRoundRect(bx, boxY, boxW, boxH, 8, accent); else g.drawRoundRect(bx, boxY, boxW, boxH, 8, accent);
                g.setTextColor(s ? G.BLACK : G.WHITE);
                g.drawString(row == 0 ? w[i] : y[i], bx + boxW / 2f, boxY + boxH / 2f);
            }
        }
    }
    /** Tocco su LUBBER LINE: true se ha cambiato qualcosa. */
    static boolean lubberTap(FlightData d, float x, float y) {
        if (y >= 96 && y <= 140) for (int i = 0; i < 4; i++) if (x >= 48 + i * 68 && x <= 108 + i * 68) { d.lubberWidthIdx = i; return true; }
        if (y >= 192 && y <= 236) for (int i = 0; i < 3; i++) if (x >= 50 + i * 90 && x <= 130 + i * 90) { d.lubberYellowIdx = i; return true; }
        return false;
    }

    // ---------- HOME FIELD ----------
    static String coordText(double v, boolean lat) {
        final char h = lat ? (v >= 0 ? 'N' : 'S') : (v >= 0 ? 'E' : 'W');
        v = Math.abs(v);
        final int deg = (int) v;
        final double min = (v - deg) * 60.0;
        return String.format(Locale.ROOT, lat ? "%s%02d*%06.3f'" : "%s%03d*%06.3f'", h, deg, min);
    }
    private static void degText(G g, String s, float y, int color) {
        // '*' = simbolo dei gradi disegnato a mano (come homeFieldDrawDegText)
        g.setFont(G.F_B12); g.setTextDatum(G.ML); g.setTextColor(color);
        final String a = s.substring(0, s.indexOf('*')), b = s.substring(s.indexOf('*') + 1);
        final float wa = g.textWidth(a), wb = g.textWidth(b), total = wa + 9 + wb;
        float x = 180 - total / 2;
        g.drawString(a, x, y);
        g.drawCircle(x + wa + 4, y - 8, 3, color);
        g.drawString(b, x + wa + 9, y);
    }
    static void homeField(G g, FlightData d, boolean confirmPending) {
        g.fillScreen(G.BLACK);
        g.ui("HOME FIELD", 180, 55, G.MC, G.CYAN, 0.88f);
        g.setFont(G.F_B9); g.setTextDatum(G.MC); g.setTextColor(G.WHITE);
        g.drawString("Lat (DD MM.mmm):", 180, 75);
        if (d.homeSet) degText(g, coordText(d.homeLat, true), 102, G.GREEN);
        else { g.setFont(G.F_B12); g.setTextColor(G.GREEN); g.drawString("-- not set --", 180, 102); }
        g.setFont(G.F_B9); g.setTextDatum(G.MC); g.setTextColor(G.WHITE);
        g.drawString("Lon (DD MM.mmm):", 180, 142);
        if (d.homeSet) degText(g, coordText(d.homeLon, false), 169, G.GREEN);
        else { g.setFont(G.F_B12); g.setTextDatum(G.MC); g.setTextColor(G.GREEN); g.drawString("-- not set --", 180, 169); }
        g.setFont(G.F_B9); g.setTextDatum(G.MC);
        if (confirmPending) { g.setTextColor(G.ORANGE); g.drawString("Tap SET HOME again to confirm", 180, 190); }
        else { g.setTextColor(G.CYAN); g.drawString("Tap center to exit", 180, 335); }
        g.drawRect(100, 257, 160, 61, G.GREEN);
        g.drawRect(68, 200, 100, 38, G.ORANGE);
        g.drawRect(192, 200, 100, 38, G.YELLOW);
        g.ui("GO TO", 180, 287, G.MC, G.GREEN, 0.88f);
        g.setFont(G.F_B9); g.setTextDatum(G.MC);
        g.setTextColor(G.ORANGE); g.drawString(confirmPending ? "CONFIRM" : "SET HOME", 118, 219);
        g.setTextColor(G.YELLOW); g.drawString("RESET", 242, 219);
    }
}
