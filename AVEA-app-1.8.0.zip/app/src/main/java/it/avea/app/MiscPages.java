package it.avea.app;

import android.os.SystemClock;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Altre pagine copiate dal firmware: SET QNH, GPS CLOCK, AUTOMATIC / MANUAL FLIGHT TIMER, FLIGHT LOG,
 * log salvati, ICT, FUEL ESTIMATE, GPS INFO.
 */
public class MiscPages {

    static final int FUEL_GOLD = 0xECE4;

    // ---------- SET QNH ----------
    static void qnh(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("SET QNH", 180, 45, G.MC, G.WHITE, 1f);
        g.drawRect(40, 80, 130, 60, G.GREEN);
        g.ui("DOWN -", 105, 110, G.MC, G.GREEN, 0.82f);
        g.drawRect(190, 80, 130, 60, G.GREEN);
        g.ui("UP +", 255, 110, G.MC, G.GREEN, 0.82f);
        g.setFont(G.F_B24); g.setTextDatum(G.MC); g.setTextColor(G.YELLOW);
        g.drawString(Math.round(d.qnhHpa) + " hPa", 180, 170);
        g.setFont(G.F_B12);
        final int mc = d.unitsMeters ? G.GREEN : G.YELLOW, fc = !d.unitsMeters ? G.GREEN : G.YELLOW;
        g.drawRect(40, 215, 130, 50, mc); g.setTextColor(mc); g.drawString("METERS", 105, 240);
        g.drawRect(190, 215, 130, 50, fc); g.setTextColor(fc); g.drawString("FEET", 255, 240);
        g.drawRect(80, 275, 200, 40, G.YELLOW); g.setTextColor(G.YELLOW); g.drawString("BACK / SAVE", 180, 295);
    }

    // ---------- gruppo dell'orologio (ClockFont60) e righe START/STOP (ClockFont22) ----------
    static void timerGroup(G g, String t, float cy, int color) {
        g.setFontDigits(G.F_CLK60); g.setTextDatum(G.MC); g.setTextColor(color);
        g.drawString(t, 180, cy - 11 + 11);
    }
    static void startStopLine(G g, String t, float cy) {
        g.setFontDigits(G.F_CLK22); g.setTextDatum(G.MC); g.setTextColor(G.WHITE);
        g.drawString(t, 180, cy);
    }

    // ---------- GPS CLOCK ----------
    static void gpsClock(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("GPS CLOCK", 180, 55, G.MC, G.CYAN, 1f);
        final Date now = new Date();
        // riquadri colorati (come il firmware): ora su fondo blu scuro con doppia cornice blu, data in cornice verde,
        // tramonto in un riquadro arancio con il sole
        final int blue = G.color565(47, 125, 255), green = G.color565(34, 212, 106), orange = G.color565(255, 144, 32);
        g.fillRoundRect(40, 83, 280, 72, 14, G.color565(10, 30, 80));
        g.drawRoundRect(40, 83, 280, 72, 14, blue); g.drawRoundRect(41, 84, 278, 70, 13, blue);
        g.drawRoundRect(28, 165, 304, 52, 10, green);
        g.fillRoundRect(70, 262, 220, 36, 10, G.color565(58, 34, 0)); g.drawRoundRect(70, 262, 220, 36, 10, orange);
        g.fillCircle(94, 280, 4, orange);
        for (int i = 0; i < 8; i++) {
            final double a = Math.toRadians(i * 45);
            g.drawWideLine(94 + 7 * (float) Math.cos(a), 280 + 7 * (float) Math.sin(a), 94 + 12 * (float) Math.cos(a), 280 + 12 * (float) Math.sin(a), 0.6f, orange);
        }
        timerGroup(g, new SimpleDateFormat("HH:mm:ss", Locale.ITALY).format(now), 119, G.WHITE);
        g.setFontDigits(G.F_CLK48); g.setTextDatum(G.MC); g.setTextColor(green);
        g.drawString(new SimpleDateFormat("dd / MM / yyyy", Locale.ITALY).format(now), 180, 191);
        final TimeZone tz = TimeZone.getDefault();
        final boolean dst = tz.inDaylightTime(now);
        final int offMin = tz.getOffset(now.getTime()) / 60000;
        String off = "UTC" + (offMin < 0 ? "-" : "+") + Math.abs(offMin) / 60;
        if (Math.abs(offMin) % 60 != 0) off += String.format(Locale.ROOT, ":%02d", Math.abs(offMin) % 60);
        final String abbr = tz.getDisplayName(dst, TimeZone.SHORT, Locale.ITALY);
        g.setFont(G.F_B12); g.setTextColor(G.CYAN);
        g.drawString((abbr.startsWith("GMT") || abbr.startsWith("UTC") ? "" : abbr + " ") + off + (d.gpsValid ? " GPS" : " PHONE"), 180, 245);
        final long ss = d.sunsetTodayMs();
        g.setTextColor(orange);
        g.drawString("SUNSET " + (ss > 0 ? new SimpleDateFormat("HH:mm", Locale.ITALY).format(new Date(ss)) : "--:--"), 196, 280);
        g.setFont(G.F_B9); g.setTextColor(G.YELLOW);
        g.drawString(dst ? "AUTO ZONE (DST)" : "AUTO ZONE", 180, 315);
    }

    // ---------- AUTOMATIC FLIGHT TIMER ----------
    static String hm(long ms) { return ms > 0 ? new SimpleDateFormat("HH:mm", Locale.ITALY).format(new Date(ms)) : "--:--"; }
    static void autoTimer(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("AUTOMATIC", 180, 48, G.MC, G.CYAN, 0.9f);
        g.ui("FLIGHT TIMER", 180, 78, G.MC, G.CYAN, 0.9f);
        timerGroup(g, FlightData.fmtDuration(d.flightElapsedMs()), 150, d.flying ? G.GREEN : G.RED);
        startStopLine(g, "START: " + hm(d.flightStartMs), 215);
        startStopLine(g, "STOP:  " + (d.flying ? "--:--" : hm(d.flightEndMs)), 240);
        g.drawRect(85, 275, 190, 45, G.YELLOW);
        g.ui("FLIGHT LOG", 180, 298, G.MC, G.YELLOW, 0.9f);
    }

    // ---------- FLIGHT LOG (volo in corso o ultimo) ----------
    // Icone gialle del FLIGHT LOG (come il firmware): 0 orologio, 1 percorso, 2 carburante, 3 aereo, 4 montagne,
    // 5 salita, 6 termometro, 7 goccia, 8 satellite (orari e data)
    private static void rotRect(G g, float cx, float cy, float l, float w, int c) {
        final float k = 0.7071f, ax = k * l / 2, ay = k * l / 2, bx = k * w / 2, by = -k * w / 2;
        g.fillTriangle(cx - ax - bx, cy - ay - by, cx + ax - bx, cy + ay - by, cx + ax + bx, cy + ay + by, c);
        g.fillTriangle(cx - ax - bx, cy - ay - by, cx + ax + bx, cy + ay + by, cx - ax + bx, cy - ay + by, c);
    }
    static void logIcon(G g, int k, float x, float y, int c) {
        final int B = G.BLACK;
        switch (k) {
            case 0: g.drawCircle(x, y, 6, c); g.drawCircle(x, y, 5, c);
                g.drawWideLine(x, y, x, y - 4, 0.8f, c); g.drawWideLine(x, y, x + 3, y + 1, 0.8f, c); break;
            case 1: g.fillCircle(x + 3, y - 3, 4, c); g.fillTriangle(x - 1, y - 2, x + 7, y - 2, x + 3, y + 5, c);
                g.fillCircle(x + 3, y - 3, 1, B);
                g.fillCircle(x - 6, y + 6, 1, c); g.fillCircle(x - 3, y + 6, 1, c); g.fillCircle(x, y + 6, 1, c); break;
            case 2: g.fillRoundRect(x - 6, y - 6, 8, 13, 1, c); g.fillRect(x - 4, y - 4, 4, 3, B);
                g.drawWideLine(x + 2, y - 4, x + 5, y - 2, 0.7f, c); g.drawWideLine(x + 5, y - 2, x + 5, y + 4, 0.7f, c);
                g.drawWideLine(x + 5, y + 4, x + 3, y + 4, 0.7f, c); break;
            case 3: g.drawWideLine(x - 6, y, x + 6, y, 1.3f, c);
                g.fillTriangle(x + 2, y, x - 2, y - 7, x - 3, y, c); g.fillTriangle(x + 2, y, x - 2, y + 7, x - 3, y, c);
                g.fillTriangle(x - 4, y, x - 6, y - 3, x - 7, y, c); g.fillTriangle(x - 4, y, x - 6, y + 3, x - 7, y, c); break;
            case 4: g.fillTriangle(x - 7, y + 6, x - 1, y - 5, x + 5, y + 6, c); g.fillTriangle(x - 1, y + 6, x + 3, y - 1, x + 7, y + 6, c); break;
            case 5: g.drawWideLine(x - 7, y + 5, x - 3, y + 1, 0.9f, c); g.drawWideLine(x - 3, y + 1, x, y + 3, 0.9f, c);
                g.drawWideLine(x, y + 3, x + 5, y - 3, 0.9f, c); g.fillTriangle(x + 7, y - 6, x + 1, y - 4, x + 6, y, c); break;
            case 6: g.fillRoundRect(x - 2, y - 7, 5, 10, 2, c); g.fillCircle(x, y + 4, 3, c);
                g.drawFastHLine(x + 4, y - 5, 3, c); g.drawFastHLine(x + 4, y - 2, 3, c); g.drawFastHLine(x + 4, y + 1, 3, c); break;
            case 7: g.fillCircle(x, y + 2, 4, c); g.fillTriangle(x - 4, y + 1, x + 4, y + 1, x, y - 7, c); break;
            case 8: rotRect(g, x + 1, y - 2, 4, 3.5f, c);
                rotRect(g, x + 1 - 3.9f, y - 2 - 3.9f, 5, 5, c);
                rotRect(g, x + 1 + 3.9f, y - 2 + 3.9f, 5, 5, c);
                g.drawLine(x - 1, y, x - 3, y + 2, c);
                g.fillArc(x + 1, y - 2, 6, 7, 100, 170, c);
                g.fillArc(x + 1, y - 2, 9, 10, 100, 170, c);
                break;
            default: break;
        }
    }
    // Righe: icona, voce e valore allineati a sinistra in colonna; ultima riga: satellite, orari e data (senza "Time")
    static final int LOG_ICON_X = 53, LOG_LABEL_X = 65, LOG_VALUE_X = 221;
    static void logRows(G g, String[] labels, String[] values, int firstY, int stepY) {
        for (int i = 0; i < 8; i++) {
            final int y = firstY + i * stepY;
            logIcon(g, i, LOG_ICON_X, y, G.YELLOW);
            g.setFont(G.F_B9); g.setTextSize(1.1f); g.setTextDatum(G.ML);
            g.setTextColor(G.GREEN); g.drawString(labels[i], LOG_LABEL_X, y);
            g.setTextColor(G.WHITE); g.drawString(values[i], LOG_VALUE_X, y);
        }
        final int yt = firstY + 8 * stepY;
        logIcon(g, 8, LOG_ICON_X, yt, G.YELLOW);
        g.setFont(G.F_B9); g.setTextSize(1.05f); g.setTextDatum(G.ML); g.setTextColor(G.WHITE);
        g.drawString(values[8], LOG_LABEL_X, yt);
    }
    static final String[] LOG_LABELS = {"Flight Time", "Km travelled", "Approx Fuel", "Max GPS GS", "Max Altitude",
            "Max Climb rate", "Temp", "Humidity", "Time"};
    static void flightLog(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("FLIGHT LOG", 180, 58, G.MC, G.CYAN, 1f);
        final String[] v = {
                FlightData.fmtDuration(d.flightElapsedMs()),
                String.format(Locale.ROOT, "%.1f km", d.flightDistKm),
                d.flightFuelUsedL >= 0 ? String.format(Locale.ROOT, "%.1f l", d.flightFuelUsedL) : "-- l",
                String.format(Locale.ROOT, "%.0f km/h", d.flightMaxKmh),
                String.format(Locale.ROOT, "%.0f m", d.flightMaxAltM),
                String.format(Locale.ROOT, "%.1f m/s", d.flightMaxClimb),
                d.meteoValid ? String.format(Locale.ROOT, "%.0fC", d.oatC()) : "--C",
                d.meteoValid ? String.format(Locale.ROOT, "%.0f%%", d.rhPct()) : "--%",
                hm(d.flightStartMs) + "/" + (d.flying ? "--:--" : hm(d.flightEndMs)) + "  "
                        + (d.flightStartMs > 0 ? new SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).format(new Date(d.flightStartMs)) : "--/--/----")};
        logRows(g, LOG_LABELS, v, 87, 26);
        g.drawRect(110, 318 - 14, 140, 28, G.YELLOW);
        g.setFont(G.F_B9); g.setTextDatum(G.MC); g.setTextColor(G.YELLOW);
        g.drawString("SAVED LOGS", 180, 318);
    }
    static void savedLog(G g, FlightData d, int index) {
        g.fillScreen(G.BLACK);
        if (d.logs.isEmpty()) {
            g.ui("LOGS", 180, 25, G.MC, G.CYAN, 1f);
            g.setFont(G.F_B12); g.setTextDatum(G.MC); g.setTextColor(G.YELLOW);
            g.drawString("NO FLIGHT DATA", 180, 170);
            return;
        }
        index = Math.max(0, Math.min(d.logs.size() - 1, index));
        final FlightData.LogEntry e = d.logs.get(index);
        g.ui("LOGS", 180, 25, G.MC, G.CYAN, 1f);
        final String date = new SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).format(new Date(e.startMs));
        final String[] v = {
                FlightData.fmtDuration(e.durMs),
                String.format(Locale.ROOT, "%.1f km", e.distKm),
                e.fuelUsedL >= 0 ? String.format(Locale.ROOT, "%.1f l", e.fuelUsedL) : "-- l",
                String.format(Locale.ROOT, "%.0f km/h", e.maxKmh),
                String.format(Locale.ROOT, "%.0f m", e.maxAltM),
                String.format(Locale.ROOT, "%.1f m/s", e.maxClimb),
                Float.isNaN(e.endTempC) ? "--C" : String.format(Locale.ROOT, "%.0fC", e.endTempC),
                Float.isNaN(e.endHum) ? "--%" : String.format(Locale.ROOT, "%.0f%%", e.endHum),
                hm(e.startMs) + "/" + hm(e.startMs + e.durMs) + "  " + date};
        logRows(g, LOG_LABELS, v, 64, 25);   // un po' piu' in basso: la prima icona non tocca il bordo
        g.setFont(G.F_B9); g.setTextSize(1f); g.setTextDatum(G.MC); g.setTextColor(G.YELLOW);
        g.drawString("#" + (index + 1) + "/" + d.logs.size(), 110, 315);
        g.setTextColor(G.CYAN);
        g.drawString("Tap to exit", 225, 315);
    }

    // ---------- ICT ----------
    static void ict(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("Instrument", 180, 42, G.MC, G.CYAN, 0.9f);
        g.ui("Check Timer", 180, 70, G.MC, G.CYAN, 0.9f);
        g.num(String.valueOf(d.ictMinutes), 180, 145, G.MC, G.WHITE, 0.9f);
        g.setFont(G.F_B12); g.setTextDatum(G.MC); g.setTextColor(G.WHITE);
        g.drawString("min", 180, 205);
        g.drawRect(25, 220, 90, 55, G.GREEN);
        g.drawRect(245, 220, 90, 55, G.GREEN);
        g.setFont(G.F_B18); g.setTextColor(G.GREEN); g.drawString("-", 70, 247);
        g.setTextColor(G.WHITE); g.drawString("+", 290, 247);
        g.drawRect(85, 290, 190, 45, G.GREEN);
        g.setTextSize(0.9f); g.setTextColor(G.GREEN);
        g.drawString(d.ictOn ? "TIMER: ON" : "TIMER: OFF", 180, 312);
    }
    static void ictAlert(G g) {
        g.fillScreen(G.WHITE);
        g.setFont(G.F_B18); g.setTextDatum(G.MC); g.setTextColor(G.BLACK);
        g.drawString("Check", 180, 125);
        g.drawString("Flight", 180, 165);
        g.drawString("Instruments", 180, 205);
    }

    // ---------- MANUAL FLIGHT TIMER ----------
    static void manualTimer(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("MANUAL", 180, 45, G.MC, G.CYAN, 0.9f);
        g.ui("FLIGHT TIMER", 180, 75, G.MC, G.CYAN, 0.9f);
        timerGroup(g, FlightData.fmtDuration(d.manElapsedMs()), 140, G.WHITE);
        startStopLine(g, "START: " + hm(d.manFirstStartMs), 190);
        startStopLine(g, "STOP:  " + (d.manRunning ? "--:--" : hm(d.manStopMs)), 215);
        g.drawRect(30, 235, 95, 45, G.GREEN);
        g.drawRect(132, 235, 95, 45, G.RED);
        g.drawRect(235, 235, 95, 45, G.ORANGE);
        g.ui("Start", 77, 257, G.MC, G.GREEN, 0.92f);
        g.ui("Stop", 179, 257, G.MC, G.RED, 0.92f);
        g.ui("Reset", 282, 257, G.MC, G.ORANGE, 0.92f);
        g.ui(d.manRunning ? "MANUAL: RUNNING" : "MANUAL: STOPPED", 180, 298, G.MC, d.manRunning ? G.GREEN : G.RED, 0.8f);
    }

    // ---------- FUEL ESTIMATE ----------
    static final int FUEL_ARC_R = 169, FUEL_ARC_HALF = 10;
    private static void cap(G g, float frac, int c) {
        final double a = Math.toRadians(135 + 270 * Math.max(0, Math.min(1, frac)));
        g.fillCircle(180 + (float) (FUEL_ARC_R * Math.cos(a)), 180 + (float) (FUEL_ARC_R * Math.sin(a)), FUEL_ARC_HALF, c);
    }
    private static void approx(G g, float cx, float cy, float w, float amp, float gapY, float thick, int c) {
        for (int row = 0; row < 2; row++) {
            final float yc = cy + (row == 0 ? -gapY / 2 : gapY / 2);
            float px = cx - w / 2, py = yc;
            for (int k = 1; k <= 12; k++) {
                final float t = k / 12f, x = cx - w / 2 + t * w, y = yc - amp * (float) Math.sin(t * 2 * Math.PI);
                g.thickLine(px, py, x, y, c, thick);
                px = x; py = y;
            }
        }
    }
    static void fuel(G g, FlightData d, boolean alert) {
        final int grey = G.color565(170, 170, 170), dark = G.color565(51, 51, 51), red = G.RED;
        final float liters = d.fuelLiters, resL = d.fuelReserveL();
        final boolean inReserve = liters <= resL + 0.01f;
        final int arcColor = inReserve ? red : G.GREEN;
        final float frac = Math.max(0, Math.min(1, liters / d.fuelTankL));
        g.fillScreen(G.BLACK);
        if (alert) { g.drawCircle(180, 180, 179, red); g.drawCircle(180, 180, 178, red); g.drawCircle(180, 180, 177, red); }
        final int rIn = FUEL_ARC_R - FUEL_ARC_HALF, rOut = FUEL_ARC_R + FUEL_ARC_HALF;
        final float resFrac = Math.max(0, Math.min(1, resL / d.fuelTankL));
        MeteoPages.fuelArc(g, rIn, rOut, 0, 1, dark);
        MeteoPages.fuelArc(g, rIn - 7, rIn - 6, 0, 1, G.color565(154, 154, 154));
        final boolean reserveMode = inReserve && (d.flying || alert);
        if (reserveMode) {
            final float rFrac = resL > 0.01f ? Math.max(0, Math.min(1, liters / resL)) : 0;
            cap(g, 0, rFrac > 0.003f ? red : dark);
            cap(g, 1, rFrac > 0.997f ? red : dark);
            if (rFrac > 0.003f) { MeteoPages.fuelArc(g, rIn, rOut, 0, rFrac, red); cap(g, rFrac, red); }
        } else {
            cap(g, 0, frac > 0.003f ? red : dark);
            cap(g, 1, frac > 0.997f ? arcColor : dark);
            if (frac > 0.003f) {
                MeteoPages.fuelArc(g, rIn, rOut, 0, Math.min(frac, resFrac), red);
                if (frac > resFrac) MeteoPages.fuelArc(g, rIn, rOut, resFrac, frac, arcColor);
                cap(g, frac, frac > resFrac ? arcColor : red);
            }
            if (resFrac > 0.003f && resFrac < 0.997f) {
                final double a = Math.toRadians(135 + 270 * resFrac);
                g.thickLine(180 + (float) ((rIn - 1) * Math.cos(a)), 180 + (float) ((rIn - 1) * Math.sin(a)),
                        180 + (float) ((rOut + 1) * Math.cos(a)), 180 + (float) ((rOut + 1) * Math.sin(a)), G.BLACK, 4);
            }
        }
        final double a0 = Math.toRadians(135), a1 = Math.toRadians(45);
        final int rr = FUEL_ARC_R - 3;
        final float rx = 180 + (float) (rr * Math.cos(a0)), ry = 180 + (float) (rr * Math.sin(a0));
        final float fx = 180 + (float) (rr * Math.cos(a1)), fy = 180 + (float) (rr * Math.sin(a1));
        g.fillCircle(rx, ry, 13, G.WHITE); g.fillCircle(fx, fy, 13, G.WHITE);
        g.ui(reserveMode ? "E" : "R", rx, ry + 1, G.MC, red, 0.62f);
        g.ui(reserveMode ? "R" : "F", fx, fy + 1, G.MC, reserveMode ? red : G.BLACK, 0.62f);
        if (!reserveMode) g.ui("FUEL ESTIMATE", 180, 69, G.MC, G.CYAN, 0.72f);
        else if ((SystemClock.uptimeMillis() / 500) % 2 == 0) g.ui("FUEL ESTIMATE", 180, 69, G.MC, red, 0.72f);
        final String num = String.valueOf((int) Math.floor(liters + 0.0001f));
        final int c = inReserve ? red : G.WHITE;
        g.setFontDigits(G.F_NUM80); g.setTextSize(1.14f);
        final float wN = Math.min(200, g.textWidth(num));
        final float x0 = 180 - (34 + 12 + wN) / 2;
        approx(g, x0 + 17, 140, 34, 4, 14, 4, c);
        g.num(num, x0 + 34 + 12 + wN / 2, 140, G.MC, c, 1.14f * Math.min(1f, 200f / Math.max(1f, g.textWidth(num))));
        g.ui("liters", 180, 196, G.MC, grey, 0.5f);
        final int totMin = (int) (d.fuelRateLph > 0.1f ? liters / d.fuelRateLph * 60f : 0);
        final String t = String.format(Locale.ROOT, "%dh %02dm", totMin / 60, totMin % 60);
        final int c2 = inReserve ? red : FUEL_GOLD;
        g.setFont(G.F_UI32); g.setTextSize(1.1f);
        final float wT = g.textWidth(t), x1 = 180 - (22 + 9 + wT) / 2;
        approx(g, x1 + 11, 230, 22, 3, 9, 3, c2);
        g.ui(t, x1 + 22 + 9 + wT / 2, 230, G.MC, c2, 1.1f);
        g.ui("endurance", 180, 257, G.MC, grey, 0.42f);
        if (alert || inReserve) {
            g.fillRoundRect(108, 270, 144, 39, 9, red);
            g.ui("RESERVE", 180, 289, G.MC, G.BLACK, 0.72f);
            if (d.gpsValid && d.homeSet) {
                final double km = FlightData.distanceKm(d.lat, d.lon, d.homeLat, d.homeLon);
                String s = String.format(Locale.ROOT, "HOME %.0f km", km);
                if (d.speedKmh > 10) { final int m = (int) (km / d.speedKmh * 60); s += String.format(Locale.ROOT, " - %dh %02dm", m / 60, m % 60); }
                g.ui(s, 180, 326, G.MC, FUEL_GOLD, 0.42f);
            } else if (alert) g.ui("Tap to close", 180, 326, G.MC, grey, 0.42f);
        } else {
            g.drawRoundRect(108, 270, 144, 39, 9, G.color565(85, 85, 85));
            g.drawRoundRect(109, 271, 142, 37, 8, G.color565(85, 85, 85));
            g.ui(String.format(Locale.ROOT, "%.1f l/h", d.fuelRateLph), 180, 289, G.MC, G.WHITE, 0.68f);
        }
        if (d.demo) g.ui("DEMO", 180, 344, G.MC, grey, 0.38f);
    }

    // ---------- GPS INFO ----------
    static void gpsInfo(G g, FlightData d, boolean hasBaro) {
        g.fillScreen(G.BLACK);
        g.ui("GPS INFO", 180, 42, G.MC, G.CYAN, 1f);
        g.drawLine(20, 66, 340, 66, G.DARKGREY);
        g.setFont(G.F_B12); g.setTextDatum(G.ML); g.setTextColor(G.WHITE);
        g.drawString("FIX:", 40, 95);
        g.drawString("QUALITY:", 40, 125);
        g.drawString("SATS:", 40, 155);
        g.setTextDatum(G.MR);
        g.setTextColor(d.gpsValid ? G.GREEN : G.RED);
        g.drawString(d.gpsValid ? "3D FIX" : "NO FIX", 330, 95);
        g.setTextColor(G.CYAN);
        g.drawString(d.gpsValid ? (d.satsUsed >= 4 ? "GPS fix" : "fix") : "Invalid", 330, 125);
        g.setTextColor(d.satsUsed >= 6 ? G.GREEN : (d.satsUsed >= 4 ? G.YELLOW : G.RED));
        g.drawString(String.valueOf(d.gpsValid ? d.satsUsed : 0), 330, 155);
        g.setFont(G.F_B9); g.setTextSize(1.05f); g.setTextDatum(G.MC); g.setTextColor(G.WHITE);
        g.drawString("Constellations:", 180, 185);
        final int m = d.constellations;
        final int on = G.GREEN, off = G.DARKGREY;
        g.setTextColor((m & 1) != 0 ? on : off); g.drawString("GPS", 90, 210);
        g.setTextColor((m & 2) != 0 ? on : off); g.drawString("GLONASS", 250, 210);
        g.setTextColor((m & 4) != 0 ? on : off); g.drawString("Galileo", 90, 235);
        g.setTextColor((m & 8) != 0 ? on : off); g.drawString("BDS", 250, 235);
        g.setTextColor((m & 16) != 0 ? on : off); g.drawString("QZSS", 90, 260);
        final Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        g.setFont(G.F_B12); g.setTextColor(G.WHITE);
        g.drawString(d.gpsValid ? String.format(Locale.ROOT, "UTC %02d:%02d:%02d", utc.get(Calendar.HOUR_OF_DAY),
                utc.get(Calendar.MINUTE), utc.get(Calendar.SECOND)) : "UTC --:--:--", 180, 292);
        g.setFont(G.F_B9);
        g.setTextColor(hasBaro ? (d.baroValid ? G.GREEN : G.YELLOW) : G.RED);
        g.drawString(hasBaro ? (d.baroValid ? String.format(Locale.ROOT, "BARO %.1f hPa", d.pressureHpa) : "BARO ...") : "NO BARO: GPS ALT", 180, 322);
    }
}
