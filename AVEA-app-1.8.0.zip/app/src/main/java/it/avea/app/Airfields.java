package it.avea.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Elenco dei campi di volo, letto da un file XCSoar .cup (come la pagina "Waypoints" dello strumento):
 * si tengono solo i campi (style 2 erba, 3 aviosuperficie/ULM, 4 volo a vela, 5 pista dura).
 * Il file si scarica dal sito ufficiale XCSoar oppure si sceglie dal telefono; una copia resta nell'app.
 */
public class Airfields {

    public static final String URL_ITALIA = "https://download.xcsoar.org/content/waypoint/country/IT-WPT-National-XCSoar.cup";
    /** copia dello stesso file sul repository XCSoar (se il primo sito non risponde) */
    public static final String URL_ITALIA_2 = "https://raw.githubusercontent.com/XCSoar/xcsoar-data-content/master/data/content/waypoint/country/IT-WPT-National-XCSoar.cup";

    public static class Field {
        public String name;
        public double lat, lon;
        public int rwyDeg = -1;      // direzione pista (gradi), -1 se sconosciuta
        public int rwyLenM = 0;
        public String freq = "";
        public String rwyText() {
            if (rwyDeg < 0) return "";
            int a = (int) Math.round(rwyDeg / 10.0);
            if (a == 0) a = 36;
            int b = a > 18 ? a - 18 : a + 18;
            int lo = Math.min(a, b), hi = Math.max(a, b);
            return String.format(Locale.ROOT, "%02d/%02d", lo, hi);
        }
    }

    private final List<Field> list = new ArrayList<>();
    private final File cacheFile;

    public Airfields(File dir) {
        cacheFile = new File(dir, "waypoints.cup");
    }

    public synchronized int size() { return list.size(); }
    public synchronized Field get(int i) { return list.get(i); }

    /** All'avvio: rilegge la copia salvata. */
    public synchronized boolean loadCache() {
        if (!cacheFile.exists()) return false;
        try (InputStream in = new FileInputStream(cacheFile)) {
            return parse(in) > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** Legge un .cup (dal telefono o da internet), lo salva come copia e ritorna il numero di campi. */

    /**
     * Dotazione di serie: se non c'e' ancora nessuna copia salvata, legge i campi di volo
     * inclusi nell'APK. Cosi' l'app funziona appena installata, senza scaricare niente.
     * Al primo aggiornamento scaricato dall'utente la copia salvata prende il posto di questa.
     */
    public synchronized boolean loadDefault(android.content.res.AssetManager am) {
        if (!list.isEmpty()) return true;
        try (InputStream in = am.open("data/waypoints_it.cup")) { return parse(in) > 0; }
        catch (Exception e) { return false; }
    }

    public int importStream(InputStream in) throws Exception {
        final File tmp = new File(cacheFile.getPath() + ".tmp");
        try (OutputStream out = new FileOutputStream(tmp)) {
            final byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        int count;
        try (InputStream again = new FileInputStream(tmp)) {
            synchronized (this) { count = parse(again); }
        }
        if (count > 0) {
            if (!tmp.renameTo(cacheFile)) { cacheFile.delete(); tmp.renameTo(cacheFile); }
        } else {
            tmp.delete();
            loadCache();   // file non valido: si torna all'elenco di prima
        }
        return count;
    }

    /** Scarica l'elenco ufficiale XCSoar dell'Italia (da chiamare fuori dal thread principale). */
    public int download(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "AVEA-app");
        final int code = c.getResponseCode();
        if (code >= 300 && code < 400) {          // redirect verso un altro protocollo: lo seguiamo a mano
            final String loc = c.getHeaderField("Location");
            c.disconnect();
            if (loc == null) throw new java.io.IOException("redirect");
            return download(new URL(new URL(url), loc).toString());
        }
        if (code != 200) { c.disconnect(); throw new java.io.IOException("HTTP " + code); }
        try (InputStream in = c.getInputStream()) {
            return importStream(in);
        } finally {
            c.disconnect();
        }
    }

    // ---------- lettura del .cup ----------
    private int parse(InputStream in) throws Exception {
        final List<Field> out = new ArrayList<>();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        String line;
        int cName = 0, cLat = 3, cLon = 4, cStyle = 6, cRwDir = 7, cRwLen = 8, cFreq = 9;
        boolean header = true;
        while ((line = r.readLine()) != null) {
            if (line.startsWith("﻿")) line = line.substring(1);
            if (line.trim().isEmpty()) continue;
            if (line.startsWith("-----")) break;          // dopo questa riga ci sono i task, non i punti
            List<String> f = splitCsv(line);
            if (header) {
                header = false;
                if (f.size() > 0 && f.get(0).trim().equalsIgnoreCase("name")) {
                    for (int k = 0; k < f.size(); k++) {
                        final String h = f.get(k).trim().toLowerCase(Locale.ROOT);
                        if (h.equals("name")) cName = k;
                        else if (h.equals("lat")) cLat = k;
                        else if (h.equals("lon")) cLon = k;
                        else if (h.equals("style")) cStyle = k;
                        else if (h.equals("rwdir")) cRwDir = k;
                        else if (h.equals("rwlen")) cRwLen = k;
                        else if (h.equals("freq")) cFreq = k;
                    }
                    continue;
                }
            }
            if (f.size() <= Math.max(cLat, Math.max(cLon, cStyle))) continue;
            int style;
            try { style = Integer.parseInt(f.get(cStyle).trim()); } catch (Exception e) { continue; }
            if (style < 2 || style > 5) continue;
            final double la = parseCoord(f.get(cLat)), lo = parseCoord(f.get(cLon));
            if (Double.isNaN(la) || Double.isNaN(lo)) continue;
            Field fd = new Field();
            fd.name = f.get(cName).trim().toUpperCase(Locale.ROOT);
            fd.lat = la; fd.lon = lo;
            if (cRwDir < f.size()) { try { fd.rwyDeg = Integer.parseInt(f.get(cRwDir).trim()) % 180; } catch (Exception ignored) { } }
            if (cRwLen < f.size()) fd.rwyLenM = parseLen(f.get(cRwLen));
            if (cFreq < f.size()) fd.freq = f.get(cFreq).trim();
            out.add(fd);
        }
        if (!out.isEmpty()) { list.clear(); list.addAll(out); }
        return out.size();
    }

    /** "4527.050N" / "00916.600E" -> gradi decimali */
    static double parseCoord(String s) {
        s = s.trim();
        if (s.length() < 4) return Double.NaN;
        final char h = Character.toUpperCase(s.charAt(s.length() - 1));
        final String num = s.substring(0, s.length() - 1);
        final int dot = num.indexOf('.');
        final int degLen = (dot < 0 ? num.length() : dot) - 2;
        if (degLen < 1) return Double.NaN;
        try {
            final double deg = Double.parseDouble(num.substring(0, degLen));
            final double min = Double.parseDouble(num.substring(degLen));
            double v = deg + min / 60.0;
            if (h == 'S' || h == 'W') v = -v;
            else if (h != 'N' && h != 'E') return Double.NaN;
            return v;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    /** "1080m", "1080.0m", "3500ft", "0.6nm" -> metri */
    static int parseLen(String s) {
        s = s.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return 0;
        double k = 1.0;
        if (s.endsWith("ft")) { k = 0.3048; s = s.substring(0, s.length() - 2); }
        else if (s.endsWith("nm")) { k = 1852; s = s.substring(0, s.length() - 2); }
        else if (s.endsWith("ml")) { k = 1609.34; s = s.substring(0, s.length() - 2); }
        else if (s.endsWith("m")) { s = s.substring(0, s.length() - 1); }
        try { return (int) Math.round(Double.parseDouble(s) * k); } catch (Exception e) { return 0; }
    }

    static List<String> splitCsv(String line) {
        final List<String> out = new ArrayList<>();
        final StringBuilder sb = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < line.length(); i++) {
            final char ch = line.charAt(i);
            if (ch == '"') q = !q;
            else if (ch == ',' && !q) { out.add(sb.toString()); sb.setLength(0); }
            else sb.append(ch);
        }
        out.add(sb.toString());
        return out;
    }

    // ---------- ricerche ----------
    /** Indici dei campi piu' vicini, dal piu' vicino. */
    public synchronized int[] nearest(double lat, double lon, int n) {
        final int sz = list.size();
        final int k = Math.min(n, sz);
        final int[] idx = new int[k];
        final double[] dist = new double[k];
        Arrays.fill(dist, Double.MAX_VALUE);
        Arrays.fill(idx, -1);
        for (int i = 0; i < sz; i++) {
            final Field f = list.get(i);
            final double d = fastDist(lat, lon, f.lat, f.lon);
            if (k == 0 || d >= dist[k - 1]) continue;
            int j = k - 1;
            while (j > 0 && dist[j - 1] > d) { dist[j] = dist[j - 1]; idx[j] = idx[j - 1]; j--; }
            dist[j] = d; idx[j] = i;
        }
        int valid = 0;
        while (valid < k && idx[valid] >= 0) valid++;
        return Arrays.copyOf(idx, valid);
    }

    /** Campi entro un raggio (km), per la mappa. */
    public synchronized List<Integer> within(double lat, double lon, double km) {
        final List<Integer> out = new ArrayList<>();
        final double dLat = km / 111.0, dLon = km / (111.0 * Math.max(0.2, Math.cos(Math.toRadians(lat))));
        for (int i = 0; i < list.size(); i++) {
            final Field f = list.get(i);
            if (Math.abs(f.lat - lat) > dLat || Math.abs(f.lon - lon) > dLon) continue;
            out.add(i);
        }
        return out;
    }

    /** Ricerca per nome (lettere scritte con la tastiera): prima i nomi che iniziano cosi'. */
    public synchronized List<Integer> search(String q, double lat, double lon, boolean haveFix, int max) {
        final List<Integer> starts = new ArrayList<>(), contains = new ArrayList<>();
        final String u = q.toUpperCase(Locale.ROOT);
        for (int i = 0; i < list.size(); i++) {
            final String nm = list.get(i).name;
            if (nm.startsWith(u)) starts.add(i);
            else if (nm.contains(u)) contains.add(i);
        }
        if (haveFix) {
            final java.util.Comparator<Integer> byDist = (a, b) -> Double.compare(
                    fastDist(lat, lon, list.get(a).lat, list.get(a).lon), fastDist(lat, lon, list.get(b).lat, list.get(b).lon));
            starts.sort(byDist);
            contains.sort(byDist);
        }
        starts.addAll(contains);
        return starts.size() > max ? new ArrayList<>(starts.subList(0, max)) : starts;
    }

    private static double fastDist(double la1, double lo1, double la2, double lo2) {
        final double x = (lo2 - lo1) * Math.cos(Math.toRadians((la1 + la2) / 2));
        final double y = la2 - la1;
        return x * x + y * y;
    }
}
