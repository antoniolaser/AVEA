package it.avea.app;

import android.os.SystemClock;

import java.util.Locale;

/**
 * Pagine meteo copiate dal firmware: SENSOR Dashboard, AIR DATA, DENSITY ALTITUDE, CARB ICE RISK, VISIBILITY.
 * Temperatura e umidita' arrivano dal meteo su internet (Open-Meteo) riportate alla quota attuale.
 */
public class MeteoPages {

    static final int DA_WARN_FT = 2000, DA_HIGH_FT = 3500, DA_SCALE_MAX_FT = 5000;
    static final int BOX_BG = 0x0841;

    // ---------- formule del firmware ----------
    static float dewPoint(float t, float h) {
        if (Float.isNaN(t) || Float.isNaN(h) || h <= 0 || h > 100 || t <= -60 || t >= 60) return Float.NaN;
        final float a = 17.27f, b = 237.7f;
        final float gamma = (a * t) / (b + t) + (float) Math.log(h / 100.0);
        return (b * gamma) / (a - gamma);
    }
    static float cloudBase(float t, float dew) {
        if (Float.isNaN(t) || Float.isNaN(dew) || dew > t) return Float.NaN;
        return Math.max(0f, (t - dew) * 125f);
    }
    static float densityAltitude(float tC, float qnh, float altM) {
        if (Float.isNaN(tC) || Float.isNaN(altM) || qnh < 800 || qnh > 1100) return Float.NaN;
        final float pa = altM * 3.28084f + 27f * (1013.25f - qnh);
        final float isa = 15f - 2f * (pa / 1000f);
        return pa + 120f * (tC - isa);
    }
    static int carbIceRisk(float t, float h) {
        if (Float.isNaN(t) || Float.isNaN(h)) return 0;
        if (t < -10 || t > 38 || h < 50) return 0;
        if (t <= 22 && h >= 80) return 2;
        if (t <= 30 && h >= 50) return 1;
        return 0;
    }
    static boolean hazePossible(float t, float dew) {
        if (Float.isNaN(t) || Float.isNaN(dew)) return false;
        final float s = t - dew;
        return s > 4 && s <= 8;
    }
    static int fogRisk(float t, float dew) {
        if (Float.isNaN(t) || Float.isNaN(dew)) return 0;
        final float s = t - dew;
        return s <= 2 ? 2 : (s <= 4 ? 1 : 0);
    }

    // ---------- disegni comuni ----------
    private static void invalid(G g, String msg) {
        g.setTextDatum(G.MC);
        g.setFont(G.F_B18); g.setTextColor(G.RED);
        g.drawString(msg, 180, 175);
        g.setFont(G.F_B9);
        g.drawString("CHECK SENSOR / DATA", 180, 220);
    }
    private static String meteoMissing(FlightData d) {
        return d.meteoStatus == null ? "METEO INVALID" : d.meteoStatus;
    }
    /** Arco 0..1 da 135 a 405 gradi (come fuelArc del firmware). */
    static void fuelArc(G g, float rIn, float rOut, float f0, float f1, int c) {
        final float a0 = 135f + 270f * Math.max(0, Math.min(1, f0)), a1 = 135f + 270f * Math.max(0, Math.min(1, f1));
        if (a1 - a0 < 0.3f) return;
        g.fillArc(180, 180, rIn, rOut, a0, a1, c);
    }
    private static void arcDot(G g, float frac) {
        final double ang = Math.toRadians(135 + 270 * Math.max(0, Math.min(1, frac)));
        final float x = 180 + (float) (160 * Math.cos(ang)), y = 180 + (float) (160 * Math.sin(ang));
        g.fillCircle(x, y, 12, G.BLACK);
        g.fillCircle(x, y, 9, G.WHITE);
    }
    private static void bigDegrees(G g, float v, float y) {
        g.ui(String.format(Locale.ROOT, "%.0f", v), 172, y, G.MR, G.WHITE, 1.5f);
        g.fillCircle(184, y - 17, 5, G.WHITE); g.fillCircle(184, y - 17, 2, G.BLACK);
        g.ui("C", 194, y, G.ML, G.WHITE, 1.5f);
    }
    private static void box(G g, String l1, String l2, int x, int w) {
        g.fillRoundRect(x, 240, w, 62, 8, BOX_BG);
        g.drawRoundRect(x, 240, w, 62, 8, G.WHITE);
        g.ui(l1, 180, 259, G.MC, G.WHITE, l1.length() > 19 ? 0.5f : 0.55f);
        g.ui(l2, 180, 284, G.MC, G.WHITE, 0.5f);
    }
    private static boolean blinkOn() { return (SystemClock.uptimeMillis() / 500) % 2 == 0; }
    private static void snowflake(G g, float x, float y, float r, int c) {
        for (int k = 0; k < 3; k++) {
            final double a = k * Math.PI / 3;
            final float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            g.drawWideLine(x - r * ca, y - r * sa, x + r * ca, y + r * sa, 1.6f, c);
            for (int sd = -1; sd <= 1; sd += 2) {
                final float bx = x + sd * r * 0.55f * ca, by = y + sd * r * 0.55f * sa;
                for (int t = -1; t <= 1; t += 2) {
                    final double b = a + t * 0.785;
                    g.drawWideLine(bx, by, bx + sd * r * 0.35f * (float) Math.cos(b), by + sd * r * 0.35f * (float) Math.sin(b), 1.4f, c);
                }
            }
        }
    }
    private static void visIcon(G g, int kind, float x, float y, int c) {
        if (kind == 0) {
            g.fillCircle(x, y, 7, c);
            for (int k = 0; k < 8; k++) {
                final double a = k * 0.785;
                g.drawWideLine(x + 11 * (float) Math.cos(a), y + 11 * (float) Math.sin(a), x + 15 * (float) Math.cos(a), y + 15 * (float) Math.sin(a), 1.5f, c);
            }
        } else if (kind == 1) {
            g.fillArc(x, y - 3, 7, 10, 180, 360, c);
            g.drawWideLine(x - 15, y + 4, x + 15, y + 4, 1.5f, c);
            g.drawWideLine(x - 15, y + 10, x + 15, y + 10, 1.5f, c);
        } else if (kind == 2) {
            g.fillArc(x - 6, y + 2, 5, 8, 90, 270, c);
            g.fillArc(x + 1, y - 4, 7, 10, 180, 360, c);
            g.fillArc(x + 9, y + 2, 5, 8, 270, 450, c);
            g.drawWideLine(x - 12, y + 15, x + 12, y + 15, 1.5f, c);
        } else {
            g.drawWideLine(x - 16, y - 8, x + 16, y - 8, 1.5f, c);
            g.drawWideLine(x - 12, y, x + 12, y, 1.5f, c);
            g.drawWideLine(x - 16, y + 8, x + 16, y + 8, 1.5f, c);
        }
    }

    // ---------- SENSOR Dashboard ----------
    static void sensor(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("SENSOR", 180, 42, G.MC, G.CYAN, 0.9f);
        g.ui("Dashboard", 180, 72, G.MC, G.CYAN, 0.9f);
        g.drawRect(85, 275, 190, 45, G.YELLOW);
        g.ui("AIR DATA", 180, 298, G.MC, G.YELLOW, 0.82f);
        if (!d.meteoValid) { invalid(g, meteoMissing(d)); return; }
        final float t = d.oatC(), h = d.rhPct();
        final String ts = String.valueOf(Math.round(t));
        final float numScale = 1.02f, ratio = numScale / 0.85f;
        final float w = g.num(ts, 180, 155, G.MC, G.WHITE, numScale);
        final float degY = 155 - 30f * ratio, degX = 180 + w / 2 + 14f * ratio;
        g.drawCircle(degX, degY, 5f * ratio, G.YELLOW);
        g.drawCircle(degX, degY, 4f * ratio, G.YELLOW);
        g.setFont(G.F_B12); g.setTextSize(1.43f); g.setTextDatum(G.MC); g.setTextColor(G.CYAN);
        g.drawString("Humidity", 135, 235);
        g.num(String.valueOf(Math.round(h)), 252, 235, G.MC, G.CYAN, 0.546f);
        g.setFont(G.F_UI24); g.setTextSize(1.04f); g.setTextDatum(G.MC); g.setTextColor(G.CYAN);
        g.drawString("%", 301, 235);
        g.ui(d.meteoSourceLine(), 180, 336, G.MC, G.DARKGREY, 0.36f);
        oatArc(g, t);   // arco a zone a sinistra con l'indice sulla temperatura
    }

    // ---------- arco laterale della SENSOR Dashboard (come il firmware senza sonda esterna) ----------
    // Scala -20..+40 C dal basso in alto, sfumata: un colore ogni 5 gradi (dal viola scuro al bordeaux).
    static final int Z_BLUE = G.color565(47, 125, 255), Z_CYAN = G.color565(0, 216, 255), Z_GREEN = G.color565(34, 212, 106),
            Z_ORANGE = G.color565(255, 144, 32), Z_RED = G.color565(255, 48, 48);
    private static float oatFrac(float t) { return Math.max(0f, Math.min(1f, (t + 20f) / 60f)); }
    private static float oatAng(float t) { return 130f + 100f * oatFrac(t); }   // gradi Android: 130 in basso, 230 in alto
    private static float px(float r, float a) { return 180f + r * (float) Math.cos(Math.toRadians(a)); }
    private static float py(float r, float a) { return 180f + r * (float) Math.sin(Math.toRadians(a)); }
    private static final int[][] OAT_SCALE = {{74, 20, 140}, {26, 35, 126}, {13, 71, 161}, {25, 118, 210}, {0, 172, 193},
            {38, 166, 154}, {102, 187, 106}, {212, 225, 87}, {255, 238, 88}, {255, 167, 38}, {245, 124, 0}, {229, 57, 53}, {142, 0, 0}};
    static int oatGrad(float t) {
        t = Math.max(-20f, Math.min(40f, t));
        int i = Math.min(11, (int) ((t + 20f) / 5f));
        final float f = (t - (-20f + 5f * i)) / 5f;
        final int[] a = OAT_SCALE[i], b = OAT_SCALE[i + 1];
        return G.color565(Math.round(a[0] + (b[0] - a[0]) * f), Math.round(a[1] + (b[1] - a[1]) * f), Math.round(a[2] + (b[2] - a[2]) * f));
    }
    static void oatArc(G g, float t) {
        final float rIn = 162f, rOut = 177.5f;
        for (int i = 0; i < 120; i++) {   // un tratto ogni mezzo grado, sovrapposto al successivo per non lasciare righe
            final float t0 = -20f + i * 0.5f;
            g.fillArc(180, 180, rIn, rOut, oatAng(t0), oatAng(t0 + 0.5f) + (i < 119 ? 0.8f : 0f), oatGrad(t0 + 0.25f));
        }
        g.setFont(G.F_B9); g.setTextSize(1f); g.setTextDatum(G.MC); g.setTextColor(G.LIGHTGREY);
        for (float m : new float[]{0f, 20f}) {
            final float a = oatAng(m);
            g.drawWideLine(px(rIn - 1, a), py(rIn - 1, a), px(rOut + 1, a), py(rOut + 1, a), 0.9f, G.BLACK);
            g.drawString(m == 0f ? "0" : "20", px(132, a), py(132, a));
        }
        final float a = oatAng(t), d = 4.5f;
        g.fillTriangle(px(rIn - 2, a), py(rIn - 2, a), px(rIn - 16, a - d), py(rIn - 16, a - d), px(rIn - 16, a + d), py(rIn - 16, a + d), G.WHITE);
    }

    // ---------- AIR DATA ----------
    static final int[] AIR_LABEL_Y = {104, 179, 254};
    static void airData(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("AIR DATA", 180, 45, G.MC, G.CYAN, 1f);
        g.setFont(G.F_B9); g.setTextSize(1.04f); g.setTextDatum(G.MC); g.setTextColor(G.YELLOW);
        g.drawString("ESTIMATE (indicative risk)", 180, 72);
        if (!d.baroValid || !d.meteoValid) { invalid(g, !d.baroValid ? "ALT INVALID" : meteoMissing(d)); return; }
        g.setFont(G.F_B9); g.setTextSize(1.4f); g.setTextColor(G.CYAN);
        g.drawString("Dew Point", 180, AIR_LABEL_Y[0]);
        g.drawString("Cloud Base AGL", 180, AIR_LABEL_Y[1]);
        g.drawString("Density Altitude", 180, AIR_LABEL_Y[2]);
        final float t = d.oatC(), h = d.rhPct();
        final float dew = dewPoint(t, h), cb = cloudBase(t, dew), da = densityAltitude(t, d.qnhHpa, d.altM);
        g.setFont(G.F_B12); g.setTextSize(1.45f); g.setTextColor(G.WHITE);
        g.drawString((Float.isNaN(dew) ? 0 : Math.round(dew)) + " C", 180, AIR_LABEL_Y[0] + 33);
        g.drawString((Float.isNaN(cb) ? 0 : Math.round(cb)) + " m", 180, AIR_LABEL_Y[1] + 33);
        g.drawString((Float.isNaN(da) ? 0 : Math.round(da)) + " ft", 180, AIR_LABEL_Y[2] + 33);
    }

    // ---------- DENSITY ALTITUDE ----------
    private static float daScaleFrac(float diff) {
        if (diff <= 0) return 0;
        if (diff < DA_WARN_FT) return diff / DA_WARN_FT / 3f;
        if (diff < DA_HIGH_FT) return 1f / 3f + (diff - DA_WARN_FT) / (float) (DA_HIGH_FT - DA_WARN_FT) / 3f;
        return Math.min(1f, 2f / 3f + (diff - DA_HIGH_FT) / (float) (DA_SCALE_MAX_FT - DA_HIGH_FT) / 3f);
    }
    static void densityAlt(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        final boolean ok = d.baroValid && d.meteoValid;
        final float tC = ok ? d.oatC() : Float.NaN;
        final float daFt = ok ? densityAltitude(tC, d.qnhHpa, d.altM) : Float.NaN;
        final float fieldFt = d.qfeSet ? d.qfeRefM * 3.28084f : d.altM * 3.28084f;
        final float diff = Float.isNaN(daFt) ? 0 : daFt - fieldFt;
        final int level = diff >= DA_HIGH_FT ? 2 : (diff >= DA_WARN_FT ? 1 : 0);
        final int cl = level == 2 ? G.RED : (level == 1 ? G.ORANGE : G.GREEN);
        fuelArc(g, 153, 167, 0, 1f / 3f, G.GREEN);
        fuelArc(g, 153, 167, 1f / 3f, 2f / 3f, G.ORANGE);
        fuelArc(g, 153, 167, 2f / 3f, 1, G.RED);
        fuelArc(g, 146, 147, 0, 1, G.color565(154, 154, 154));
        if (ok && !Float.isNaN(daFt)) g.fillArc(180, 180, 172, 179, 0, 360, cl);   // bordo sempre, del colore del livello
        g.ui("DENSITY", 180, 74, G.MC, G.CYAN, 0.75f);
        g.ui("ALTITUDE", 180, 98, G.MC, G.CYAN, 0.75f);
        if (!ok || Float.isNaN(daFt)) { g.ui(!d.baroValid ? "ALT INVALID" : meteoMissing(d), 180, 180, G.MC, G.RED, 0.9f); return; }
        arcDot(g, daScaleFrac(diff));
        g.ui(Math.round(daFt) + " ft", 180, 140, G.MC, G.WHITE, 1.5f);
        g.ui(String.format(Locale.ROOT, "%+d ft over field", Math.round(diff)), 180, 180, G.MC, cl, 0.65f);
        if (level < 2 || blinkOn())
            g.ui(level == 2 ? "MUCH LONGER TAKE-OFF" : (level == 1 ? "LONGER TAKE-OFF" : "NORMAL"), 180, 212, G.MC, cl, level == 2 ? 0.68f : 0.8f);
        g.fillRoundRect(80, 240, 200, 62, 8, BOX_BG);   // stesso riquadro di VISIBILITY e CARB ICE
        g.drawRoundRect(80, 240, 200, 62, 8, G.WHITE);
        g.ui("Take-off roll +" + (diff > 0 ? Math.round(diff / 1000f * 10f) : 0) + " %", 180, 259, G.MC, G.WHITE, 0.55f);
        g.ui(String.format(Locale.ROOT, "TEMP %.0f C - QNH %.0f", tC, d.qnhHpa), 180, 284, G.MC, G.WHITE, 0.5f);
    }
    /** Livello DA (0, 1, 2) per l'avviso all'avvio, -1 se non calcolabile. */
    static int daLevel(FlightData d) {
        if (!d.baroValid || !d.meteoValid) return -1;
        final float da = densityAltitude(d.oatC(), d.qnhHpa, d.altM);
        if (Float.isNaN(da)) return -1;
        final float diff = da - (d.qfeSet ? d.qfeRefM * 3.28084f : d.altM * 3.28084f);
        return diff >= DA_HIGH_FT ? 2 : (diff >= DA_WARN_FT ? 1 : 0);
    }

    // ---------- CARB ICE RISK ----------
    static void carbIce(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        final float temp = d.meteoValid ? d.oatC() : Float.NaN, hum = d.meteoValid ? d.rhPct() : Float.NaN;
        final int level = carbIceRisk(temp, hum);
        final int cl = level >= 2 ? G.RED : (level == 1 ? G.ORANGE : G.GREEN);
        fuelArc(g, 153, 167, 0, 1f / 3f, G.GREEN);
        fuelArc(g, 153, 167, 1f / 3f, 2f / 3f, G.ORANGE);
        fuelArc(g, 153, 167, 2f / 3f, 1, G.RED);
        fuelArc(g, 146, 147, 0, 1, G.color565(154, 154, 154));
        g.fillArc(180, 180, 172, 179, 0, 360, cl);   // bordo sempre, del colore del livello
        final float h = Float.isNaN(hum) ? 0 : hum;
        float frac;
        if (level >= 2) frac = 2f / 3f + Math.max(0.05f, Math.min(0.95f, (h - 80f) / 20f)) / 3f;
        else if (level == 1) frac = 1f / 3f + Math.max(0.05f, Math.min(0.95f, (h - 50f) / 30f)) / 3f;
        else frac = Math.max(0.05f, Math.min(0.95f, h / 50f)) / 3f;
        arcDot(g, frac);
        snowflake(g, 180, 46, 13, cl);
        g.ui("CARB ICE", 180, 76, G.MC, G.CYAN, 0.75f);
        g.ui("RISK", 180, 100, G.MC, G.CYAN, 0.75f);
        if (!Float.isNaN(temp)) bigDegrees(g, temp, 142); else g.ui("--", 180, 142, G.MC, G.WHITE, 1.5f);
        g.ui(Float.isNaN(hum) ? "Humidity -- %" : "Humidity " + Math.round(hum) + " %", 180, 182, G.MC, cl, 0.65f);
        final String st = level >= 2 ? "SERIOUS RISK" : (level == 1 ? "MODERATE RISK" : "NO RISK");
        if (level < 2 || blinkOn()) g.ui(st, 180, 212, G.MC, cl, 0.8f);
        final float dew = dewPoint(temp, hum);
        box(g, level >= 2 ? "Apply carb heat" : (level == 1 ? "Check carb heat" : "No action needed"),
                Float.isNaN(dew) ? "DEW POINT -- C" : String.format(Locale.ROOT, "DEW POINT %.0f C", dew), 80, 200);
    }

    // ---------- VISIBILITY ----------
    static void visibility(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        final float temp = d.meteoValid ? d.oatC() : Float.NaN, hum = d.meteoValid ? d.rhPct() : Float.NaN;
        final float dew = dewPoint(temp, hum);
        final int visLevel = fogRisk(temp, dew);
        final boolean haze = visLevel <= 0 && hazePossible(temp, dew);
        final int state = visLevel >= 2 ? 3 : (visLevel == 1 ? 2 : (haze ? 1 : 0));
        final int cl = state == 3 ? G.RED : (state == 2 ? G.ORANGE : (state == 1 ? G.YELLOW : G.GREEN));
        fuelArc(g, 153, 167, 0, 0.25f, G.GREEN);
        fuelArc(g, 153, 167, 0.25f, 0.5f, G.YELLOW);
        fuelArc(g, 153, 167, 0.5f, 0.75f, G.ORANGE);
        fuelArc(g, 153, 167, 0.75f, 1, G.RED);
        fuelArc(g, 146, 147, 0, 1, G.color565(154, 154, 154));
        g.fillArc(180, 180, 172, 179, 0, 360, cl);   // bordo sempre, del colore dello stato
        final float sp = (!Float.isNaN(temp) && !Float.isNaN(dew)) ? Math.max(0, temp - dew) : 20f;
        float frac;
        if (sp > 8) frac = 0.25f * Math.max(0.03f, Math.min(0.97f, (14f - sp) / 6f));
        else if (sp > 4) frac = 0.25f + 0.25f * (8f - sp) / 4f;
        else if (sp > 2) frac = 0.5f + 0.25f * (4f - sp) / 2f;
        else frac = 0.75f + 0.25f * Math.max(0.03f, Math.min(0.97f, (2f - sp) / 2f));
        arcDot(g, frac);
        visIcon(g, state, 180, 46, cl);
        g.ui("VISIBILITY", 180, 82, G.MC, G.CYAN, 0.75f);
        g.ui("Spread T - dew point", 180, 108, G.MC, G.color565(150, 170, 170), 0.45f);
        if (!Float.isNaN(temp) && !Float.isNaN(dew)) bigDegrees(g, sp, 145); else g.ui("--", 180, 145, G.MC, G.WHITE, 1.5f);
        g.ui(Float.isNaN(hum) ? "Humidity -- %" : "Humidity " + Math.round(hum) + " %", 180, 182, G.MC, cl, 0.65f);
        final String[] ST = {"GOOD VISIBILITY", "HAZE POSSIBLE", "LOW VISIBILITY", "FOG"};
        if (!(state == 3 || state == 1) || blinkOn()) g.ui(ST[state], 180, 212, G.MC, cl, state == 3 ? 0.8f : 0.72f);
        box(g, state == 3 ? "Do not take off VFR" : (state >= 1 ? "Check METAR visibility" : "No action needed"),
                (!Float.isNaN(temp) && !Float.isNaN(dew)) ? String.format(Locale.ROOT, "TEMP %.0f C - DEW %.0f C", temp, dew) : "TEMP -- C - DEW -- C", 80, 200);
    }
}
