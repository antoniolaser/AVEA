package it.avea.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

/**
 * Piccolo "LovyanGFX" per Android: stesse funzioni di disegno usate dal firmware dello strumento
 * (colori RGB565, coordinate 360 x 360, testo con "datum"), cosi' le pagine si copiano dal firmware
 * quasi riga per riga e risultano uguali al display tondo.
 */
public class G {
    // ---------- colori RGB565 come in LovyanGFX ----------
    public static final int BLACK = 0x0000, NAVY = 0x000F, DARKGREEN = 0x03E0, DARKCYAN = 0x03EF, MAROON = 0x7800,
            PURPLE = 0x780F, OLIVE = 0x7BE0, LIGHTGREY = 0xD69A, DARKGREY = 0x7BEF, BLUE = 0x001F, GREEN = 0x07E0,
            CYAN = 0x07FF, RED = 0xF800, MAGENTA = 0xF81F, YELLOW = 0xFFE0, WHITE = 0xFFFF, ORANGE = 0xFDA0,
            GREENYELLOW = 0xB7E0, PINK = 0xFE19, BROWN = 0x9A60, GOLD = 0xFEA0, SILVER = 0xC618, SKYBLUE = 0x867D;

    public static int color565(int r, int g, int b) { return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3); }
    public static int argb(int c) {
        final int r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
        return 0xFF000000 | ((r * 255 / 31) << 16) | ((g * 255 / 63) << 8) | (b * 255 / 31);
    }
    /** Mescola due colori 565 (a = 0 -> c0, a = 1 -> c1), come gsMix565 del firmware. */
    public static int mix(int c0, int c1, float a) {
        a = Math.max(0f, Math.min(1f, a));
        final int r0 = (c0 >> 11) & 31, g0 = (c0 >> 5) & 63, b0 = c0 & 31, r1 = (c1 >> 11) & 31, g1 = (c1 >> 5) & 63, b1 = c1 & 31;
        return ((r0 + Math.round((r1 - r0) * a)) << 11) | ((g0 + Math.round((g1 - g0) * a)) << 5) | (b0 + Math.round((b1 - b0) * a));
    }

    // ---------- datum del testo ----------
    public static final int TL = 0, TC = 1, TR = 2, ML = 4, MC = 5, MR = 6, BL = 8, BC = 9, BR = 10, L_BASE = 16, C_BASE = 17, R_BASE = 18;

    // ---------- caratteri: dimensione Android per i font del firmware ----------
    public static final float F_UI32 = 32f, F_UI24 = 24f, F_NUM80 = 80f, F_CLK22 = 22f, F_CLK48 = 48f, F_CLK60 = 60f;
    public static final float F_B9 = 9 * 2.04f, F_B12 = 12 * 2.04f, F_B18 = 18 * 2.04f, F_B24 = 24 * 2.04f;
    public static final float F_S12 = 12 * 2.04f, F_S18 = 18 * 2.04f, F_GLCD = 10f;

    private Canvas c;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final Paint.FontMetrics fm = new Paint.FontMetrics();
    private final Typeface bold = Typeface.create("sans-serif", Typeface.BOLD);
    private final Typeface regular = Typeface.create("sans-serif", Typeface.NORMAL);
    private final Typeface digits = Typeface.create("sans-serif-condensed", Typeface.BOLD);

    private float fontPx = F_B12, sx = 1f, sy = 1f;
    private boolean fontBold = true, fontDigits = false;
    private int datum = TL, fg = WHITE, bg = -1;

    public void begin(Canvas canvas) { c = canvas; }
    public Canvas canvas() { return c; }

    // ---------- forme ----------
    private void fill(int color) { p.setStyle(Paint.Style.FILL); p.setColor(argb(color)); }
    private void stroke(int color, float w) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w); p.setColor(argb(color)); p.setStrokeCap(Paint.Cap.BUTT); }

    public void fillScreen(int color) { fill(color); c.drawRect(0, 0, 360, 360, p); }
    public void fillSprite(int color) { fillScreen(color); }
    public void fillRect(float x, float y, float w, float h, int color) { fill(color); c.drawRect(x, y, x + w, y + h, p); }
    public void drawRect(float x, float y, float w, float h, int color) { stroke(color, 1f); c.drawRect(x + 0.5f, y + 0.5f, x + w - 0.5f, y + h - 0.5f, p); }
    public void fillRoundRect(float x, float y, float w, float h, float r, int color) { fill(color); rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, p); }
    public void drawRoundRect(float x, float y, float w, float h, float r, int color) {
        stroke(color, 1f); rf.set(x + 0.5f, y + 0.5f, x + w - 0.5f, y + h - 0.5f); c.drawRoundRect(rf, r, r, p);
    }
    /** Immagine di trasparenza (ALPHA_8 o PNG) tinta del colore dato, ruotata e scalata attorno al centro. */
    public void tintedBitmap(android.graphics.Bitmap b, float cx, float cy, float deg, float scale, int color) {
        if (b == null) return;
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        c.scale(scale, scale);
        p.setStyle(Paint.Style.FILL);
        p.setColor(argb(color));
        p.setColorFilter(new android.graphics.PorterDuffColorFilter(argb(color), android.graphics.PorterDuff.Mode.SRC_IN));
        p.setFilterBitmap(true);
        c.drawBitmap(b, -b.getWidth() / 2f, -b.getHeight() / 2f, p);
        p.setColorFilter(null);
        c.restore();
    }
    public void save() { c.save(); }
    public void restore() { c.restore(); }
    public void rotateAbout(float cx, float cy, float deg) { c.translate(cx, cy); c.rotate(deg); c.translate(-cx, -cy); }

    public void drawFastHLine(float x, float y, float w, int color) { fillRect(x, y, w, 1, color); }
    public void drawFastVLine(float x, float y, float h, int color) { fillRect(x, y, 1, h, color); }
    public void drawPixel(float x, float y, int color) { fillRect(x, y, 1, 1, color); }
    public void drawLine(float x0, float y0, float x1, float y1, int color) {
        stroke(color, 1.2f); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(x0 + 0.5f, y0 + 0.5f, x1 + 0.5f, y1 + 0.5f, p);
    }
    /** r = meta' dello spessore, come LovyanGFX. */
    public void drawWideLine(float x0, float y0, float x1, float y1, float r, int color) {
        stroke(color, Math.max(1f, r * 2)); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(x0, y0, x1, y1, p);
    }
    public void fillCircle(float x, float y, float r, int color) { fill(color); c.drawCircle(x + 0.5f, y + 0.5f, r + 0.5f, p); }
    public void fillSmoothCircle(float x, float y, float r, int color) { fillCircle(x, y, r, color); }
    public void drawCircle(float x, float y, float r, int color) { stroke(color, 1.2f); c.drawCircle(x + 0.5f, y + 0.5f, r, p); }
    public void fillTriangle(float x0, float y0, float x1, float y1, float x2, float y2, int color) {
        fill(color);
        path.reset(); path.moveTo(x0, y0); path.lineTo(x1, y1); path.lineTo(x2, y2); path.close();
        c.drawPath(path, p);
    }
    public void drawTriangle(float x0, float y0, float x1, float y1, float x2, float y2, int color) {
        stroke(color, 1.2f);
        path.reset(); path.moveTo(x0, y0); path.lineTo(x1, y1); path.lineTo(x2, y2); path.close();
        c.drawPath(path, p);
    }
    /** Settore di anello: angoli in gradi da ore 3, in senso orario (come LovyanGFX fillArc). */
    public void fillArc(float x, float y, float r0, float r1, float a0, float a1, int color) {
        final float rin = Math.min(r0, r1), rout = Math.max(r0, r1);
        float sweep = a1 - a0;
        if (sweep < 0) sweep += 360;
        stroke(color, rout - rin + 1);
        final float rm = (rin + rout) / 2f;
        rf.set(x - rm, y - rm, x + rm, y + rm);
        c.drawArc(rf, a0, sweep, false, p);
    }
    public void drawArc(float x, float y, float r0, float r1, float a0, float a1, int color) { fillArc(x, y, r0, r1, a0, a1, color); }
    /** Come fillArc ma con un colore ARGB (trasparenza), per la scia delle lancette. */
    public void fillArcArgb(float x, float y, float r0, float r1, float a0, float a1, int argbColor) {
        final float rin = Math.min(r0, r1), rout = Math.max(r0, r1);
        float sweep = a1 - a0;
        if (sweep < 0) sweep += 360;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(rout - rin); p.setStrokeCap(Paint.Cap.BUTT); p.setColor(argbColor);
        final float rm = (rin + rout) / 2f;
        rf.set(x - rm, y - rm, x + rm, y + rm);
        c.drawArc(rf, a0, sweep, false, p);
    }
    /** Settore con angoli "matematici" (da ore 3, positivi verso l'alto), come gsPolar / gpsArcPt del firmware. */
    public void arcMath(float rIn, float rOut, float a0, float a1, int color) {
        final float lo = Math.min(a0, a1), hi = Math.max(a0, a1);
        if (hi - lo < 0.05f) return;
        fillArc(180, 180, rIn, rOut, -hi, -lo, color);
    }
    public static float polX(float r, float aMath) { return 180f + r * (float) Math.cos(Math.toRadians(aMath)); }
    public static float polY(float r, float aMath) { return 180f - r * (float) Math.sin(Math.toRadians(aMath)); }

    /** Linea spessa del firmware (drawThickLine: quadrilatero pieno). */
    public void thickLine(float x0, float y0, float x1, float y1, int color, float thickness) {
        if (thickness <= 1) { drawLine(x0, y0, x1, y1, color); return; }
        final float dx = x1 - x0, dy = y1 - y0, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5f) { fillCircle(x0, y0, thickness / 2f, color); return; }
        final float nx = -dy / len * thickness / 2f, ny = dx / len * thickness / 2f;
        fill(color);
        path.reset();
        path.moveTo(x0 + nx, y0 + ny); path.lineTo(x1 + nx, y1 + ny); path.lineTo(x1 - nx, y1 - ny); path.lineTo(x0 - nx, y0 - ny);
        path.close();
        c.drawPath(path, p);
    }
    public void thickTriangle(float x1, float y1, float x2, float y2, float x3, float y3, int color, float t) {
        fillTriangle(x1, y1, x2, y2, x3, y3, color);
        thickLine(x1, y1, x2, y2, color, t);
        thickLine(x2, y2, x3, y3, color, Math.max(1, t - 1));
        thickLine(x3, y3, x1, y1, color, t);
    }
    public void polygon(float[] xs, float[] ys, int n, int color) {
        if (n < 3) return;
        fill(color);
        path.reset(); path.moveTo(xs[0], ys[0]);
        for (int i = 1; i < n; i++) path.lineTo(xs[i], ys[i]);
        path.close();
        c.drawPath(path, p);
    }

    // ---------- clip ----------
    public void setClipRect(float x, float y, float w, float h) { c.save(); c.clipRect(x, y, x + w, y + h); }
    public void clearClipRect() { c.restore(); }

    // ---------- caratteri veri dello strumento (file .vlw negli assets) ----------
    public static VlwFont UI32, UI24, NUM80, CLK60, CLK48, CLK22;
    public static GfxFont FS9, FS12, FS18, FS24;   // FreeSansBold di LovyanGFX, stessi glifi del firmware
    public static void loadFonts(android.content.res.AssetManager am) {
        if (UI32 != null) return;
        FS9 = GfxFont.fromAsset(am, "FreeSansBold9pt7b.gfx");
        FS12 = GfxFont.fromAsset(am, "FreeSansBold12pt7b.gfx");
        FS18 = GfxFont.fromAsset(am, "FreeSansBold18pt7b.gfx");
        FS24 = GfxFont.fromAsset(am, "FreeSansBold24pt7b.gfx");
        UI32 = VlwFont.fromAsset(am, "UiFont32.vlw");
        UI24 = VlwFont.fromAsset(am, "UiFont24.vlw");
        NUM80 = VlwFont.fromAsset(am, "VarioNumbers80.vlw");
        CLK60 = VlwFont.fromAsset(am, "ClockFont60.vlw");
        CLK48 = VlwFont.fromAsset(am, "ClockFont48.vlw");
        CLK22 = VlwFont.fromAsset(am, "ClockFont22.vlw");
    }

    private VlwFont vlw;   // se diverso da null il testo usa il carattere VLW dello strumento
    private GfxFont gfx;   // altrimenti, se diverso da null, il FreeSansBold del firmware

    // ---------- testo ----------
    /** Carattere dello strumento: stessi glifi e stesse larghezze del firmware. */
    public void setVlw(VlwFont f) { vlw = f; gfx = null; sx = sy = 1f; }
    /** I corpi F_B9/F_B12/F_B18/F_B24 prendono il FreeSansBold vero, se caricato. */
    public void setFont(float px) {
        vlw = null; fontPx = px; fontBold = true; fontDigits = false; sx = sy = 1f;
        if (px == F_B9) gfx = FS9; else if (px == F_B12) gfx = FS12;
        else if (px == F_B18) gfx = FS18; else if (px == F_B24) gfx = FS24; else gfx = null;
    }
    public void setFontRegular(float px) { vlw = null; gfx = null; fontPx = px; fontBold = false; fontDigits = false; sx = sy = 1f; }
    public void setFontDigits(float px) { vlw = null; gfx = null; fontPx = px; fontBold = true; fontDigits = true; sx = sy = 1f; }
    public void setTextSize(float s) { sx = sy = s; }
    public void setTextSize(float a, float b) { sx = a; sy = b; }
    public void setTextDatum(int d) { datum = d; }
    public void setTextColor(int f) { fg = f; bg = -1; }
    public void setTextColor(int f, int b) { fg = f; bg = b; }

    private void prep() {
        tp.setTypeface(fontDigits ? digits : (fontBold ? bold : regular));
        tp.setTextSize(fontPx * sy);
        tp.setTextScaleX(sy > 0 ? sx / sy : 1f);
        tp.setColor(argb(fg));
    }
    public float textWidth(String s) {
        if (vlw != null) return vlw.width(s) * sx;
        if (gfx != null) return gfx.width(s) * sx;
        prep(); return tp.measureText(s);
    }
    public float fontHeight() {
        if (vlw != null) return vlw.height() * sy;
        if (gfx != null) return gfx.height() * sy;
        prep(); tp.getFontMetrics(fm); return fm.descent - fm.ascent;
    }

    public float drawString(String s, float x, float y) {
        if (vlw != null) return drawVlw(s, x, y);
        if (gfx != null) return drawGfx(s, x, y);
        prep();
        tp.getFontMetrics(fm);
        final float w = tp.measureText(s);
        final int h = datum & 3, v = datum & 0x1C;
        float left = x;
        if (h == 1) left = x - w / 2f; else if (h == 2) left = x - w;
        // altezza visibile: si usano le maiuscole/cifre (circa 0,72 del corpo), come i font bitmap del firmware
        final float cap = tp.getTextSize() * 0.72f;
        float base;
        if (v == 0) base = y + cap;              // alto
        else if (v == 4) base = y + cap / 2f;    // centro
        else if (v == 8) base = y + fm.descent * 0.2f; // basso
        else base = y;                           // linea di base
        if (bg >= 0 && bg != fg) { /* il fondo e' gia' a tinta unita: niente rettangolo */ }
        c.drawText(s, left, base, tp);
        return w;
    }
    /** Testo col carattere dello strumento: stesso posizionamento per "datum" di LovyanGFX. */
    private float drawVlw(String s, float x, float y) {
        final float w = vlw.width(s) * sx;
        final int h = datum & 3, v = datum & 0x1C;
        float left = x;
        if (h == 1) left = x - w / 2f; else if (h == 2) left = x - w;
        final float asc = vlw.ascent * sy, desc = vlw.descent * sy;
        float base;
        if (v == 0) base = y + asc;                      // alto
        else if (v == 4) base = y + (asc - desc) / 2f;   // centro
        else if (v == 8) base = y - desc;                // basso
        else base = y;                                   // linea di base
        tp.setColor(argb(fg));
        tp.setFilterBitmap(true);
        vlw.draw(c, s, left, base, sx, sy, tp);
        return w;
    }

    /** Testo col FreeSansBold del firmware: centrato sull'altezza delle maiuscole, come sul display. */
    private float drawGfx(String s, float x, float y) {
        final float w = gfx.width(s) * sx;
        final int h = datum & 3, v = datum & 0x1C;
        float left = x;
        if (h == 1) left = x - w / 2f; else if (h == 2) left = x - w;
        final float cap = gfx.capHeight() * sy;
        float base;
        if (v == 0) base = y + cap;             // alto
        else if (v == 4) base = y + cap / 2f;   // centro
        else base = y;                          // basso / linea di base
        tp.setColor(argb(fg));
        tp.setFilterBitmap(true);
        gfx.draw(c, s, left, base, sx, sy, tp);
        return w;
    }

    public float drawCentreString(String s, float x, float y) { final int d = datum; datum = TC; final float w = drawString(s, x, y); datum = d; return w; }

    /** Come drawUiVlw / drawUiVlwSprite del firmware: carattere UiFont32. */
    public float ui(String s, float x, float y, int d, int color, float scale) {
        if (UI32 != null) setVlw(UI32); else setFont(F_UI32);
        setTextSize(scale); setTextDatum(d); setTextColor(color); return drawString(s, x, y);
    }
    /** Come drawUi24Vlw del firmware: carattere UiFont24. */
    public float ui24(String s, float x, float y, int d, int color, float scale) {
        if (UI24 != null) setVlw(UI24); else setFont(F_UI24);
        setTextSize(scale); setTextDatum(d); setTextColor(color); return drawString(s, x, y);
    }
    /** Come drawNumericVlw del firmware: cifre grandi VarioNumbers80. */
    public float num(String s, float x, float y, int d, int color, float scale) {
        if (NUM80 != null) setVlw(NUM80); else setFontDigits(F_NUM80);
        setTextSize(scale); setTextDatum(d); setTextColor(color); return drawString(s, x, y);
    }
    /** Cifre dell'orologio: ClockFont60 / 48 / 22 secondo il corpo richiesto. */
    public float clock(String s, float x, float y, int d, int color, float px) {
        final VlwFont f = px >= 54 ? CLK60 : (px >= 36 ? CLK48 : CLK22);
        if (f != null) { setVlw(f); setTextSize(px / f.sizePx); } else { setFontDigits(px); }
        setTextDatum(d); setTextColor(color); return drawString(s, x, y);
    }
}
