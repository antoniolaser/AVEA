package it.avea.app;

import android.os.SystemClock;

import java.util.Locale;

/**
 * Pagine di volo copiate dal firmware: VARIO, ALTIMETER (ALTM), QFE, GPS SPEED, con la lancetta
 * arancio-rossa, la scia bianca e l'arco interno grigio.
 */
public class FlightPages {

    static final float LOW_GS_KMH = 65f, GS_LOW_MARGIN_KMH = 85f;
    static final int LOW_GS_COLOR = 0xFCC0;
    static final int ALT_VARIO_BARS = 5, ALT_VARIO_R_OUT = 172, ALT_VARIO_ZERO_X = 2, ALT_VARIO_ZERO_W = 18;
    static final float ALT_VARIO_SPAN_DEG = 60f, ALT_VARIO_GAP_DEG = 1.5f, ALT_VARIO_T_MIN = 17f;
    static final int ALT_VARIO_TEXT_X = ALT_VARIO_ZERO_X + ALT_VARIO_ZERO_W + 10;
    static final float VARIO_THRESHOLD = 1.0f;   // soglia del variometro dello strumento (1,0 m/s)

    // ---------- lancette animate ----------
    static float ndlAlt = 0, ndlGps = 0, ndlQfe = 0;
    static long ndlLastMs = 0;
    static void stepNeedles(FlightData d) {
        final long now = SystemClock.uptimeMillis();
        final float dt = ndlLastMs == 0 ? 0.016f : Math.min(1f, (now - ndlLastMs) / 1000f);
        ndlLastMs = now;
        final float k = 1f - (float) Math.exp(-dt / 0.12f);
        final float v = d.gpsValid ? d.speedKmh : 0f;
        ndlAlt += (v - ndlAlt) * k;
        ndlGps += (v - ndlGps) * k;
        ndlQfe += (d.qfeM() - ndlQfe) * k;
    }

    // ---------- scala della velocita' (come gsUpdateAutoRange) ----------
    static int gsRangeIdx = 0;
    static boolean gs150 = false;   // PAGES: GS 150 (copiato da FlightData in unitMax)
    // Con GS 150 si parte da 0-150 km/h (0-80 kt), poi 200, 300, 400. La 0-150 resta solo se il rosso
    // parte da 150 o meno: altrimenti 0-200 (come nel firmware).
    static float scaleMaxFor(boolean kt, int idx) {
        final float[] KMH = {200, 300, 400, 500}, KT = {110, 160, 215, 270};
        final float[] KMH150 = {150, 200, 300, 400}, KT150 = {80, 110, 160, 215};
        idx = Math.max(0, Math.min(3, idx));
        if (gs150) return kt ? KT150[idx] : KMH150[idx];
        return kt ? KT[idx] : KMH[idx];
    }
    static boolean is150(boolean kt, float maxU) { return !kt && maxU <= 150.5f; }   // 0-150: numeri ogni 25, tacche ogni 5
    static float unitMax(FlightData d) {
        gs150 = d.gs150;
        final boolean kt = d.speedKnots;
        final float speed = d.gpsValid ? d.speedKmh : 0f;
        final float u = kt ? speed / 1.852f : speed, hyst = kt ? 5f : 10f;
        final float uY = kt ? d.gsYellowKmh / 1.852f : d.gsYellowKmh, uR = kt ? d.gsRedKmh / 1.852f : d.gsRedKmh;
        int minIdx = 0;
        if (uY >= scaleMaxFor(kt, 0) - 0.5f) minIdx = 1;
        while (minIdx < 3 && uR > scaleMaxFor(kt, minIdx) + 0.5f) minIdx++;
        int idx = Math.max(0, Math.min(3, gsRangeIdx));
        while (idx < 3 && u > scaleMaxFor(kt, idx)) idx++;
        while (idx > minIdx && u < scaleMaxFor(kt, idx - 1) - hyst) idx--;
        if (idx < minIdx) idx = minIdx;
        gsRangeIdx = idx;
        return scaleMaxFor(kt, idx);
    }
    static float toUnit(FlightData d, float kmh) { return d.speedKnots ? kmh / 1.852f : kmh; }
    static int speedColor(FlightData d, float kmh) {
        if (d.lowGsArmed() && kmh < GS_LOW_MARGIN_KMH) return LOW_GS_COLOR;
        if (kmh < d.gsYellowKmh) return G.GREEN;
        if (kmh < d.gsRedKmh) return G.YELLOW;
        return G.RED;
    }
    static final boolean lowWhite = true;   // fascia 0-65 bianca in volo (come il firmware)
    static final float R_OUT = 177.5f;   // bordo esterno delle fasce (filo nero costante dal bordo, come il firmware)
    static final float TICK_R = 176f;    // tacche della zona 0-65 fin dentro l'arco bianco
    static float needleTip = R_OUT - 4f - 3f;   // punta a 3 px dall'arco bianco 0-65, come il firmware
    static float slowEdgeW = 4f;   // arco bianco esterno 4 px sulla zona 0-65 (come il firmware)
    static int slowStyle = 3;   // 3 = niente fascia 0-65, tacche allungate (come il firmware)
    static void slowBand(G g, float a0, float a1, int color) {   // angoli matematici
        if (slowStyle == 1 || slowStyle == 3) return;
        if (slowStyle == 0) { g.arcMath(162, R_OUT, a0, a1, color); return; }
        final float lo = Math.min(a0, a1), hi = Math.max(a0, a1), dash = 4f, gap = 3f;
        for (float a = hi - 1f; a > lo; a -= dash + gap) g.arcMath(162, R_OUT, Math.max(lo, a - dash), a, color);
    }
    static int lowArcColor(FlightData d) { return d.lowGsArmed() ? LOW_GS_COLOR : G.DARKGREY; }
    static boolean lowGsBlinkOn() { return (SystemClock.uptimeMillis() / 500) % 2 == 0; }

    /** Trattini a scalare 65-85 (stessa serie del firmware), in unita' di velocita'. */
    static float[][] gradedDashes(float lowU, float marU, float degPerU) {
        if (marU <= lowU || degPerU <= 0) return new float[0][];
        final float spanU = marU - lowU, spanDeg = spanU * degPerU;
        final int n = Math.max(3, Math.min(7, Math.round(spanDeg / 4.5f)));
        float parts = 0;
        for (int i = 0; i < n; i++) parts += n - i;
        for (int i = 0; i < n - 1; i++) parts += 0.75f * (1f + 0.5f * i);
        final float unit = spanU / parts;
        final float[][] out = new float[n][2];
        float u = lowU;
        for (int i = 0; i < n; i++) {
            final float len = unit * (n - i);
            out[i][0] = u; out[i][1] = i == n - 1 ? marU : u + len;
            u += len;
            if (i < n - 1) u += unit * 0.75f * (1f + 0.5f * i);
        }
        return out;
    }

    /** Tratto 65-85: solo contorno (2.5 px) della fascia 162-177.5, staccato dai separatori neri. a0, a1 angoli matematici. */
    static void outlineBand(G g, float a0, float a1, int color) {
        final float lo = Math.min(a0, a1), hi = Math.max(a0, a1);
        final float inset = 1.0f;                          // gradi: ~3 px dal separatore nero
        if (hi - lo < 2 * inset + 0.5f) { g.arcMath(162, R_OUT, lo, hi, color); return; }
        final float l = lo + inset, h = hi - inset;
        g.arcMath(162, 164.5f, l, h, color);
        g.arcMath(R_OUT - 2.5f, R_OUT, l, h, color);
        g.thickLine(G.polX(162, l), G.polY(162, l), G.polX(R_OUT, l), G.polY(R_OUT, l), color, 2.5f);
        g.thickLine(G.polX(162, h), G.polY(162, h), G.polX(R_OUT, h), G.polY(R_OUT, h), color, 2.5f);
    }

    // ---------- scia e lancetta (arcSweepC / arcNeedleC del firmware), angoli matematici ----------
    static void sweep(G g, float aZero, float aTip, float rIn, float rOut, boolean mirror) {
        final float span = Math.min(270f, Math.abs(aZero - aTip));
        if (span <= 0.3f) return;
        final float dir = aTip >= aZero ? 1f : -1f;
        final int steps = Math.max(2, (int) (span / 2f));
        final int RINGS = 7;
        for (int i = 0; i < steps; i++) {
            final float b0 = aZero + dir * span * i / steps, b1 = aZero + dir * span * (i + 1) / steps;
            final float back = Math.abs(aTip - (b0 + b1) / 2f);
            float fa = Math.max(0f, 1f - back / 150f); fa *= fa;   // ciano forte: sfumato del tutto 150 gradi dietro
            for (int r = 0; r < RINGS; r++) {
                final float r0 = rIn + (rOut + 1 - rIn) * r / RINGS, r1 = rIn + (rOut + 1 - rIn) * (r + 1) / RINGS;
                final float q = ((r0 + r1) / 2f - rIn) / (rOut - rIn);
                final float al = 1.0f * fa * (0.45f + 0.55f * q);
                final int a = Math.max(0, Math.min(255, Math.round(al * 255)));
                float lo = Math.min(b0, b1), hi = Math.max(b0, b1) + 0.4f;
                if (mirror) { final float l2 = 180 - hi, h2 = 180 - lo; lo = l2; hi = h2; }
                g.fillArcArgb(180, 180, r0, r1, -hi, -lo, (a << 24) | 0x00FFFF);   // scia ciano
            }
        }
    }
    static void innerArc(G g, float a0, float a1, float rIn, boolean mirror) {
        float lo = Math.min(a0, a1), hi = Math.max(a0, a1);
        if (mirror) { final float l2 = 180 - hi, h2 = 180 - lo; lo = l2; hi = h2; }
        g.fillArc(180, 180, rIn - 2.6f, rIn - 1f, -hi, -lo, G.color565(154, 154, 154));
    }
    static final int needleStyle = 2;   // bianca piena con bordino nero (come il firmware)
    static void needle(G g, float aTip, float rIn, float rOut, boolean mirror) {
        final int veil = G.WHITE, ndl = G.color565(255, 77, 26);
        // lancetta fino a 3 px dall'arco bianco 0-65, spessore in proporzione alla lunghezza
        final float n0 = rIn - 8f, n1 = needleTip, wk = (n1 - n0) / (rOut + 3f - n0);
        final int NS = 12;
        final float a = mirror ? 180 - aTip : aTip;
        for (int pass = needleStyle == 2 ? 0 : 1; pass < 2; pass++) {   // pass 0: bordino nero (stile 2)
            for (int k = 0; k < NS; k++) {
                final float tt = (k + 1f) / NS;
                final float ra = n0 + (n1 - n0) * k / NS, rb = n0 + (n1 - n0) * (k + 1) / NS;
                final float fr = Math.max(0f, Math.min(1f, (rb - rIn) / (rOut - rIn)));
                final int under = G.mix(G.BLACK, veil, 0.65f * (0.25f + 0.75f * (float) Math.pow(fr, 1.2)));
                int col = G.mix(under, ndl, 0.25f + 0.75f * (float) Math.pow(tt, 1.1));
                if (needleStyle >= 1) col = G.WHITE;             // bianco pieno, senza sfumatura
                final float w = (0.8f + 2.35f * tt) * wk;
                if (pass == 0) g.drawWideLine(G.polX(ra, a), G.polY(ra, a), G.polX(rb, a), G.polY(rb, a), w + 1.3f, G.BLACK);
                else g.drawWideLine(G.polX(ra, a), G.polY(ra, a), G.polX(rb, a), G.polY(rb, a), w, col);
            }
        }
    }
    private static void blackMark(G g, float aMath) {
        g.thickLine(G.polX(161, aMath), G.polY(161, aMath), G.polX(180, aMath), G.polY(180, aMath), G.BLACK, 4);
    }

    // ---------- barre del vario (ALTIMETER a sinistra, QFE a destra) ----------
    /** Settore con angoli dal punto delle 9 (sinistra) o delle 3 (destra), positivi verso l'alto (fillArcBar). */
    private static void arcBar(G g, float rIn, float rOut, float a0, float a1, int color, boolean right) {
        if (right) g.arcMath(rIn, rOut, a0, a1, color);
        else g.arcMath(rIn, rOut, 180 - a1, 180 - a0, color);
    }
    static void varioBars(G g, float vario, boolean valid, boolean right) {
        int sign = 0, lit = 0;
        if (valid) {
            final int whole = Math.round(Math.max(-99f, Math.min(99f, vario)));
            if (whole != 0) { sign = whole > 0 ? 1 : -1; lit = Math.min(Math.abs(whole), ALT_VARIO_BARS * 2); }
        }
        final int ghost = G.color565(42, 42, 42), up = G.GREEN, down = G.RED;
        final float pitch = ALT_VARIO_SPAN_DEG / ALT_VARIO_BARS, rIn = ALT_VARIO_R_OUT - ALT_VARIO_T_MIN;
        for (int s = 1; s >= -1; s -= 2) {
            for (int i = 0; i < ALT_VARIO_BARS; i++) {
                final float p0 = i * pitch + ALT_VARIO_GAP_DEG / 2, p1 = (i + 1) * pitch - ALT_VARIO_GAP_DEG / 2, mid = (p0 + p1) / 2;
                final int on = sign == s ? Math.max(0, Math.min(2, lit - i * 2)) : 0;
                final int color = on > 0 ? (s > 0 ? up : down) : ghost;
                if (on >= 2) { if (s > 0) arcBar(g, rIn, ALT_VARIO_R_OUT, p0, p1, color, right); else arcBar(g, rIn, ALT_VARIO_R_OUT, -p1, -p0, color, right); }
                else if (on == 1) {
                    if (s > 0) { arcBar(g, rIn, ALT_VARIO_R_OUT, p0, mid, color, right); arcBar(g, rIn, ALT_VARIO_R_OUT, mid, p1, ghost, right); }
                    else { arcBar(g, rIn, ALT_VARIO_R_OUT, -mid, -p0, color, right); arcBar(g, rIn, ALT_VARIO_R_OUT, -p1, -mid, ghost, right); }
                } else { if (s > 0) arcBar(g, rIn, ALT_VARIO_R_OUT, p0, p1, ghost, right); else arcBar(g, rIn, ALT_VARIO_R_OUT, -p1, -p0, ghost, right); }
            }
        }
        final int zx = right ? 360 - ALT_VARIO_ZERO_X - (ALT_VARIO_ZERO_W + 3) : ALT_VARIO_ZERO_X;
        g.fillRect(zx, 178, ALT_VARIO_ZERO_W + 3, 3, G.WHITE);
    }

    // ---------- ALTIMETER ----------
    static void altimeter(G g, FlightData d, int dragTarget) {
        g.fillScreen(G.BLACK);
        g.ui("ALTM", 180, 40, G.MC, G.CYAN, 1f);
        // vario a sinistra
        varioBars(g, d.varioMs, d.baroValid, false);
        if (d.baroValid) {
            final int whole = Math.round(Math.max(-99f, Math.min(99f, d.varioMs)));
            g.setFontRegular(G.F_S18); g.setTextDatum(G.ML); g.setTextColor(G.GREEN);
            g.drawString(whole == 0 ? "0" : String.format(Locale.ROOT, "%+d", whole), ALT_VARIO_TEXT_X, 178);
            g.setFontRegular(G.F_S12); g.setTextSize(0.65f); g.setTextColor(G.GREEN);
            g.drawString("m/s", ALT_VARIO_TEXT_X + 5, 205);
        }
        // arco GS a destra (-60..60 gradi dal punto delle 3)
        final float maxU = unitMax(d);
        final float lowU = Math.min(toUnit(d, LOW_GS_KMH), maxU), marU = Math.min(Math.max(toUnit(d, GS_LOW_MARGIN_KMH), lowU), maxU);
        final float yel = Math.min(Math.max(toUnit(d, d.gsYellowKmh), marU), maxU), red = Math.min(Math.max(toUnit(d, d.gsRedKmh), yel), maxU);
        final int lowC = lowArcColor(d);
        g.setFont(G.F_B9);
        final boolean valid = d.gpsValid;
        final float ndlU = Math.min(maxU, toUnit(d, ndlAlt));
        if (valid) sweep(g, gsAng(0, maxU), gsAng(ndlU, maxU), 131, 161, false);
        if (lowU > 0) slowBand(g, gsAng(0, maxU), gsAng(lowU, maxU), lowWhite && d.lowGsArmed() ? G.WHITE : lowC);
        if (marU > lowU && (!d.gsRectBlink || lowGsBlinkOn())) outlineBand(g, gsAng(lowU, maxU), gsAng(marU, maxU), LOW_GS_COLOR);
        if (yel > marU) g.arcMath(162, R_OUT, gsAng(marU, maxU), gsAng(yel, maxU), G.GREEN);
        if (red > yel) g.arcMath(162, R_OUT, gsAng(yel, maxU), gsAng(red, maxU), G.YELLOW);
        if (red < maxU) g.arcMath(162, R_OUT, gsAng(red, maxU), gsAng(maxU, maxU), G.RED);
        for (float ev : new float[]{lowU, marU, yel, red}) if (ev > 0 && ev < maxU) blackMark(g, gsAng(ev, maxU));
        final boolean s150 = is150(d.speedKnots, maxU);
        final int tickStep = s150 ? 5 : (d.speedKnots ? (maxU <= 135 ? 5 : 10) : (maxU <= 250 ? 10 : 20));
        final int major = s150 ? 25 : (d.speedKnots ? (maxU <= 135 ? 25 : 50) : (maxU <= 250 ? 50 : 100));
        for (int k = 0; k <= (int) maxU; k += tickStep) {
            final float a = gsAng(k, maxU), r0 = k % major == 0 ? 142 : 151;
            final float r1 = slowStyle == 3 && k < lowU - 0.01f ? TICK_R : 161f;   // 0-65: tacche lunghe fino all'arco bianco
            g.thickLine(G.polX(r0, a), G.polY(r0, a), G.polX(r1, a), G.polY(r1, a), G.WHITE, 2);
        }
        if (slowStyle == 3 && slowEdgeW > 0 && lowU > 0) g.arcMath(R_OUT - slowEdgeW, R_OUT, gsAng(0, maxU), gsAng(lowU, maxU), G.WHITE);   // arco bianco esterno 0-65
        if (slowStyle == 3 && !s150) {   // 0-65: tacche intermedie (non in 0-150, dove sono gia' ogni 5) piu' piccole a meta' passo (5, 15, 25...)
            for (float k = tickStep / 2f; k < lowU - 0.01f; k += tickStep) {
                final float a = gsAng(k, maxU);
                g.thickLine(G.polX(167, a), G.polY(167, a), G.polX(TICK_R, a), G.polY(TICK_R, a), G.WHITE, 1.5f);
            }
        }
        g.setFont(G.F_B9); g.setTextSize(1.1f); g.setTextDatum(G.MC); g.setTextColor(G.LIGHTGREY);
        for (int v = major; v <= (int) maxU; v += major) {
            final float la = gsAng(v, maxU), r = Math.abs(la) < 15 ? 120 : 128;
            g.drawString(String.valueOf(v), G.polX(r, la), G.polY(r, la));
        }
        if (dragTarget != 0) {
            final float b = dragTarget == 1 ? yel : red;
            g.drawWideLine(G.polX(156, gsAng(b, maxU)), G.polY(156, gsAng(b, maxU)), G.polX(180, gsAng(b, maxU)), G.polY(180, gsAng(b, maxU)), 2.5f, G.WHITE);
        }
        // quota al centro
        if (!d.baroValid) {
            g.setTextDatum(G.MC); g.setFont(G.F_B18); g.setTextColor(G.RED); g.drawString("ALT INVALID", 180, 175);
            g.setFont(G.F_B9); g.drawString("CHECK SENSOR / DATA", 180, 220);
        } else {
            final String alt = String.valueOf(Math.round(d.altUnit(d.altM)));
            g.setFontDigits(G.F_NUM80); g.setTextSize(1.14f);
            float sc = 1.14f;
            final float w = g.textWidth(alt);
            if (w > 172) sc *= 172f / w;
            g.num(alt, 180, 165, G.MC, G.WHITE, sc);
            g.setFont(G.F_B12); g.setTextSize(1.3f); g.setTextDatum(G.MC); g.setTextColor(G.CYAN);
            g.drawString(d.unitsMeters ? "mt" : "ft", 180, 213);
        }
        // GS
        final boolean lowGs = d.lowGsActive;
        g.setFont(G.F_B9); g.setTextDatum(G.MC);
        if (lowGs) { g.setTextColor(LOW_GS_COLOR); if (lowGsBlinkOn()) g.drawString("LOW GS", 180, 243); }
        else { g.setTextColor(G.CYAN); g.drawString("GS", 180, 243); }
        final String unit = d.speedKnots ? "kt" : "km/h";
        String vs;
        int vc = !valid ? G.DARKGREY : speedColor(d, d.speedKmh);
        if (dragTarget != 0) {
            vs = (dragTarget == 1 ? "YEL " : "RED ") + Math.round(toUnit(d, dragTarget == 1 ? d.gsYellowKmh : d.gsRedKmh));
            vc = dragTarget == 1 ? G.YELLOW : G.RED;
        } else vs = valid ? Math.round(toUnit(d, d.speedKmh)) + " " + unit : "-- " + unit;
        if (lowGs && dragTarget == 0) vc = LOW_GS_COLOR;
        g.setFontRegular(G.F_S18); g.setTextDatum(G.MC); g.setTextColor(vc);
        g.drawString(vs, 180, 268);
        g.drawRect(125, 300, 110, 32, G.YELLOW);
        g.ui("SET QNH", 180, 316, G.MC, G.YELLOW, 0.62f);
        if (valid) { innerArc(g, -60, 60, 131, false); needle(g, gsAng(ndlU, maxU), 131, 161, false); }
    }
    static float gsAng(float u, float maxU) { return -60f + 120f * Math.max(0, Math.min(maxU, u)) / maxU; }

    // ---------- VARIO ----------
    static void vario(G g, FlightData d) {
        g.fillScreen(G.BLACK);
        g.ui("VARIO", 180, 65, G.MC, G.CYAN, 1f);
        g.fillRect(80, 263, 200, 2, G.DARKGREY);
        if (!d.baroValid) {
            g.setTextDatum(G.MC); g.setFont(G.F_B18); g.setTextColor(G.RED); g.drawString("VARIO INVALID", 180, 175);
            g.setFont(G.F_B9); g.drawString("CHECK SENSOR / DATA", 180, 220);
        } else {
            final float v = d.varioMs;
            final float q = Math.round(v / VARIO_THRESHOLD) * VARIO_THRESHOLD;
            final int dir = v >= VARIO_THRESHOLD ? 1 : (v <= -VARIO_THRESHOLD ? -1 : 0);
            final int outline = G.color565(42, 42, 42);
            if (dir > 0) g.fillTriangle(290, 105, 242, 205, 338, 205, G.GREEN); else g.drawTriangle(290, 105, 242, 205, 338, 205, outline);
            if (dir < 0) g.fillTriangle(70, 205, 22, 105, 118, 105, G.RED); else g.drawTriangle(70, 205, 22, 105, 118, 105, outline);
            final int qi = Math.round(q);
            g.num(String.valueOf(qi == 0 ? 0 : qi), 180, 180, G.MC, G.WHITE, 1.2f);
            g.setFont(G.F_B12); g.setTextDatum(G.MC); g.setTextColor(G.CYAN);
            g.drawString("m/s", 180, 238);
        }
        // "ALT 1842 mt"
        final String num = d.baroValid ? String.valueOf(Math.round(d.altUnit(d.altM))) : "--";
        final String unit = d.unitsMeters ? " mt" : " ft";
        g.setFont(G.F_UI32); g.setTextSize(0.85f);
        final float wA = g.textWidth("ALT "), wN = g.textWidth(num), wU = g.textWidth(unit);
        float x = 40 + 140 - (wA + wN + wU) / 2;
        final float y = 276 + 21;
        g.setTextDatum(G.ML);
        g.setTextColor(G.CYAN); g.drawString("ALT ", x, y); x += wA;
        g.setTextColor(G.YELLOW); g.drawString(num, x, y); x += wN;
        g.setTextColor(G.CYAN); g.drawString(unit, x, y);
    }

    // ---------- QFE ----------
    static int qfeArcRange = 1;
    static void qfe(G g, FlightData d, int dragEdge) {
        g.fillScreen(G.BLACK);
        final boolean feet = !d.unitsMeters;
        final float k = feet ? 3.28084f : 1f;
        final boolean valid = d.baroValid && d.qfeSet;
        final float qfeM = d.qfeM();
        final float hU = qfeM * k;
        // vario a destra
        varioBars(g, d.varioMs, d.baroValid, true);
        if (d.baroValid) {
            final int whole = Math.round(Math.max(-99f, Math.min(99f, d.varioMs)));
            g.setFontRegular(G.F_S18); g.setTextDatum(G.MR); g.setTextColor(G.GREEN);
            g.drawString(whole == 0 ? "0" : String.format(Locale.ROOT, "%+d", whole), 360 - ALT_VARIO_TEXT_X, 178);
            g.setFontRegular(G.F_S12); g.setTextSize(0.65f);
            g.drawString("m/s", 360 - ALT_VARIO_TEXT_X - 5, 205);
        }
        final float stepU = feet ? 1500f : 500f;
        if (valid && dragEdge == 0) {
            while (hU > qfeArcRange * stepU && qfeArcRange < 20) qfeArcRange++;
            while (qfeArcRange > 1 && hU < (qfeArcRange - 1) * stepU - 0.2f * stepU) qfeArcRange--;
        }
        final float maxU = qfeArcRange * stepU;
        final int major = (int) (maxU / 5f), tick = major / 4;
        // arco a sinistra: angoli specchiati (mirror = true)
        g.arcMath(162, R_OUT, 180 - 60, 180 + 60, G.GREEN);
        g.arcMath(162, R_OUT, 180 - qAng(d.qfeHighM * k, maxU), 180 - qAng(d.qfeLowM * k, maxU), G.YELLOW);
        for (float ev : new float[]{d.qfeLowM * k, d.qfeHighM * k}) if (ev > 0 && ev < maxU) blackMark(g, 180 - qAng(ev, maxU));
        if (dragEdge != 0) {
            final float ea = 180 - qAng((dragEdge == 1 ? d.qfeLowM : d.qfeHighM) * k, maxU);
            g.drawWideLine(G.polX(156, ea), G.polY(156, ea), G.polX(178, ea), G.polY(178, ea), 2.5f, G.WHITE);
        }
        final float ndlU = Math.max(0, Math.min(maxU, ndlQfe * k));
        if (valid) sweep(g, qAng(0, maxU), qAng(ndlU, maxU), 131, 161, true);
        for (int v = 0; v <= (int) maxU; v += tick) {
            final float a = 180 - qAng(v, maxU), r0 = v % major == 0 ? 142 : 151;
            g.thickLine(G.polX(r0, a), G.polY(r0, a), G.polX(161, a), G.polY(161, a), G.WHITE, 2);
        }
        g.setFont(G.F_B9); g.setTextSize(1.1f); g.setTextDatum(G.MC); g.setTextColor(G.LIGHTGREY);
        for (int v = major; v <= (int) maxU; v += major) {
            final float la = qAng(v, maxU), a = 180 - la, r = Math.abs(la) < 15 ? 120 : 126;
            g.drawString(v >= 10000 ? (v / 1000) + "k" : String.valueOf(v), G.polX(r, a), G.polY(r, a));
        }
        g.ui("QFE", 180, 40, G.MC, G.CYAN, 0.95f);
        if (valid) {
            final String main = String.valueOf(Math.round(hU));
            g.setFontDigits(G.F_NUM80); g.setTextSize(1.14f);
            float sc = 1.14f;
            final float w = g.textWidth(main);
            if (w > 200) sc *= 200f / w;
            g.num(main, 180, 150, G.MC, G.WHITE, sc);
        } else {
            g.ui(d.baroValid ? "RESET QFE" : "ALT INVALID", 180, 150, G.MC, G.RED, 0.8f);
        }
        g.ui(feet ? "ft" : "mt", 180, 205, G.MC, G.CYAN, 0.8f);
        if (valid) {
            final String other = String.valueOf(Math.round(feet ? qfeM : qfeM * 3.28084f)), ou = feet ? "mt" : "ft";
            g.setFont(G.F_UI32); g.setTextSize(0.85f);
            final float wN = g.textWidth(other);
            g.setTextSize(0.62f);
            final float wU = g.textWidth(ou);
            final float x = 180 - (wN + 6 + wU) / 2;
            g.ui(other, x, 246, G.ML, G.WHITE, 0.85f);
            g.ui(ou, x + wN + 6, 247, G.ML, G.CYAN, 0.62f);
        }
        g.setFont(G.F_B9); g.setTextSize(0.75f); g.setTextDatum(G.MC);
        if (dragEdge != 0) {
            g.setTextColor(G.YELLOW);
            g.drawString("CIRCUIT " + Math.round(d.qfeLowM * k) + "-" + Math.round(d.qfeHighM * k) + " " + (feet ? "ft" : "mt"), 180, 276);
        } else { g.setTextColor(G.DARKGREY); g.drawString("ABOVE FIELD", 180, 276); }
        g.drawRect(115, 296, 130, 34, G.YELLOW); g.drawRect(116, 297, 128, 32, G.YELLOW);
        g.ui("RESET QFE", 180, 313, G.MC, G.YELLOW, 0.55f);
        if (valid) { innerArc(g, -60, 60, 131, true); needle(g, qAng(ndlU, maxU), 131, 161, true); }
    }
    static float qAng(float u, float maxU) { return -60f + 120f * Math.max(0, Math.min(maxU, u)) / maxU; }
    static float qfeMaxShown(FlightData d) { return qfeArcRange * (d.unitsMeters ? 500f : 1500f); }

    // ---------- GPS SPEED ----------
    static float gpsAng(float u, float maxU) { return 225f - 270f * Math.max(0, Math.min(maxU, u)) / maxU; }
    static void gpsSpeed(G g, FlightData d, int dragTarget) {
        g.fillScreen(G.BLACK);
        final boolean valid = d.gpsValid;
        final float maxU = unitMax(d);
        final float lowU = Math.min(toUnit(d, LOW_GS_KMH), maxU), marU = Math.min(toUnit(d, GS_LOW_MARGIN_KMH), maxU);
        final float yelU = Math.max(toUnit(d, d.gsYellowKmh), marU), redU = Math.max(toUnit(d, d.gsRedKmh), yelU);
        final int lowC = lowArcColor(d);
        final float ndlU = Math.min(maxU, toUnit(d, ndlGps));
        if (valid) { sweep(g, gpsAng(0, maxU), gpsAng(ndlU, maxU), 108, 161, false); innerArc(g, gpsAng(0, maxU), gpsAng(maxU, maxU), 108, false); }
        slowBand(g, gpsAng(0, maxU), gpsAng(lowU, maxU), lowWhite && d.lowGsArmed() ? G.WHITE : lowC);
        if (marU > lowU && (!d.gsRectBlink || lowGsBlinkOn())) outlineBand(g, gpsAng(lowU, maxU), gpsAng(marU, maxU), LOW_GS_COLOR);
        g.arcMath(162, R_OUT, gpsAng(marU, maxU), gpsAng(Math.min(yelU, maxU), maxU), G.GREEN);
        g.arcMath(162, R_OUT, gpsAng(Math.min(yelU, maxU), maxU), gpsAng(Math.min(redU, maxU), maxU), G.YELLOW);
        g.arcMath(162, R_OUT, gpsAng(Math.min(redU, maxU), maxU), gpsAng(maxU, maxU), G.RED);
        for (float ev : new float[]{lowU, marU, yelU, redU}) if (ev > 0 && ev < maxU) blackMark(g, gpsAng(ev, maxU));
        if (dragTarget != 0) {
            final float b = gpsAng(dragTarget == 1 ? yelU : redU, maxU);
            g.drawWideLine(G.polX(156, b), G.polY(156, b), G.polX(180, b), G.polY(180, b), 2.5f, G.WHITE);
        }
        final boolean s150 = is150(d.speedKnots, maxU);
        final int tickStep = s150 ? 5 : (d.speedKnots ? (maxU <= 160.5f ? 5 : 10) : (maxU <= 300.5f ? 10 : 20));
        final int majorStep = s150 ? 25 : (d.speedKnots ? (maxU <= 110.5f ? 25 : 50) : (maxU <= 300.5f ? 50 : 100));
        for (int k = 0; k <= (int) maxU; k += tickStep) {
            final float a = gpsAng(k, maxU), r0 = k % majorStep == 0 ? 142 : 151;
            final float r1 = slowStyle == 3 && k < lowU - 0.01f ? TICK_R : 161f;   // 0-65: tacche lunghe fino all'arco bianco
            g.thickLine(G.polX(r0, a), G.polY(r0, a), G.polX(r1, a), G.polY(r1, a), G.WHITE, 2);
        }
        if (slowStyle == 3 && slowEdgeW > 0 && lowU > 0) g.arcMath(R_OUT - slowEdgeW, R_OUT, gpsAng(0, maxU), gpsAng(lowU, maxU), G.WHITE);   // arco bianco esterno 0-65
        if (slowStyle == 3 && !s150) {   // 0-65: tacche intermedie (non in 0-150, dove sono gia' ogni 5) piu' piccole a meta' passo (5, 15, 25...)
            for (float k = tickStep / 2f; k < lowU - 0.01f; k += tickStep) {
                final float a = gpsAng(k, maxU);
                g.thickLine(G.polX(167, a), G.polY(167, a), G.polX(TICK_R, a), G.polY(TICK_R, a), G.WHITE, 1.5f);
            }
        }
        g.setFont(G.F_B9);
        g.setTextSize(maxU > (d.speedKnots ? 110.5f : 200.5f) ? 1.0f : 1.17f);
        g.setTextDatum(G.MC);
        for (int k = 0; k <= (int) maxU; k += majorStep) {
            final float a = gpsAng(k, maxU);
            g.setTextColor(valid && k <= ndlU ? G.WHITE : G.LIGHTGREY);
            g.drawString(String.valueOf(k), G.polX(122, a), G.polY(122, a));
        }
        final boolean lowGs = d.lowGsActive;
        {   // titolo su una riga che sfiora l'arco interno (r 108), come nel firmware
            final String title = lowGs ? "LOW GS" : "GND SPEED";
            final float sz = lowGs ? 0.75f : 0.62f;
            g.setFont(G.F_UI32); g.setTextSize(sz);
            final float hw = g.textWidth(title) / 2f, capH = 32f * sz * 0.72f;
            final float ty = 180f - (float) Math.sqrt(108f * 108f - hw * hw) + 1.5f + capH / 2f + 8f;
            if (!lowGs) g.ui(title, 180, ty, G.MC, G.CYAN, sz);
            else if (lowGsBlinkOn()) g.ui(title, 180, ty, G.MC, LOW_GS_COLOR, sz);
        }
        final int mainColor = lowGs ? LOW_GS_COLOR : speedColor(d, d.speedKmh);
        g.num(valid ? String.valueOf(Math.round(toUnit(d, d.speedKmh))) : "--", 180, 165, G.MC, valid ? mainColor : G.DARKGREY, 1.14f);
        g.ui(d.speedKnots ? "kt" : "km/h", 180, 218, G.MC, G.CYAN, 0.85f);
        if (dragTarget != 0) {
            g.ui((dragTarget == 1 ? "YELLOW " : "RED ") + Math.round(dragTarget == 1 ? yelU : redU), 180, 256, G.MC, dragTarget == 1 ? G.YELLOW : G.RED, 0.85f);
        } else {
            final String num = valid ? String.valueOf(Math.round(d.speedKnots ? d.speedKmh : d.speedKmh / 1.852f)) : "--";
            final String ou = d.speedKnots ? "km/h" : "kt";
            g.setFont(G.F_UI32); g.setTextSize(0.85f);
            final float wN = g.textWidth(num), wS = g.textWidth(" "), wU = g.textWidth(ou);
            final float x = 180 - (wN + wS + wU) / 2;
            g.ui(num, x, 256, G.ML, G.WHITE, 0.85f);
            g.ui(ou, x + wN + wS, 256, G.ML, G.CYAN, 0.85f);
        }
        g.setFont(G.F_B9); g.setTextSize(1.5f); g.setTextDatum(G.MC); g.setTextColor(G.ORANGE);
        g.drawString("MAX " + Math.round(toUnit(d, d.maxSpeedKmh)) + " " + (d.speedKnots ? "kt" : "km/h"), 180, 308);
        if (valid) needle(g, gpsAng(ndlU, maxU), 108, 161, false);
    }
}
