package it.avea.app;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Tutti i dati di volo, come nello strumento: quota barometrica con filtro di Kalman, variometro,
 * QFE, dati GPS, home, timer automatico del volo e log degli ultimi voli.
 * Viene aggiornato dai sensori (thread principale) e letto dal disegno e dall'audio.
 */
public class FlightData {

    // ---------- impostazioni ----------
    public float qnhHpa = 1013.25f;
    public boolean unitsMeters = true;      // quota in metri o piedi
    public boolean speedKnots = false;      // velocita' in km/h o nodi
    public boolean audioOn = false;         // AUDIO di serie spento, come sullo strumento
    public boolean demo = false;            // simulazione di un volo

    // ---------- barometro ----------
    public volatile boolean baroValid = false;
    public volatile float pressureHpa = 0f;
    public volatile float altM = 0f;        // quota filtrata (QNH)
    public volatile float varioMs = 0f;     // velocita' verticale filtrata
    public boolean qfeSet = false;
    public float qfeRefM = 0f;

    // ---------- GPS ----------
    public volatile boolean gpsValid = false;
    public volatile double lat, lon;
    public volatile float speedKmh = 0f;
    public volatile float courseDeg = 0f;
    public volatile float gpsAltM = 0f;
    public volatile int satsUsed = 0, satsInView = 0;
    public volatile long gpsFixAtMs = 0;

    // ---------- home ----------
    public boolean homeSet = false;
    public double homeLat, homeLon;

    // ---------- volo ----------
    public static final float TAKEOFF_KMH = 60f;          // come lo strumento: sopra 60 km/h per 3 s
    public static final long TAKEOFF_MS = 3000;
    public static final float LANDING_KMH = 5f;            // sotto 5 km/h per 5 s
    public static final long LANDING_MS = 5000;
    public boolean flying = false;
    public long flightStartMs = 0, flightEndMs = 0;
    public float flightMaxAltM = 0, flightMaxKmh = 0, flightMaxClimb = 0, flightMinSink = 0;
    public double flightDistKm = 0;
    private long aboveSince = 0, belowSince = 0;
    private double lastLat = Double.NaN, lastLon = Double.NaN;

    public static class LogEntry {
        public long startMs, durMs;
        public float maxAltM, maxKmh, maxClimb, minSink;
        public double distKm;
        public float fuelUsedL = -1f, endTempC = Float.NaN, endHum = Float.NaN;
    }
    public float flightFuelUsedL = -1f;
    private float takeoffLiters = -1f;
    public int constellations = 0;   // bit: 1 GPS, 2 GLONASS, 4 Galileo, 8 BDS, 16 QZSS
    public final List<LogEntry> logs = new ArrayList<>();
    public static final int MAX_LOGS = 10;

    // ---------- filtro di Kalman quota / velocita' verticale ----------
    private boolean kInit = false;
    private double kH, kV;                       // stato: quota, velocita' verticale
    private double p00 = 10, p01 = 0, p10 = 0, p11 = 10;
    private long kLastNs = 0;
    private static final double K_ACC_VAR = 1.5;   // rumore di processo (accelerazione verticale)
    private static final double K_MEAS_VAR = 0.20; // rumore del barometro del telefono (m^2)

    public static float pressureToAltitude(float p, float qnh) {
        return (float) (44330.0 * (1.0 - Math.pow(p / qnh, 1.0 / 5.255)));
    }
    public static float altitudeToPressure(float h, float qnh) {
        return (float) (qnh * Math.pow(1.0 - h / 44330.0, 5.255));
    }

    /** Nuova lettura del barometro (hPa) al tempo t (nanosecondi). */
    public synchronized void onPressure(float hPa, long tNs) {
        pressureHpa = hPa;
        final double z = pressureToAltitude(hPa, qnhHpa);
        if (!kInit) {
            kH = z; kV = 0; kInit = true; kLastNs = tNs;
            p00 = 10; p01 = p10 = 0; p11 = 10;
        } else {
            double dt = (tNs - kLastNs) / 1e9;
            kLastNs = tNs;
            if (dt <= 0 || dt > 1.0) dt = 0.05;
            // previsione
            kH += kV * dt;
            final double dt2 = dt * dt, dt3 = dt2 * dt, dt4 = dt3 * dt;
            final double n00 = p00 + dt * (p10 + p01) + dt2 * p11 + K_ACC_VAR * dt4 / 4;
            final double n01 = p01 + dt * p11 + K_ACC_VAR * dt3 / 2;
            final double n10 = p10 + dt * p11 + K_ACC_VAR * dt3 / 2;
            final double n11 = p11 + K_ACC_VAR * dt2;
            // correzione con la quota misurata
            final double s = n00 + K_MEAS_VAR;
            final double k0 = n00 / s, k1 = n10 / s;
            final double y = z - kH;
            kH += k0 * y;
            kV += k1 * y;
            p00 = (1 - k0) * n00;
            p01 = (1 - k0) * n01;
            p10 = n10 - k1 * n00;
            p11 = n11 - k1 * n01;
        }
        altM = (float) kH;
        varioMs = (float) kV;
        baroValid = true;
        if (flying) {
            if (altM > flightMaxAltM) flightMaxAltM = altM;
            if (varioMs > flightMaxClimb) flightMaxClimb = varioMs;
            if (varioMs < flightMinSink) flightMinSink = varioMs;
        }
    }

    /** Cambio di QNH: la quota si ricalcola subito dalla pressione attuale. */
    public synchronized void setQnh(float q) {
        final float old = altM;
        qnhHpa = Math.max(900f, Math.min(1100f, q));
        if (baroValid) {
            final double nh = pressureToAltitude(pressureHpa, qnhHpa);
            kH += nh - old;
            altM = (float) kH;
        }
    }

    public float qfeM() { return qfeSet ? altM - qfeRefM : altM; }

    public void resetQfe() { qfeRefM = altM; qfeSet = true; }

    /** Nuova posizione GPS. */
    public void onGps(double la, double lo, float kmh, float course, float alt, long nowMs) {
        lat = la; lon = lo; speedKmh = kmh; courseDeg = course; gpsAltM = alt;
        gpsValid = true;
        gpsFixAtMs = nowMs;
        if (kmh > maxSpeedKmh) maxSpeedKmh = kmh;
        if (flying) {
            if (!Double.isNaN(lastLat)) {
                final double d = distanceKm(lastLat, lastLon, la, lo);
                if (d < 2.0) flightDistKm += d;     // salti anomali esclusi
            }
            lastLat = la; lastLon = lo;
            if (kmh > flightMaxKmh) flightMaxKmh = kmh;
        }
        updateFlightState(nowMs);
    }

    /** GPS perso da troppo tempo: dati non piu' validi. */
    public void checkGpsTimeout(long nowMs) {
        if (gpsValid && nowMs - gpsFixAtMs > 3000) { gpsValid = false; speedKmh = 0; }
        updateFlightState(nowMs);
    }

    private void updateFlightState(long nowMs) {
        final float v = gpsValid ? speedKmh : 0f;
        if (!flying) {
            if (v >= TAKEOFF_KMH) {
                if (aboveSince == 0) aboveSince = nowMs;
                if (nowMs - aboveSince >= TAKEOFF_MS) startFlight(nowMs);
            } else aboveSince = 0;
        } else {
            if (v <= LANDING_KMH) {
                if (belowSince == 0) belowSince = nowMs;
                if (nowMs - belowSince >= LANDING_MS) endFlight(nowMs);
            } else belowSince = 0;
        }
    }

    private void startFlight(long nowMs) {
        flying = true;
        flightStartMs = System.currentTimeMillis() - (nowMs - aboveSince);
        flightEndMs = 0;
        flightMaxAltM = altM; flightMaxKmh = speedKmh; flightMaxClimb = 0; flightMinSink = 0;
        flightDistKm = 0; lastLat = Double.NaN; lastLon = Double.NaN;
        takeoffLiters = fuelLiters; flightFuelUsedL = 0f;
        aboveSince = 0; belowSince = 0;
    }

    private void endFlight(long nowMs) {
        flying = false;
        flightEndMs = System.currentTimeMillis();
        belowSince = 0;
        LogEntry e = new LogEntry();
        e.startMs = flightStartMs;
        e.durMs = flightEndMs - flightStartMs;
        e.maxAltM = flightMaxAltM; e.maxKmh = flightMaxKmh;
        e.maxClimb = flightMaxClimb; e.minSink = flightMinSink;
        e.distKm = flightDistKm;
        e.fuelUsedL = flightFuelUsedL;
        if (meteoValid) { e.endTempC = oatC(); e.endHum = rhPct(); }
        logs.add(0, e);
        while (logs.size() > MAX_LOGS) logs.remove(logs.size() - 1);
        logsDirty = true;
    }

    public boolean logsDirty = false;

    public long flightElapsedMs() {
        if (flying) return System.currentTimeMillis() - flightStartMs;
        if (flightEndMs > 0) return flightEndMs - flightStartMs;
        return 0;
    }

    /** Ferma la simulazione: un volo simulato non resta aperto. */
    public void abortFlight() {
        flying = false; aboveSince = 0; belowSince = 0;
    }

    // ---------- navigazione ----------
    public static double distanceKm(double la1, double lo1, double la2, double lo2) {
        final double r = 6371.0;
        final double dLa = Math.toRadians(la2 - la1), dLo = Math.toRadians(lo2 - lo1);
        final double a = Math.sin(dLa / 2) * Math.sin(dLa / 2)
                + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dLo / 2) * Math.sin(dLo / 2);
        return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    public static double bearingDeg(double la1, double lo1, double la2, double lo2) {
        final double p1 = Math.toRadians(la1), p2 = Math.toRadians(la2), dLo = Math.toRadians(lo2 - lo1);
        final double y = Math.sin(dLo) * Math.cos(p2);
        final double x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dLo);
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    // ---------- unita' ----------
    public float altUnit(float m) { return unitsMeters ? m : m * 3.28084f; }
    public String altUnitName() { return unitsMeters ? "m" : "ft"; }
    public float speedUnit(float kmh) { return speedKnots ? kmh / 1.852f : kmh; }
    public String speedUnitName() { return speedKnots ? "kt" : "km/h"; }

    public static String fmtDuration(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(Locale.ROOT, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }
    public static String fmtDate(long ms) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY).format(new Date(ms));
    }


    // ---------- MANUAL FLIGHT TIMER ----------
    public boolean manRunning = false;
    public long manStartMs = 0, manAccumMs = 0;
    public long manElapsedMs() { return manAccumMs + (manRunning ? System.currentTimeMillis() - manStartMs : 0); }
    public long manFirstStartMs = 0, manStopMs = 0;
    public void manStart() { if (!manRunning) { manRunning = true; manStartMs = System.currentTimeMillis(); if (manFirstStartMs == 0) manFirstStartMs = manStartMs; } }
    public void manStop() { if (manRunning) { manAccumMs += System.currentTimeMillis() - manStartMs; manRunning = false; manStopMs = System.currentTimeMillis(); } }
    public void manReset() { manRunning = false; manAccumMs = 0; manFirstStartMs = 0; manStopMs = 0; }

    // ---------- ICT (Check Instruments) ----------
    public int ictMinutes = 15;
    public boolean ictOn = false;
    public long ictStartMs = 0;
    /** true quando e' ora di mostrare "Check Instruments" (poi il conteggio riparte). */
    public boolean ictDue(long nowMs) {
        if (!ictOn) return false;
        if (ictStartMs == 0) ictStartMs = nowMs;
        if (nowMs - ictStartMs >= ictMinutes * 60000L) { ictStartMs = nowMs; return true; }
        return false;
    }
    public long ictLeftMs(long nowMs) { return ictOn ? Math.max(0, ictMinutes * 60000L - (nowMs - ictStartMs)) : 0; }

    // ---------- FUEL ESTIMATE ----------
    public int fuelTankL = 60;
    public float fuelLiters = 60f;
    public float fuelRateLph = 15f;
    public int fuelReserveMin = 30;
    public float fuelGroundL = 1.5f;
    public boolean fuelReserveAlerted = false;
    private double fuelPendingMs = 0;
    private boolean fuelWasFlying = false;
    public float fuelReserveL() { return fuelRateLph * fuelReserveMin / 60f; }
    public float fuelEnduranceMin() { return fuelRateLph > 0 ? fuelLiters / fuelRateLph * 60f : 0; }
    /** Consumo stimato: a tempo durante il volo, piu' il consumo fisso a terra tolto al decollo. Ritorna true all'ingresso in riserva. */
    public boolean fuelStep(double dtMs) {
        boolean alert = false;
        if (demo) { fuelWasFlying = false; fuelPendingMs = 0; return false; }   // la simulazione non consuma il carburante vero
        if (flying && !fuelWasFlying) fuelLiters = Math.max(0f, fuelLiters - fuelGroundL);
        fuelWasFlying = flying;
        if (flying && takeoffLiters >= 0) flightFuelUsedL = Math.max(0f, takeoffLiters - fuelLiters);
        if (flying) {
            fuelPendingMs += dtMs;
            if (fuelPendingMs >= 1000) {
                fuelLiters = Math.max(0f, fuelLiters - (float) (fuelRateLph * fuelPendingMs / 3600000.0));
                fuelPendingMs = 0;
            }
        } else fuelPendingMs = 0;
        final boolean inReserve = fuelLiters <= fuelReserveL() + 0.01f;
        if (!inReserve) fuelReserveAlerted = false;
        else if (flying && !fuelReserveAlerted) { fuelReserveAlerted = true; alert = true; }
        return alert;
    }

    // ---------- GO TO un campo ----------
    public boolean gotoField = false;   // false = GO TO HOME
    public String gotoName = "";
    public double gotoLat, gotoLon;

    // ---------- LOW GS ----------
    public static final float LOW_GS_KMH = 65f, LOW_GS_ARM_KMH = 90f;
    private boolean lowGsArmed = false;
    public boolean lowGsArmed() { return lowGsArmed; }
    public float maxSpeedKmh = 0f;            // velocita' massima dall'accensione (scritta MAX di GPS SPEED)
    public boolean lowGsActive = false;
    public boolean gsRectArmed = false, gsRectBlink = false;   // rettangolo 65-85: lampeggia dopo aver superato 90 km/h
    public void lowGsStep() {
        if (gpsValid && speedKmh >= LOW_GS_ARM_KMH) gsRectArmed = true;
        else if (gpsValid && speedKmh < LOW_GS_KMH) gsRectArmed = false;
        gsRectBlink = gsRectArmed && gpsValid && speedKmh >= LOW_GS_KMH && speedKmh <= 85f;
        if (!flying) { lowGsArmed = false; lowGsActive = false; return; }
        if (gpsValid && speedKmh >= LOW_GS_ARM_KMH) lowGsArmed = true;
        lowGsActive = lowGsArmed && gpsValid && speedKmh < LOW_GS_KMH;
    }

    // ---------- tramonto (algoritmo NOAA semplificato) ----------
    /** Minuti dalla mezzanotte UTC del tramonto per la data e la posizione date; NaN se il sole non tramonta. */
    public static double sunsetUtcMin(int year, int month, int day, double lat, double lon) {
        final double n1 = Math.floor(275 * month / 9.0), n2 = Math.floor((month + 9) / 12.0);
        final double n3 = 1 + Math.floor((year - 4 * Math.floor(year / 4.0) + 2) / 3.0);
        final double n = n1 - n2 * n3 + day - 30;
        final double lngHour = lon / 15.0;
        final double t = n + ((18 - lngHour) / 24.0);
        final double m = 0.9856 * t - 3.289;
        double l = m + 1.916 * Math.sin(Math.toRadians(m)) + 0.020 * Math.sin(Math.toRadians(2 * m)) + 282.634;
        l = (l % 360 + 360) % 360;
        double ra = Math.toDegrees(Math.atan(0.91764 * Math.tan(Math.toRadians(l))));
        ra = (ra % 360 + 360) % 360;
        ra = ra + (Math.floor(l / 90) * 90 - Math.floor(ra / 90) * 90);
        ra /= 15.0;
        final double sinDec = 0.39782 * Math.sin(Math.toRadians(l));
        final double cosDec = Math.cos(Math.asin(sinDec));
        final double cosH = (Math.cos(Math.toRadians(90.833)) - sinDec * Math.sin(Math.toRadians(lat)))
                / (cosDec * Math.cos(Math.toRadians(lat)));
        if (cosH > 1 || cosH < -1) return Double.NaN;
        final double h = Math.toDegrees(Math.acos(cosH)) / 15.0;
        final double tLocal = h + ra - 0.06571 * t - 6.622;
        double ut = tLocal - lngHour;
        ut = (ut % 24 + 24) % 24;
        return ut * 60.0;
    }

    /** Tramonto di oggi come ora locale del telefono (millisecondi), o -1. */
    public long sunsetTodayMs() {
        if (!gpsValid) return -1;
        final java.util.Calendar utc = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
        final int y = utc.get(java.util.Calendar.YEAR), mo = utc.get(java.util.Calendar.MONTH) + 1, d = utc.get(java.util.Calendar.DAY_OF_MONTH);
        final double min = sunsetUtcMin(y, mo, d, lat, lon);
        if (Double.isNaN(min)) return -1;
        utc.set(java.util.Calendar.HOUR_OF_DAY, 0); utc.set(java.util.Calendar.MINUTE, 0);
        utc.set(java.util.Calendar.SECOND, 0); utc.set(java.util.Calendar.MILLISECOND, 0);
        return utc.getTimeInMillis() + (long) (min * 60000.0);
    }

    // ---------- soglie degli archi (si regolano con uno swipe sull'arco, come sullo strumento) ----------
    public int gsYellowKmh = 120, gsRedKmh = 160;     // GPS SPEED e arco GS dell'ALTIMETER
    public int qfeLowM = 250, qfeHighM = 350;          // fascia gialla del circuito sul QFE


    // ---------- corridoio GO TO HOME (lubber line) ----------
    public boolean lubberEdit = false;           // PAGES 1/2: casella LUBBER LINE (tocco in alto su GO HOME)
    public boolean gs150 = false;                // PAGES: GS 150, fondo scala GS da 0-150 km/h
    public boolean rotate180 = false;            // PAGES 2/3: ROTATE DISPLAY 180 gradi
    public boolean arcBlock = false;             // PAGES 2/3: ARCH BLOCK, blocca lo spostamento delle soglie sugli archi
    public boolean vertSwipeOff = false;         // PAGES 2/3: COMPASS VERTICAL SWIPE (spuntato = attivo, quindi qui false)
    public boolean onlyCtr = false;              // PAGES 2/3: avvisi spazi aerei solo per le CTR
    public boolean alertsMuted = false;          // PAGES 3/3: DON'T SHOW ALERTS, nessun avviso a tutto schermo
    public int navRwyTens = 0;                   // pista della meta (decine di gradi, 0 = sconosciuta) per GO TO HOME
    public int lubberWidthIdx = 0, lubberYellowIdx = 0;
    public boolean lubberLegValid = false, lubberActive = true;
    public double lubberLegLat, lubberLegLon;

    // ---------- meteo da internet (Open-Meteo) ----------
    public volatile boolean meteoValid = false;
    public volatile float meteoT2m = Float.NaN, meteoRh2m = Float.NaN, meteoElevM = 0f;
    public volatile long meteoAtMs = 0;           // System.currentTimeMillis() dell'ultimo dato
    public volatile String meteoStatus = null;    // messaggio se manca il dato
    public double meteoLat, meteoLon;

    private static float es(float t) { return 6.112f * (float) Math.exp(17.62f * t / (243.12f + t)); }
    /** Quota usata per riportare il meteo dal suolo alla quota attuale. */
    private float meteoDh() {
        final float alt = baroValid ? altM : (gpsValid ? gpsAltM : meteoElevM);
        return Math.max(0f, alt - meteoElevM);
    }
    /** Temperatura esterna alla quota attuale: gradiente standard 6,5 C/km dal suolo. */
    public float oatC() { return meteoT2m - 0.0065f * meteoDh(); }
    /** Umidita' alla quota attuale: il punto di rugiada scende di circa 1,8 C/km. */
    public float rhPct() {
        final float t0 = meteoT2m, h0 = meteoRh2m;
        final float a = 17.62f, b = 243.12f;
        final float g0 = (float) Math.log(Math.max(1f, h0) / 100.0) + a * t0 / (b + t0);
        final float dew0 = b * g0 / (a - g0);
        final float dh = meteoDh();
        final float t = t0 - 0.0065f * dh, dew = Math.min(t, dew0 - 0.0018f * dh);
        return Math.max(0f, Math.min(100f, 100f * es(dew) / es(t)));
    }
    public String meteoSourceLine() {
        if (!meteoValid) return "";
        final long min = Math.max(0, (System.currentTimeMillis() - meteoAtMs) / 60000);
        return "meteo internet, " + (min == 0 ? "adesso" : min + " min fa");
    }

    // ---------- pagine attive (PAGES) ----------
    public long pagesMask = ~0L;

    // ---------- salvataggio ----------
    public void load(SharedPreferences p) {
        qnhHpa = p.getFloat("qnh", 1013.25f);
        unitsMeters = p.getBoolean("meters", true);
        speedKnots = p.getBoolean("knots", false);
        audioOn = p.getBoolean("audio", false);
        qfeSet = p.getBoolean("qfeSet", false);
        qfeRefM = p.getFloat("qfeRef", 0f);
        homeSet = p.getBoolean("homeSet", false);
        homeLat = Double.longBitsToDouble(p.getLong("homeLat", 0));
        homeLon = Double.longBitsToDouble(p.getLong("homeLon", 0));
        ictMinutes = p.getInt("ictMin", 15);
        ictOn = p.getBoolean("ictOn", false);
        fuelTankL = p.getInt("tank", 60);
        fuelLiters = p.getFloat("liters", 60f);
        fuelRateLph = p.getFloat("lph", 15f);
        fuelReserveMin = p.getInt("resMin", 30);
        fuelGroundL = p.getFloat("gnd", 1.5f);
        pagesMask = p.getLong("pages2", ~0L);
        gsYellowKmh = p.getInt("gsYel", 120);
        lubberEdit = p.getBoolean("lubEdit", false);
        gs150 = p.getBoolean("gs150", false);
        rotate180 = p.getBoolean("rot180", false);
        arcBlock = p.getBoolean("arcBlock", false);
        vertSwipeOff = p.getBoolean("vSwipeOff", false);
        onlyCtr = p.getBoolean("onlyCtr", false);
        alertsMuted = p.getBoolean("noAlerts", false);
        lubberWidthIdx = Math.max(0, Math.min(3, p.getInt("lubW", 0)));
        lubberYellowIdx = Math.max(0, Math.min(2, p.getInt("lubY", 0)));
        gsRedKmh = p.getInt("gsRed", 160);
        qfeLowM = p.getInt("qfeLow", 250);
        qfeHighM = p.getInt("qfeHigh", 350);
        manAccumMs = p.getLong("manAccum", 0);
        logs.clear();
        try {
            JSONArray a = new JSONArray(p.getString("logs", "[]"));
            for (int i = 0; i < a.length() && i < MAX_LOGS; i++) {
                JSONObject o = a.getJSONObject(i);
                LogEntry e = new LogEntry();
                e.startMs = o.getLong("s"); e.durMs = o.getLong("d");
                e.maxAltM = (float) o.getDouble("a"); e.maxKmh = (float) o.getDouble("v");
                e.maxClimb = (float) o.optDouble("c", 0); e.minSink = (float) o.optDouble("n", 0);
                e.distKm = o.optDouble("k", 0);
                e.fuelUsedL = (float) o.optDouble("f", -1);
                e.endTempC = (float) o.optDouble("t", Double.NaN);
                e.endHum = (float) o.optDouble("h", Double.NaN);
                logs.add(e);
            }
        } catch (Exception ignored) { }
    }

    public void save(SharedPreferences p) {
        SharedPreferences.Editor ed = p.edit();
        ed.putFloat("qnh", qnhHpa);
        ed.putBoolean("meters", unitsMeters);
        ed.putBoolean("knots", speedKnots);
        ed.putBoolean("audio", audioOn);
        ed.putBoolean("qfeSet", qfeSet);
        ed.putFloat("qfeRef", qfeRefM);
        ed.putBoolean("homeSet", homeSet);
        ed.putLong("homeLat", Double.doubleToLongBits(homeLat));
        ed.putLong("homeLon", Double.doubleToLongBits(homeLon));
        ed.putInt("ictMin", ictMinutes);
        ed.putBoolean("ictOn", ictOn);
        ed.putInt("tank", fuelTankL);
        ed.putFloat("liters", fuelLiters);
        ed.putFloat("lph", fuelRateLph);
        ed.putInt("resMin", fuelReserveMin);
        ed.putFloat("gnd", fuelGroundL);
        ed.putLong("pages2", pagesMask);
        ed.putInt("gsYel", gsYellowKmh);
        ed.putBoolean("lubEdit", lubberEdit);
        ed.putBoolean("gs150", gs150);
        ed.putBoolean("rot180", rotate180);
        ed.putBoolean("arcBlock", arcBlock);
        ed.putBoolean("vSwipeOff", vertSwipeOff);
        ed.putBoolean("onlyCtr", onlyCtr);
        ed.putBoolean("noAlerts", alertsMuted);
        ed.putInt("lubW", lubberWidthIdx);
        ed.putInt("lubY", lubberYellowIdx);
        ed.putInt("gsRed", gsRedKmh);
        ed.putInt("qfeLow", qfeLowM);
        ed.putInt("qfeHigh", qfeHighM);
        ed.putLong("manAccum", manElapsedMs());
        try {
            JSONArray a = new JSONArray();
            for (LogEntry e : logs) {
                JSONObject o = new JSONObject();
                o.put("s", e.startMs); o.put("d", e.durMs);
                o.put("a", e.maxAltM); o.put("v", e.maxKmh);
                o.put("c", e.maxClimb); o.put("n", e.minSink); o.put("k", e.distKm);
                o.put("f", e.fuelUsedL);
                if (!Float.isNaN(e.endTempC)) o.put("t", e.endTempC);
                if (!Float.isNaN(e.endHum)) o.put("h", e.endHum);
                a.put(o);
            }
            ed.putString("logs", a.toString());
        } catch (Exception ignored) { }
        ed.apply();
        logsDirty = false;
    }
}
