package it.avea.app;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

public class MainActivity extends Activity implements SensorEventListener, LocationListener, InstrumentView.Host {

    private static final int REQ_LOCATION = 1;
    private static final int REQ_CUP = 2;
    private static final int REQ_ASP = 3;
    private Airspaces airspaces;
    private long lastAspCheckMs = 0;
    private Airfields fields;
    private long sunsetShownDay = -1;
    private long lastSaveMs = 0;

    private final FlightData data = new FlightData();
    private VarioAudio audio;
    private InstrumentView view;
    private SharedPreferences prefs;
    private SensorManager sensors;
    private Sensor barometer;
    private LocationManager locations;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Demo demo;
    private long lastTickMs = 0;
    private boolean hasBarometer = false;
    private boolean permissionAsked = false;   // il permesso si chiede una volta sola per avvio

    private final GnssStatus.Callback gnssCallback = new GnssStatus.Callback() {
        @Override
        public void onSatelliteStatusChanged(GnssStatus status) {
            int used = 0, cons = 0;
            for (int i = 0; i < status.getSatelliteCount(); i++) {
                if (!status.usedInFix(i)) continue;
                used++;
                switch (status.getConstellationType(i)) {
                    case GnssStatus.CONSTELLATION_GPS: cons |= 1; break;
                    case GnssStatus.CONSTELLATION_GLONASS: cons |= 2; break;
                    case GnssStatus.CONSTELLATION_GALILEO: cons |= 4; break;
                    case GnssStatus.CONSTELLATION_BEIDOU: cons |= 8; break;
                    case GnssStatus.CONSTELLATION_QZSS: cons |= 16; break;
                    default: break;
                }
            }
            data.satsUsed = used;
            data.constellations = cons;
            data.satsInView = status.getSatelliteCount();
        }
    };

    // 20 volte al secondo: simulazione, controllo del GPS perso, salvataggio dei log
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            final long now = SystemClock.elapsedRealtime();
            final double dt = lastTickMs == 0 ? 0.05 : (now - lastTickMs) / 1000.0;
            lastTickMs = now;
            if (data.demo) {
                if (demo == null) {
                    final double la = data.gpsValid ? data.lat : 45.4451;   // senza GPS: Milano Linate
                    final double lo = data.gpsValid ? data.lon : 9.2767;
                    demo = new Demo(la, lo);
                }
                demo.step(dt);
                data.onPressure(demo.pressureHpa(data.qnhHpa), SystemClock.elapsedRealtimeNanos());
                data.onGps(demo.lat(), demo.lon(), demo.speedKmh(), demo.courseDeg(), demo.altM(), now);
                data.satsUsed = 12; data.satsInView = 30; data.constellations = 1 | 4 | 8;
            } else {
                if (demo != null) { demo = null; data.abortFlight(); data.gpsValid = false; }
                data.checkGpsTimeout(now);
            }
            // carburante, ICT, LOW GS, tramonto
            // pagina bloccata: nessun avviso; quelli scattati nel frattempo compaiono appena si sblocca
            final boolean locked = view.isPageLocked();
            if (data.fuelStep(dt * 1000.0)) pendReserve = true;
            if (data.ictDue(now)) pendIct = true;
            if (!locked && pendReserve) {
                pendReserve = false;
                view.showAlert(InstrumentView.A_RESERVE, 10000, null);
                audio.click(1000, 600);
            }
            if (!locked && pendIct) {
                pendIct = false;
                view.showAlert(InstrumentView.A_ICT, 8000, null);
                audio.click(1500, 400);
            }
            data.lowGsStep();
            checkAirspace(now);
            checkSunset();
            checkMeteo();
            if (data.logsDirty || now - lastSaveMs > 60000) { data.save(prefs); lastSaveMs = now; }
            handler.postDelayed(this, 50);
        }
    };

    // ---------- meteo da internet (Open-Meteo, gratuito, senza chiave) ----------
    private long lastMeteoTryMs = 0;
    private volatile boolean meteoBusy = false;

    /** Ogni 10 minuti, o se ci si e' spostati di oltre 10 km, chiede temperatura e umidita' al suolo. */
    private void checkMeteo() {
        if (meteoBusy || !data.gpsValid) {
            if (!data.gpsValid && !data.meteoValid && data.meteoStatus == null) data.meteoStatus = "WAITING GPS";
            return;
        }
        final long now = SystemClock.elapsedRealtime();
        final boolean moved = data.meteoValid && FlightData.distanceKm(data.lat, data.lon, data.meteoLat, data.meteoLon) > 10;
        final long every = data.meteoValid ? 10 * 60000L : 60000L;   // senza dato riprova ogni minuto
        if (lastMeteoTryMs != 0 && now - lastMeteoTryMs < every && !moved) return;
        if (moved && now - lastMeteoTryMs < 60000L) return;
        lastMeteoTryMs = now;
        meteoBusy = true;
        final double la = data.lat, lo = data.lon;
        new Thread(() -> {
            try {
                final java.net.URL url = new java.net.URL(String.format(java.util.Locale.ROOT,
                        "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,relative_humidity_2m", la, lo));
                final java.net.HttpURLConnection c = (java.net.HttpURLConnection) url.openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(8000);
                final StringBuilder b = new StringBuilder();
                try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
                    String line; while ((line = r.readLine()) != null) b.append(line);
                }
                final org.json.JSONObject o = new org.json.JSONObject(b.toString());
                final org.json.JSONObject cur = o.getJSONObject("current");
                data.meteoT2m = (float) cur.getDouble("temperature_2m");
                data.meteoRh2m = (float) cur.getDouble("relative_humidity_2m");
                data.meteoElevM = (float) o.optDouble("elevation", 0);
                data.meteoLat = la; data.meteoLon = lo;
                data.meteoAtMs = System.currentTimeMillis();
                data.meteoStatus = null;
                data.meteoValid = true;
            } catch (Exception e) {
                // dato vecchio ancora buono per 1 ora, poi si dichiara mancante
                if (data.meteoValid && System.currentTimeMillis() - data.meteoAtMs > 3600000L) data.meteoValid = false;
                if (!data.meteoValid) data.meteoStatus = "NO INTERNET";
            } finally {
                meteoBusy = false;
            }
        }, "Meteo").start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("avea", MODE_PRIVATE);
        data.load(prefs);
        audio = new VarioAudio(data);
        fields = new Airfields(getFilesDir());
        view = new InstrumentView(this, data, audio, () -> data.save(prefs), fields, this);
        airspaces = new Airspaces(getFilesDir());
        view.setAirspaces(airspaces);
        final InstrumentView v = view;
        new Thread(() -> {
            // prima la copia salvata dall'utente; se non c'e', la dotazione di serie dentro l'APK
            if (!fields.loadCache()) fields.loadDefault(getAssets());
            if (!airspaces.loadCache()) airspaces.loadDefault(getAssets());
            v.postInvalidate();
        }, "Campi").start();
        view.setPage(prefs.getInt("page", 0));
        setContentView(view);

        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        barometer = sensors.getDefaultSensor(Sensor.TYPE_PRESSURE);
        hasBarometer = barometer != null;
        view.setHasBarometer(hasBarometer);
        locations = (LocationManager) getSystemService(LOCATION_SERVICE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        if (hasBarometer) sensors.registerListener(this, barometer, SensorManager.SENSOR_DELAY_GAME);
        startGps();
        audio.start();
        lastTickMs = 0;
        handler.post(tick);
        view.startAnimation();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensors.unregisterListener(this);
        stopGps();
        audio.stop();
        handler.removeCallbacks(tick);
        view.stopAnimation();
        prefs.edit().putInt("page", view.getPage()).apply();
        data.save(prefs);
    }

    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ---------- tramonto: avviso 30 minuti prima, una volta al giorno ----------
    private boolean pendReserve = false, pendIct = false;
    private void checkSunset() {
        if (view.isPageLocked()) return;   // bloccata: l'avviso aspetta lo sblocco
        final long ss = data.sunsetTodayMs();
        if (ss <= 0) return;
        final long nowWall = System.currentTimeMillis();
        final long day = ss / 86400000L;
        if (day != sunsetShownDay && nowWall >= ss - 30 * 60000L && nowWall < ss) {
            sunsetShownDay = day;
            view.showAlert(InstrumentView.A_SUNSET, 10000,
                    new java.text.SimpleDateFormat("HH:mm", java.util.Locale.ITALY).format(new java.util.Date(ss)));
            audio.click(1200, 300);
        }
    }

    // ---------- spazi aerei: controllo una volta al secondo, solo in volo ----------
    private void checkAirspace(long now) {
        if (now - lastAspCheckMs < 1000) return;
        lastAspCheckMs = now;
        if (airspaces.size() == 0) return;
        if (!data.flying) { airspaces.resetAlerts(); return; }
        if (view.isPageLocked()) return;   // bloccata: nessun avviso (dopo lo sblocco si ricontrolla)
        if (!data.gpsValid) return;
        final float altM = data.baroValid ? data.altM : data.gpsAltM;
        final float groundFt = data.qfeSet ? data.qfeRefM * 3.28084f : 0f;
        final Airspaces.Hit h = airspaces.check(data.lat, data.lon, altM * 3.28084f, groundFt, data.qnhHpa);
        if (h == null) return;
        if (data.onlyCtr && h != null && h.area != null
                && !h.area.type.contains("CTR") && !h.area.cls.contains("CTR")) return;   // PAGES 2/3: ONLY CTR
        view.showAirspace(h);
        if (h.level >= 2) { audio.click(900, 200); }
        else audio.click(1200, 150);
    }

    @Override
    public void pickAirspaceFile() {
        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, REQ_ASP); }
        catch (Exception e) { view.toastFromHost("Nessuna app per scegliere i file"); }
    }

    // ---------- campi di volo (file .cup) ----------
    @Override
    public void pickCupFile() {
        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, REQ_CUP); }
        catch (Exception e) { view.toastFromHost("Nessuna app per scegliere i file"); }
    }

    @Override
    public void downloadItaly() {
        view.setBusy("Scarico i campi d'Italia...");
        new Thread(() -> {
            int n = -1;
            for (String url : new String[]{Airfields.URL_ITALIA, Airfields.URL_ITALIA_2}) {
                try { n = fields.download(url); break; } catch (Exception ignored) { }
            }
            final int got = n;
            handler.post(() -> {
                view.setBusy(null);
                if (got > 0) view.toastFromHost(got + " campi caricati");
                else {
                    // senza internet (o sito irraggiungibile): si sceglie il file dal telefono, come per gli spazi aerei
                    view.toastFromHost(got == 0 ? "File senza campi: scegli un .cup" : "Niente internet: scegli il file .cup");
                    pickCupFile();
                }
            });
        }, "DownloadCampi").start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if ((requestCode != REQ_CUP && requestCode != REQ_ASP) || resultCode != RESULT_OK || result == null || result.getData() == null) return;
        final android.net.Uri uri = result.getData();
        if (requestCode == REQ_ASP) {
            view.setBusy("Leggo gli spazi aerei...");
            new Thread(() -> {
                String msg;
                try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                    final int n = in == null ? 0 : airspaces.importStream(in);
                    msg = n > 0 ? n + " spazi aerei caricati" : "Nessuno spazio aereo: serve un file OpenAir .txt";
                } catch (Exception e) {
                    msg = "File non leggibile";
                }
                final String m = msg;
                handler.post(() -> { view.setBusy(null); view.toastFromHost(m); });
            }, "FileSpazi").start();
            return;
        }
        view.setBusy("Leggo il file...");
        new Thread(() -> {
            String msg;
            try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                final int n = in == null ? 0 : fields.importStream(in);
                msg = n > 0 ? n + " campi caricati" : "Nel file non ci sono campi di volo";
            } catch (Exception e) {
                msg = "File non leggibile";
            }
            final String m = msg;
            handler.post(() -> { view.setBusy(null); view.toastFromHost(m); });
        }, "FileCampi").start();
    }

    // ---------- GPS ----------
    private void startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (permissionAsked) { view.setGpsMessage("Permesso posizione negato"); return; }
            permissionAsked = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        try {
            if (locations.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locations.requestLocationUpdates(LocationManager.GPS_PROVIDER, 200, 0f, this, Looper.getMainLooper());
                locations.registerGnssStatusCallback(gnssCallback, handler);
                view.setGpsMessage(null);
            } else {
                view.setGpsMessage("GPS spento: attivalo nelle impostazioni");
            }
        } catch (SecurityException e) {
            view.setGpsMessage("Permesso posizione negato");
        }
    }

    private void stopGps() {
        try {
            locations.removeUpdates(this);
            locations.unregisterGnssStatusCallback(gnssCallback);
        } catch (Exception ignored) { }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startGps();
            else view.setGpsMessage("Permesso posizione negato");
        }
    }

    @Override
    public void onLocationChanged(Location l) {
        if (data.demo) return;
        final float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
        final float course = l.hasBearing() ? l.getBearing() : data.courseDeg;
        data.onGps(l.getLatitude(), l.getLongitude(), kmh, course, (float) l.getAltitude(), SystemClock.elapsedRealtime());
        // Senza barometro la quota viene dal GPS (meno precisa)
        if (!hasBarometer) {
            data.onPressure(FlightData.altitudeToPressure((float) l.getAltitude(), data.qnhHpa),
                    SystemClock.elapsedRealtimeNanos());
        }
    }

    @Override public void onProviderEnabled(String provider) { view.setGpsMessage(null); }
    @Override public void onProviderDisabled(String provider) { view.setGpsMessage("GPS spento: attivalo nelle impostazioni"); }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    // ---------- barometro ----------
    @Override
    public void onSensorChanged(SensorEvent e) {
        if (data.demo) return;
        if (e.sensor.getType() == Sensor.TYPE_PRESSURE) data.onPressure(e.values[0], e.timestamp);
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}
