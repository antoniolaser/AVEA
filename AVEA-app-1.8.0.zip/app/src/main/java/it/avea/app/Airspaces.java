package it.avea.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Spazi aerei da un file OpenAir (.txt), come la pagina "Airspace" dello strumento:
 * avvisi entro 2 km o 300 ft dai limiti, "sotto" e "dentro", e i CTR disegnati sulla mappa FIELDS.
 */
public class Airspaces {

    public static final int REF_AMSL = 0, REF_AGL = 1, REF_FL = 2;
    public static final int WARN_DIST_M = 2000;      // distanza orizzontale di avviso
    public static final int VERT_MARGIN_FT = 300;    // margine verticale

    public static class Area {
        public String name = "", type = "", cls = "";
        public int lowFt = 0, lowRef = REF_AGL, highFt = 99999, highRef = REF_AMSL;
        public double[] lat = new double[0], lon = new double[0];
        public double minLat, maxLat, minLon, maxLon;
        public int alerted = 0;      // livello gia' segnalato (0 nessuno, 1 vicino, 2 dentro)
    }

    private final List<Area> list = new ArrayList<>();
    private final File cacheFile;

    public Airspaces(File dir) { cacheFile = new File(dir, "airspace.txt"); }

    public synchronized int size() { return list.size(); }
    public synchronized Area get(int i) { return list.get(i); }

    public synchronized boolean loadCache() {
        if (!cacheFile.exists()) return false;
        try (InputStream in = new FileInputStream(cacheFile)) { return parse(in) > 0; }
        catch (Exception e) { return false; }
    }


    /**
     * Dotazione di serie: se non c'e' ancora nessuna copia salvata, legge i spazi aerei
     * inclusi nell'APK. Cosi' l'app funziona appena installata, senza scaricare niente.
     * Al primo aggiornamento scaricato dall'utente la copia salvata prende il posto di questa.
     */
    public synchronized boolean loadDefault(android.content.res.AssetManager am) {
        if (!list.isEmpty()) return true;
        try (InputStream in = am.open("data/airspace_it.txt")) { return parse(in) > 0; }
        catch (Exception e) { return false; }
    }

    public int importStream(InputStream in) throws Exception {
        final File tmp = new File(cacheFile.getPath() + ".tmp");
        try (OutputStream out = new FileOutputStream(tmp)) {
            final byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        int count;
        try (InputStream again = new FileInputStream(tmp)) { synchronized (this) { count = parse(again); } }
        if (count > 0) { if (!tmp.renameTo(cacheFile)) { cacheFile.delete(); tmp.renameTo(cacheFile); } }
        else { tmp.delete(); loadCache(); }
        return count;
    }

    // ---------- lettura OpenAir ----------
    private Area cur;
    private final List<double[]> pts = new ArrayList<>();
    private double vLat, vLon;
    private int vDir = 1;

    private int parse(InputStream in) throws Exception {
        final List<Area> out = new ArrayList<>();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.ISO_8859_1));
        String line;
        cur = null; pts.clear(); vDir = 1;
        while ((line = r.readLine()) != null) {
            final int star = line.indexOf('*');
            if (star >= 0) line = line.substring(0, star);
            line = line.trim();
            if (line.length() < 2) continue;
            final String key = line.substring(0, 2).toUpperCase(Locale.ROOT);
            final String arg = line.substring(2).trim();
            switch (key) {
                case "AC":
                    close(out);
                    cur = new Area();
                    cur.cls = arg.toUpperCase(Locale.ROOT);
                    cur.type = cur.cls;      // senza AY il tipo e' la classe (OpenAir 1)
                    vDir = 1;
                    break;
                case "AY": if (cur != null) cur.type = arg.toUpperCase(Locale.ROOT); break;
                case "AN": if (cur != null) cur.name = arg; break;
                case "AL": if (cur != null) { int[] a = parseAlt(arg); cur.lowFt = a[0]; cur.lowRef = a[1]; } break;
                case "AH": if (cur != null) { int[] a = parseAlt(arg); cur.highFt = a[0]; cur.highRef = a[1]; } break;
                case "DP":
                    if (cur != null) { double[] p = parseLatLon(arg); if (p != null) pts.add(p); }
                    break;
                case "DC":
                    if (cur != null) { try { arcPts(vLat, vLon, Double.parseDouble(arg), 0, 360, 1); } catch (Exception ignored) { } }
                    break;
                case "DA":
                    if (cur != null) {
                        final String[] f = arg.split(",");
                        try {
                            if (f.length >= 3) arcPts(vLat, vLon, Double.parseDouble(f[0].trim()),
                                    Double.parseDouble(f[1].trim()), Double.parseDouble(f[2].trim()), vDir);
                        } catch (Exception ignored) { }
                    }
                    break;
                case "DB":
                    if (cur != null) {
                        final int comma = findSecondCoordStart(arg);
                        if (comma > 0) {
                            final double[] p1 = parseLatLon(arg.substring(0, comma)), p2 = parseLatLon(arg.substring(comma + 1));
                            if (p1 != null && p2 != null) {
                                final double rNm = distNm(vLat, vLon, p1[0], p1[1]);
                                arcPts(vLat, vLon, rNm, bearing(vLat, vLon, p1[0], p1[1]), bearing(vLat, vLon, p2[0], p2[1]), vDir);
                            }
                        }
                    }
                    break;
                default:
                    if (key.charAt(0) == 'V' && cur != null) {
                        final int eq = arg.indexOf('=');
                        if (eq > 0) {
                            final char k = Character.toUpperCase(arg.charAt(0));
                            final String v = arg.substring(eq + 1).trim();
                            if (k == 'X') { double[] p = parseLatLon(v); if (p != null) { vLat = p[0]; vLon = p[1]; } }
                            else if (k == 'D') vDir = v.startsWith("-") ? -1 : 1;
                        }
                    }
                    break;
            }
        }
        close(out);
        if (!out.isEmpty()) { list.clear(); list.addAll(out); }
        return out.size();
    }

    private void close(List<Area> out) {
        if (cur != null && pts.size() >= 3 && !ignored(cur.type)) {
            final int n = pts.size();
            cur.lat = new double[n]; cur.lon = new double[n];
            cur.minLat = cur.maxLat = pts.get(0)[0];
            cur.minLon = cur.maxLon = pts.get(0)[1];
            for (int i = 0; i < n; i++) {
                cur.lat[i] = pts.get(i)[0]; cur.lon[i] = pts.get(i)[1];
                cur.minLat = Math.min(cur.minLat, cur.lat[i]); cur.maxLat = Math.max(cur.maxLat, cur.lat[i]);
                cur.minLon = Math.min(cur.minLon, cur.lon[i]); cur.maxLon = Math.max(cur.maxLon, cur.lon[i]);
            }
            out.add(cur);
        }
        cur = null;
        pts.clear();
    }

    private static boolean ignored(String t) {
        return t.equals("FIR") || t.equals("ASRA") || t.equals("NONE") || t.equals("UIR");
    }

    /** In "DB lat1 lon1, lat2 lon2" trova la virgola tra le due coordinate (dopo la prima E/W). */
    private static int findSecondCoordStart(String s) {
        final String u = s.toUpperCase(Locale.ROOT);
        int e = Math.max(u.indexOf('E'), -1);
        final int w = u.indexOf('W');
        if (e < 0 || (w >= 0 && w < e)) e = w;
        if (e < 0) return -1;
        return s.indexOf(',', e);
    }

    /** "45:26:42 N 009:16:36 E" o "45:26.7N 9:16.6E" */
    static double[] parseLatLon(String s) {
        final String u = s.toUpperCase(Locale.ROOT).replace(',', ' ');
        int h1 = -1;
        for (int i = 0; i < u.length(); i++) { final char c = u.charAt(i); if (c == 'N' || c == 'S') { h1 = i; break; } }
        if (h1 < 0) return null;
        int h2 = -1;
        for (int i = h1 + 1; i < u.length(); i++) { final char c = u.charAt(i); if (c == 'E' || c == 'W') { h2 = i; break; } }
        if (h2 < 0) return null;
        final double la = dms(u.substring(0, h1)), lo = dms(u.substring(h1 + 1, h2));
        if (Double.isNaN(la) || Double.isNaN(lo)) return null;
        return new double[]{u.charAt(h1) == 'S' ? -la : la, u.charAt(h2) == 'W' ? -lo : lo};
    }

    private static double dms(String s) {
        final String[] p = s.trim().split(":");
        try {
            double v = Double.parseDouble(p[0].trim());
            if (p.length > 1) v += Double.parseDouble(p[1].trim()) / 60.0;
            if (p.length > 2) v += Double.parseDouble(p[2].trim()) / 3600.0;
            return v;
        } catch (Exception e) { return Double.NaN; }
    }

    /** "GND", "SFC", "2000ft AMSL", "FL95", "1000ft AGL", "300m AGL", "UNL" -> {piedi, riferimento} */
    static int[] parseAlt(String s) {
        final String u = s.trim().toUpperCase(Locale.ROOT);
        if (u.startsWith("GND") || u.startsWith("SFC")) return new int[]{0, REF_AGL};
        if (u.startsWith("UNL")) return new int[]{99999, REF_AMSL};
        if (u.startsWith("FL")) {
            try { return new int[]{(int) Math.round(Double.parseDouble(u.substring(2).trim().split("[^0-9.]")[0]) * 100), REF_FL}; }
            catch (Exception e) { return new int[]{0, REF_FL}; }
        }
        int i = 0;
        while (i < u.length() && (Character.isDigit(u.charAt(i)) || u.charAt(i) == '.')) i++;
        if (i == 0) return new int[]{0, REF_AMSL};
        double v = Double.parseDouble(u.substring(0, i));
        final String rest = u.substring(i).trim();
        if (rest.startsWith("M") && !rest.startsWith("MSL")) v *= 3.28084;
        final int ref = (u.contains("AGL") || u.contains("AGND") || u.contains("GND")) ? REF_AGL : REF_AMSL;
        return new int[]{(int) Math.round(v), ref};
    }

    private void arcPts(double cLat, double cLon, double rNm, double a1, double a2, int dir) {
        final double rDeg = rNm * 1852.0 / 111320.0;
        final double cosLat = Math.cos(Math.toRadians(cLat));
        if (cosLat < 0.01) return;
        double sweep = dir > 0 ? a2 - a1 : a1 - a2;
        while (sweep <= 0) sweep += 360;
        if (sweep > 360) sweep = 360;
        final int steps = Math.max(2, (int) (sweep / 5.0));
        for (int i = 0; i <= steps; i++) {
            final double a = Math.toRadians(a1 + dir * sweep * i / steps);
            pts.add(new double[]{cLat + rDeg * Math.cos(a), cLon + rDeg * Math.sin(a) / cosLat});
        }
    }

    private static double bearing(double cLat, double cLon, double lat, double lon) {
        final double dx = (lon - cLon) * Math.cos(Math.toRadians(cLat)), dy = lat - cLat;
        double b = Math.toDegrees(Math.atan2(dx, dy));
        return b < 0 ? b + 360 : b;
    }

    private static double distNm(double cLat, double cLon, double lat, double lon) {
        final double dx = (lon - cLon) * Math.cos(Math.toRadians(cLat)), dy = lat - cLat;
        return Math.sqrt(dx * dx + dy * dy) * 111320.0 / 1852.0;
    }

    // ---------- limiti e geometria ----------
    public static int limitFt(int ft, int ref, float groundFt, float qnh) {
        if (ref == REF_AGL) return (int) (ft + groundFt);
        if (ref == REF_FL) return (int) (ft - (1013.25f - qnh) * 27.5f);   // FL -> quota QNH
        return ft;
    }

    public static String fmtLimit(int ft, int ref) {
        if (ref == REF_AGL && ft == 0) return "GND";
        if (ft >= 99999) return "UNL";
        if (ref == REF_FL) return "FL" + (ft / 100);
        return ft + " ft " + (ref == REF_AGL ? "AGL" : "AMSL");
    }

    /** Dentro / fuori e distanza dal bordo (metri), proiezione piana locale. */
    public static boolean polyTest(Area a, double lat, double lon, double[] edgeM) {
        final double kx = 111320.0 * Math.cos(Math.toRadians(lat)), ky = 111320.0;
        boolean inside = false;
        double best = 1e12;
        final int n = a.lat.length;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            final double xi = (a.lon[i] - lon) * kx, yi = (a.lat[i] - lat) * ky;
            final double xj = (a.lon[j] - lon) * kx, yj = (a.lat[j] - lat) * ky;
            if ((yi > 0) != (yj > 0) && 0 < (xj - xi) * (0 - yi) / (yj - yi) + xi) inside = !inside;
            final double dx = xj - xi, dy = yj - yi, l2 = dx * dx + dy * dy;
            double t = l2 > 0 ? -(xi * dx + yi * dy) / l2 : 0;
            t = Math.max(0, Math.min(1, t));
            final double px = xi + t * dx, py = yi + t * dy;
            best = Math.min(best, px * px + py * py);
        }
        edgeM[0] = Math.sqrt(best);
        return inside;
    }

    /** Risultato del controllo: lo spazio da segnalare (o null). */
    public static class Hit {
        public Area area;
        public int level;      // 1 vicino, 2 dentro
        public int distM;
        public int vert;       // -1 sotto, 0 dentro la quota, 1 sopra
    }

    /** Controllo una volta al secondo, solo in volo. */
    public synchronized Hit check(double lat, double lon, float altFt, float groundFt, float qnh) {
        Hit best = null;
        final double cosLat = Math.cos(Math.toRadians(lat));
        final double clearM = WARN_DIST_M * 1.5;
        final double padLat = clearM / 111320.0, padLon = clearM / (111320.0 * Math.max(cosLat, 0.1));
        final double[] edge = new double[1];
        for (Area a : list) {
            if (lat < a.minLat - padLat || lat > a.maxLat + padLat || lon < a.minLon - padLon || lon > a.maxLon + padLon) {
                a.alerted = 0;
                continue;
            }
            final float lowFt = limitFt(a.lowFt, a.lowRef, groundFt, qnh);
            final float highFt = a.highFt >= 99999 ? 1e9f : limitFt(a.highFt, a.highRef, groundFt, qnh);
            final boolean in = polyTest(a, lat, lon, edge);
            final boolean vIn = altFt >= lowFt && altFt <= highFt;
            final boolean vNear = altFt >= lowFt - VERT_MARGIN_FT && altFt <= highFt + VERT_MARGIN_FT;
            final int vert = altFt < lowFt ? -1 : (altFt > highFt ? 1 : 0);
            int level = 0;
            if (in && vIn) level = 2;
            else if ((in && vNear) || (!in && edge[0] <= WARN_DIST_M && vNear)) level = 1;
            final boolean vClear = altFt < lowFt - VERT_MARGIN_FT * 1.5f || altFt > highFt + VERT_MARGIN_FT * 1.5f;
            if (level == 0 && ((!in && edge[0] > clearM) || vClear)) a.alerted = 0;
            final int dist = in ? 0 : (int) edge[0];
            if (level > a.alerted && (best == null || level > best.level || (level == best.level && dist < best.distM))) {
                best = new Hit();
                best.area = a; best.level = level; best.distM = dist; best.vert = vert;
            }
        }
        if (best != null) best.area.alerted = best.level;
        return best;
    }

    public synchronized void resetAlerts() { for (Area a : list) a.alerted = 0; }

    /** CTR vicini per la mappa. */
    public synchronized List<Area> ctrNear(double lat, double lon, double km) {
        final List<Area> out = new ArrayList<>();
        final double dLat = km / 111.0, dLon = km / (111.0 * Math.max(0.2, Math.cos(Math.toRadians(lat))));
        for (Area a : list) {
            if (!a.type.equals("CTR")) continue;
            if (lat < a.minLat - dLat || lat > a.maxLat + dLat || lon < a.minLon - dLon || lon > a.maxLon + dLon) continue;
            out.add(a);
        }
        return out;
    }
}
