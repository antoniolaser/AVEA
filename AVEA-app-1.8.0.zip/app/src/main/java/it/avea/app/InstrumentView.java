package it.avea.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Locale;

/**
 * Il quadrante tondo dello strumento AVEA disegnato sullo schermo del telefono.
 * Tutto si disegna in coordinate "strumento" 360 x 360 (come il display rotondo dell'ESP32),
 * poi si scala alla larghezza del telefono. Sotto il quadrante: nome della pagina e stato dei sensori.
 * Swipe a destra / sinistra: pagina successiva / precedente.
 */
public class InstrumentView extends View {

    // ---------- colori (come sullo strumento) ----------
    static final int C_CYAN = 0xFF00E5FF, C_WHITE = 0xFFFFFFFF, C_YELLOW = 0xFFFFD400, C_GREEN = 0xFF22E04A,
            C_RED = 0xFFFF3B30, C_ORANGE = 0xFFFF8E00, C_GREY = 0xFF8C8C8C, C_DGREY = 0xFF3A3A3A,
            C_BEZEL = 0xFF555555;

    // ---------- pagine ----------
    // stesso ordine del giro dello strumento
    static final int P_COMPASS = 0, P_FIELDS = 1, P_HOME = 2, P_NEAREST = 3, P_METEO = 4, P_VARIO = 5, P_ALT = 6,
            P_QFE = 7, P_SPEED = 8, P_CLOCK = 9, P_TIMER = 10, P_ICT = 11, P_MANUAL = 12, P_FUEL = 13, P_GPSINFO = 14,
            P_SETTINGS = 15;
    static final int CYCLE = 16;
    static final int P_QNH = 100, P_LOG = 101, P_SEARCH = 102, P_FUELSET = 103, P_PAGES = 104, P_FIELDINFO = 105,
            P_AIRDATA = 106, P_DA = 107, P_CARB = 108, P_VIS = 109, P_LUBBER = 110, P_HOMEFIELD = 111, P_SAVEDLOG = 112;
    static final String[] NAMES = {"COMPASS", "FIELDS", "GO TO HOME", "NEAREST FIELDS", "METEO", "VARIO", "ALTIMETER",
            "QFE", "GND SPEED", "GPS CLOCK", "AUTOMATIC FLIGHT TIMER", "ICT", "MANUAL FLIGHT TIMER", "FUEL ESTIMATE",
            "GPS INFO", "SETTINGS"};
    private final G g = new G();
    private int pagesSub = 0;   // 0 = PAGES 1/3, 1 = PAGES 2/3, 2 = PAGES 3/3 (clic sul titolo)
    private boolean frRwyView = false, frRwySuppressed = false;   // vista pista: come frRwyView del firmware
    private int logIdx = 0;
    private boolean homeConfirm = false;

    /** Azioni che servono all'Activity (scelta file, download). */
    public interface Host {
        void pickCupFile();
        void downloadItaly();
        void pickAirspaceFile();
    }

    // ---------- avvisi a tutto schermo ----------
    static final int A_NONE = 0, A_ICT = 1, A_RESERVE = 2, A_SUNSET = 3, A_AIRSPACE = 4;
    private Airspaces.Hit aspHit = null;
    public void showAirspace(Airspaces.Hit h) { aspHit = h; showAlert(A_AIRSPACE, 8000, null); }
    private int alert = A_NONE;
    private long alertUntil = 0;
    private String alertText = "";
    public void showAlert(int type, long durationMs, String txt) {
        if (pageLocked) return;        // pagina bloccata: nessun avviso
        if (d.alertsMuted) return;     // PAGES 3/3: DON'T SHOW ALERTS
        alert = type; alertText = txt == null ? "" : txt;
        alertUntil = SystemClock.uptimeMillis() + durationMs;
        postInvalidate();
    }

    private final Airfields fields;
    private Airspaces airspaces;
    public void setAirspaces(Airspaces a) { airspaces = a; }
    private final Host host;
    private String query = "";
    private int nearestScroll = 0;
    private int frIdx = 0;                                  // zoom di FIELDS
    static final float[] FR_KM = {30, 20, 10, 8, 4, 2};
    private boolean frAuto = true;
    private int infoField = -1;
    private String busyText = null;

    private final FlightData d;
    private final VarioAudio audio;
    private final Runnable saver;
    private int page = P_ALT;
    private int returnPage = P_ALT;
    private boolean hasBaro = true;
    private String gpsMessage = null;
    private String toast = null;
    private long toastUntil = 0;

    private long lastFrameMs = 0;
    private boolean animating = false;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final Paint.FontMetrics fm = new Paint.FontMetrics();

    // trasformazione schermo <-> coordinate strumento
    private float sc = 1f, ox = 0f, oy = 0f;

    private final GestureDetector gestures;

    public InstrumentView(Context ctx, FlightData data, VarioAudio audio, Runnable saver, Airfields fields, Host host) {
        super(ctx);
        G.loadFonts(ctx.getAssets());   // caratteri veri dello strumento
        this.fields = fields;
        this.host = host;
        this.d = data;
        this.audio = audio;
        this.saver = saver;
        setBackgroundColor(Color.BLACK);
        tp.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        gestures = new GestureDetector(ctx, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null) return false;
                final float dx = e2.getX() - e1.getX(), dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > Math.abs(dy) * 1.3f && Math.abs(dx) > 80) {
                    swipe(dx < 0 ? +1 : -1);
                    return true;
                }
                if (page == P_SAVEDLOG && Math.abs(dy) > 80 && !d.logs.isEmpty()) {   // swipe su/giu': log successivo
                    final int n = d.logs.size();
                    logIdx = (logIdx + (dy < 0 ? 1 : -1) + n) % n;
                    audio.click(1500, 60);
                    invalidate();
                    return true;
                }
                if (page == P_NEAREST && Math.abs(dy) > 80) {      // swipe su/giu': campi successivi
                    nearestScroll = Math.max(0, Math.min(6, nearestScroll + (dy < 0 ? 3 : -3)));
                    invalidate();
                    return true;
                }
                if (page == P_FIELDS && frRwyView && Math.abs(dy) > 80) {   // come il firmware: lo swipe scaccia la vista pista
                    frRwyView = false; frRwySuppressed = true;
                    audio.click(1300, 40);
                    invalidate();
                    return true;
                }
                if (page == P_FIELDS && Math.abs(dy) > 80) {       // swipe su/giu': zoom (si esce dall'automatico)
                    frAuto = false;
                    frIdx = Math.max(0, Math.min(FR_KM.length - 1, frIdx + (dy < 0 ? 1 : -1)));
                    audio.click(1300, 40);
                    invalidate();
                    return true;
                }
                return false;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                tap((e.getX() - ox) / sc, (e.getY() - oy) / sc);
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                longPress((e.getX() - ox) / sc, (e.getY() - oy) / sc);
            }
        });
    }

    public void setPage(int pg) { page = (pg >= 0 && pg < CYCLE) ? pg : P_ALT; }
    public void setBusy(String s) { busyText = s; postInvalidate(); }
    public void toastFromHost(String s) { showToast(s); postInvalidate(); }
    private boolean pageOn(int i) { return i == P_SETTINGS || ((d.pagesMask >> i) & 1L) != 0; }
    public int getPage() { return page < CYCLE ? page : returnPage; }
    public void setHasBarometer(boolean b) { hasBaro = b; }
    public void setGpsMessage(String m) { gpsMessage = m; postInvalidate(); }

    public void startAnimation() {
        animating = true;
        lastFrameMs = 0;
        postInvalidateOnAnimation();
    }
    public void stopAnimation() { animating = false; }

    private void showToast(String s) { toast = s; toastUntil = SystemClock.uptimeMillis() + 2500; }

    // ---------- blocco della pagina (come lo strumento) ----------
    // Dito fermo 2 secondi su una pagina del giro: blocca / sblocca. Bloccata: swipe e tocchi ignorati,
    // lucchetto rosso lampeggiante in basso a destra, nessun avviso. Alla riapertura dell'app e' sbloccata.
    private boolean pageLocked = false;
    private long lockSplashUntil = 0;
    private boolean lockGestureDone = false;
    private float lockDownX, lockDownY;
    public boolean isPageLocked() { return pageLocked; }
    private boolean lockablePage() { return page < CYCLE && page != P_SETTINGS; }
    private final Runnable lockRunnable = new Runnable() {
        @Override public void run() {
            if (!lockablePage() || alert != A_NONE) return;
            pageLocked = !pageLocked;
            lockGestureDone = true;
            drag = DR_NONE; dragPending = DR_NONE;
            if (pageLocked) { lockSplashUntil = SystemClock.uptimeMillis() + 1000; audio.click(1000, 60); audio.click(1600, 90); }
            else { lockSplashUntil = 0; audio.click(1600, 60); audio.click(1000, 90); }
            invalidate();
        }
    };
    private void drawLockShape(float x, float y, float s, int c) {
        g.fillArc(x, y - 6 * s, 5.5f * s, 8.5f * s, 180, 360, c);
        g.fillRect(x - 8.5f * s, y - 6 * s, 3 * s, 6 * s, c); g.fillRect(x + 5.5f * s, y - 6 * s, 3 * s, 6 * s, c);
        g.fillRoundRect(x - 11 * s, y - 1 * s, 22 * s, 17 * s, 3 * s, c);
        g.fillCircle(x, y + 6 * s, 2.4f * s, G.BLACK); g.fillRect(x - 1 * s, y + 7 * s, 2 * s, 5 * s, G.BLACK);
    }
    private void drawLock() {
        if (!pageLocked) return;
        if (SystemClock.uptimeMillis() < lockSplashUntil) {   // appena bloccata: lucchetto grande al centro
            g.fillCircle(180, 180, 70, G.BLACK);
            g.drawCircle(180, 180, 70, G.RED); g.drawCircle(180, 180, 69, G.RED);
            drawLockShape(180, 170, 2.6f, G.RED);
            g.ui("LOCKED", 180, 230, G.MC, G.RED, 0.55f);
            return;
        }
        final boolean on = (SystemClock.uptimeMillis() / 500) % 2 == 0;
        final int c = on ? G.RED : G.color565(70, 0, 0);
        g.fillCircle(224, 332, 19, G.BLACK);
        g.drawCircle(224, 332, 19, c); g.drawCircle(224, 332, 18, c);
        drawLockShape(224, 328, 0.8f, c);
    }

    // ---------- gesti ----------
    private void swipe(int dir) {
        if (page == P_DA) page = P_CARB;            // giro dalla SENSOR: DA -> CARB ICE -> VISIBILITY -> SENSOR
        else if (page == P_CARB) page = P_VIS;
        else if (page == P_VIS) page = P_METEO;
        else if (page == P_SAVEDLOG) page = P_LOG;
        else if (page == P_LOG) page = P_TIMER;
        else if (page == P_HOMEFIELD || page == P_LUBBER) { homeConfirm = false; page = P_HOME; }
        else if (page >= CYCLE) {      // le altre pagine secondarie si chiudono con uno swipe
            page = returnPage;
        } else {
            int n = page;
            for (int k = 0; k < CYCLE; k++) {          // salta le pagine spente in PAGES
                n = (n + dir + CYCLE) % CYCLE;
                if (pageOn(n)) break;
            }
            page = n;
        }
        audio.click(1500, 60);
        invalidate();
    }

    private static boolean in(float x, float y, float l, float t, float w, float h) {
        return x >= l && x <= l + w && y >= t && y <= t + h;
    }

    private void openSub(int sub) { returnPage = page; page = sub; audio.click(1200, 50); }

    private void tap(float x, float y) {
        if (alert != A_NONE && SystemClock.uptimeMillis() < alertUntil) { alert = A_NONE; invalidate(); return; }
        switch (page) {
            case P_HOME:   // GO TO HOME: centro = HOME FIELD, in alto = LUBBER LINE, in basso = HOME (annulla GO TO)
                if (in(x, y, 110, 125, 140, 140)) { homeConfirm = false; openSub(P_HOMEFIELD); }
                else if (d.lubberEdit && in(x, y, 110, 30, 140, 85)) openSub(P_LUBBER);
                else if (d.gotoField && in(x, y, 110, 272, 140, 63)) {
                    d.gotoField = false; d.lubberLegValid = false; gotoIdx = -1;
                    audio.click(1500, 80); showToast("GO TO HOME");
                }
                break;
            case P_HOMEFIELD:
                if (in(x, y, 68, 200, 100, 38)) {          // SET HOME: due tocchi (conferma)
                    if (!homeConfirm) { homeConfirm = true; audio.click(1200, 50); }
                    else if (d.gpsValid) {
                        d.homeLat = d.lat; d.homeLon = d.lon; d.homeSet = true; d.lubberLegValid = false;
                        homeConfirm = false; saver.run(); audio.click(1800, 150); showToast("HOME salvata qui");
                    } else { homeConfirm = false; showToast("Serve il GPS per salvare la HOME"); }
                } else if (in(x, y, 192, 200, 100, 38)) {   // RESET
                    d.homeSet = false; d.lubberLegValid = false; homeConfirm = false; saver.run(); audio.click(900, 80);
                    showToast("HOME cancellata");
                } else if (in(x, y, 100, 257, 160, 61)) {   // GO TO: scelta del campo
                    homeConfirm = false; page = P_NEAREST; audio.click(1200, 50);
                } else if (in(x, y, 90, 60, 180, 130) || y > 320) { homeConfirm = false; page = P_HOME; audio.click(1200, 50); }
                break;
            case P_LUBBER:
                if (NavPages.lubberTap(d, x, y)) { saver.run(); audio.click(1300, 40); }
                else if (y > 260) { page = P_HOME; audio.click(1200, 50); }
                break;
            case P_METEO:
                if (in(x, y, 85, 275, 190, 45)) openSub(P_AIRDATA);
                break;
            case P_AIRDATA: page = P_DA; audio.click(1200, 50); break;
            case P_DA: page = P_CARB; audio.click(1200, 50); break;
            case P_CARB: page = P_VIS; audio.click(1200, 50); break;
            case P_VIS: page = P_METEO; audio.click(1200, 50); break;
            case P_ALT:
                if (in(x, y, 115, 292, 130, 48)) openSub(P_QNH);
                else if (in(x, y, 120, 228, 120, 58)) { d.speedKnots = !d.speedKnots; saver.run(); audio.click(1200, 40); }
                break;
            case P_QFE:
                if (in(x, y, 115, 290, 130, 46)) { d.resetQfe(); saver.run(); audio.click(1500, 80); showToast("QFE azzerato"); }
                else if (in(x, y, 90, 100, 180, 150)) { d.unitsMeters = !d.unitsMeters; saver.run(); audio.click(1200, 40); }
                break;
            case P_SPEED:
                if (in(x, y, 100, 110, 160, 170)) { d.speedKnots = !d.speedKnots; saver.run(); audio.click(1200, 40); }
                break;
            case P_VARIO:
                if (in(x, y, 80, 80, 200, 200)) { d.unitsMeters = !d.unitsMeters; saver.run(); audio.click(1200, 40); }
                break;
            case P_NEAREST: tapNearest(x, y); break;
            case P_SEARCH: tapSearch(x, y); break;
            case P_FIELDS:
                if (in(x, y, 120, 120, 120, 120)) {
                    final int fi = fieldsFocus();
                    if (fi >= 0) { infoField = fi; openSub(P_FIELDINFO); }
                } else if (in(x, y, 95, 290, 170, 50)) { frAuto = true; audio.click(1300, 40); showToast("Zoom automatico"); }
                break;
            case P_FIELDINFO: page = returnPage; break;
            case P_ICT:
                if (in(x, y, 25, 220, 90, 55)) { d.ictMinutes = Math.max(1, d.ictMinutes - 1); d.ictStartMs = 0; saver.run(); audio.click(1000, 30); }
                else if (in(x, y, 245, 220, 90, 55)) { d.ictMinutes = Math.min(120, d.ictMinutes + 1); d.ictStartMs = 0; saver.run(); audio.click(1400, 30); }
                else if (in(x, y, 85, 290, 190, 45)) { d.ictOn = !d.ictOn; d.ictStartMs = 0; saver.run(); audio.click(1200, 50); }
                break;
            case P_MANUAL:
                if (in(x, y, 30, 235, 95, 45)) { d.manStart(); audio.click(1500, 60); }
                else if (in(x, y, 132, 235, 95, 45)) { d.manStop(); saver.run(); audio.click(1200, 60); }
                else if (in(x, y, 235, 235, 95, 45)) { d.manReset(); saver.run(); audio.click(900, 60); }
                break;
            case P_FUEL:
                if (in(x, y, 90, 120, 180, 150)) openSub(P_FUELSET);
                break;
            case P_FUELSET: tapFuelSetup(x, y); break;
            case P_PAGES: tapPages(x, y); break;
            case P_TIMER:
                if (in(x, y, 85, 275, 190, 45)) openSub(P_LOG);
                break;
            case P_LOG:
                if (in(x, y, 105, 298, 150, 40)) { logIdx = 0; page = P_SAVEDLOG; audio.click(1200, 50); }
                break;
            case P_SAVEDLOG: page = P_LOG; audio.click(1200, 50); break;
            case P_SETTINGS:
                for (int i = 0; i < 4; i++) {
                    if (in(x, y, 50, 66 + i * 38, 260, 34)) {
                        if (i == 0) d.audioOn = !d.audioOn;
                        else if (i == 1) d.demo = !d.demo;
                        else if (i == 2) d.unitsMeters = !d.unitsMeters;
                        else d.speedKnots = !d.speedKnots;
                        saver.run();
                        audio.click(1200, 50);
                    }
                }
                if (in(x, y, 60, 222, 115, 40)) openSub(P_PAGES);
                else if (in(x, y, 185, 222, 115, 40)) host.pickCupFile();
                else if (in(x, y, 60, 270, 115, 40)) host.downloadItaly();
                else if (in(x, y, 185, 270, 115, 40)) host.pickAirspaceFile();
                break;
            case P_QNH:
                if (in(x, y, 40, 80, 130, 60)) { d.setQnh(d.qnhHpa - 1f); audio.click(1000, 30); }
                else if (in(x, y, 190, 80, 130, 60)) { d.setQnh(d.qnhHpa + 1f); audio.click(1400, 30); }
                else if (in(x, y, 40, 215, 130, 50)) d.unitsMeters = true;
                else if (in(x, y, 190, 215, 130, 50)) d.unitsMeters = false;
                else if (in(x, y, 80, 275, 200, 40)) { saver.run(); page = returnPage; audio.click(1500, 80); }
                break;
            default:
                break;
        }
        invalidate();
    }

    private void longPress(float x, float y) {
        if (page == P_QNH && in(x, y, 30, 145, 300, 50) && d.baroValid && d.gpsValid) {
            // tenendo premuto sul valore: QNH dalla quota GPS (utile a terra senza METAR)
            final float q = d.pressureHpa / (float) Math.pow(1.0 - d.gpsAltM / 44330.0, 5.255);
            d.setQnh(Math.round(q));
            saver.run();
            showToast("QNH dalla quota GPS");
        }
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final float x = (e.getX() - ox) / sc, y = (e.getY() - oy) / sc;
        switch (e.getActionMasked()) {   // blocco della pagina: dito fermo 2 secondi
            case MotionEvent.ACTION_DOWN:
                lockGestureDone = false; lockDownX = x; lockDownY = y;
                removeCallbacks(lockRunnable);
                if (lockablePage()) postDelayed(lockRunnable, 2000);
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(x - lockDownX) > 15 || Math.abs(y - lockDownY) > 15) removeCallbacks(lockRunnable);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(lockRunnable);
                break;
            default: break;
        }
        if (lockGestureDone) {   // il tocco lungo ha bloccato / sbloccato: niente altro
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) lockGestureDone = false;
            return true;
        }
        if (pageLocked) return true;   // pagina bloccata: swipe e tocchi ignorati
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                // il trascinamento della soglia parte solo se il dito si muove LUNGO l'arco: uno swipe
                // che parte dall'arco (verso il centro o il bordo) cambia pagina come altrove
                dragPending = alert == A_NONE ? dragStart(x, y) : DR_NONE;
                drag = DR_NONE; dragDownX = x; dragDownY = y;
                break;
            case MotionEvent.ACTION_MOVE:
                if (drag != DR_NONE) { dragMove(x, y); invalidate(); return true; }
                if (dragPending != DR_NONE && (Math.abs(x - dragDownX) >= 8 || Math.abs(y - dragDownY) >= 8)) {
                    if (arcDragIsRadial(dragDownX, dragDownY, x, y)) dragPending = DR_NONE;
                    else { drag = dragPending; dragPending = DR_NONE; audio.click(1300, 30); dragMove(x, y); invalidate(); return true; }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragPending = DR_NONE;
                if (drag != DR_NONE) { drag = DR_NONE; saver.run(); audio.click(1500, 50); invalidate(); return true; }
                break;
            default: break;
        }
        return gestures.onTouchEvent(e) || super.onTouchEvent(e);
    }
    private int dragPending = DR_NONE;
    private float dragDownX, dragDownY;
    private static boolean arcDragIsRadial(float sx, float sy, float x, float y) {
        final float rx = sx - 179.5f, ry = sy - 179.5f, rl = (float) Math.hypot(rx, ry);
        if (rl < 1f) return true;
        final float mx = x - sx, my = y - sy;
        return Math.abs((mx * rx + my * ry) / rl) > Math.abs((mx * ry - my * rx) / rl);
    }

    // ---------- regolazioni con il dito sugli archi (come sullo strumento) ----------
    static final int DR_NONE = 0, DR_YEL = 1, DR_RED = 2, DR_QLOW = 3, DR_QHIGH = 4, DR_FUEL = 5;
    private int drag = DR_NONE;

    private static float mathAng(float x, float y) { return (float) Math.toDegrees(Math.atan2(180 - y, x - 180)); }

    /** Valore sotto il dito sull'arco della pagina (km/h, metri o frazione del serbatoio), NaN se fuori. */
    private float dragValue(float x, float y) {
        final float r = (float) Math.hypot(x - 180, y - 180);
        if (r < 120 || r > 196) return Float.NaN;
        float a = mathAng(x, y);
        switch (page) {
            case P_ALT: {      // arco GS a destra: -60..+60 gradi
                if (a < -68 || a > 68) return Float.NaN;
                final float u = Math.max(0f, Math.min(1f, (a + 60f) / 120f)) * FlightPages.unitMax(d);
                return d.speedKnots ? u * 1.852f : u;
            }
            case P_SPEED: {    // da 225 a -45 gradi
                if (a < -90) a += 360;
                if (a < -53 || a > 233) return Float.NaN;
                final float u = Math.max(0f, Math.min(1f, (225f - a) / 270f)) * FlightPages.unitMax(d);
                return d.speedKnots ? u * 1.852f : u;
            }
            case P_QFE: {      // arco a sinistra, specchiato
                float q = 180f - a;
                if (q > 180) q -= 360;
                if (q < -68 || q > 68) return Float.NaN;
                final float u = Math.max(0f, Math.min(1f, (q + 60f) / 120f)) * FlightPages.qfeMaxShown(d);
                return d.unitsMeters ? u : u / 3.28084f;
            }
            case P_FUEL: {     // da 135 a 405 gradi (orari, da ore 3)
                float sa = (float) Math.toDegrees(Math.atan2(y - 180, x - 180));
                if (sa < 0) sa += 360;
                if (sa < 90) sa += 360;
                if (sa < 120 || sa > 420) return Float.NaN;
                return Math.max(0f, Math.min(1f, (sa - 135f) / 270f));
            }
            default: return Float.NaN;
        }
    }

    private int dragStart(float x, float y) {
        if (d.flying && !d.demo) return DR_NONE;   // in volo le soglie non si cambiano (come sullo strumento)
        if (page == P_ALT && x < 230) return DR_NONE;
        if (page == P_QFE && x > 130) return DR_NONE;
        final float v = dragValue(x, y);
        if (Float.isNaN(v)) return DR_NONE;
        if (page == P_SPEED || page == P_ALT) return Math.abs(v - d.gsYellowKmh) <= Math.abs(v - d.gsRedKmh) ? DR_YEL : DR_RED;
        if (page == P_QFE) return Math.abs(v - d.qfeLowM) <= Math.abs(v - d.qfeHighM) ? DR_QLOW : DR_QHIGH;
        if (page == P_FUEL) return DR_FUEL;
        return DR_NONE;
    }

    private void dragMove(float x, float y) {
        final float v = dragValue(x, y);
        if (Float.isNaN(v)) return;
        if (drag == DR_YEL || drag == DR_RED) {
            final int kmh = Math.round(v / 5f) * 5;
            if (drag == DR_YEL) {   // la gialla puo' spingere avanti la rossa
                d.gsYellowKmh = Math.max(90, Math.min(290, kmh));
                if (d.gsRedKmh < d.gsYellowKmh + 10) d.gsRedKmh = d.gsYellowKmh + 10;
            } else d.gsRedKmh = Math.max(d.gsYellowKmh + 10, Math.min(300, kmh));
        } else if (drag == DR_QLOW || drag == DR_QHIGH) {
            final int m = Math.round(v / 10f) * 10;
            if (drag == DR_QLOW) d.qfeLowM = Math.max(0, Math.min(d.qfeHighM - 20, m));
            else d.qfeHighM = Math.max(d.qfeLowM + 20, Math.min(9000, m));
        } else if (drag == DR_FUEL) {
            d.fuelLiters = Math.round(v * d.fuelTankL * 2f) / 2f;
            d.fuelReserveAlerted = d.fuelLiters <= d.fuelReserveL();
        }
    }
    private int dragGs() { return drag == DR_YEL ? 1 : (drag == DR_RED ? 2 : 0); }
    private int dragQfe() { return drag == DR_QLOW ? 1 : (drag == DR_QHIGH ? 2 : 0); }


    // ---------- disegno: strumenti di base ----------
    private void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align al) {
        tp.setTextSize(size);
        tp.setColor(color);
        tp.setTextAlign(al);
        tp.getFontMetrics(fm);
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, tp);
    }
    private void text(Canvas c, String s, float x, float y, float size, int color) {
        text(c, s, x, y, size, color, Paint.Align.CENTER);
    }
    /** Testo che si restringe per stare in una larghezza massima. */
    private void textFit(Canvas c, String s, float x, float y, float size, int color, float maxW) {
        tp.setTextSize(size);
        final float w = tp.measureText(s);
        if (w > maxW) size *= maxW / w;
        text(c, s, x, y, size, color);
    }

    private static float px(float r, float aDeg) { return 180f + r * (float) Math.sin(Math.toRadians(aDeg)); }
    private static float py(float r, float aDeg) { return 180f - r * (float) Math.cos(Math.toRadians(aDeg)); }

    private void line(Canvas c, float x0, float y0, float x1, float y1, int color, float w) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(w);
        p.setColor(color);
        c.drawLine(x0, y0, x1, y1, p);
    }

    private void button(Canvas c, float x, float y, float w, float h, String label, int color, float size) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f);
        p.setColor(color);
        rf.set(x, y, x + w, y + h);
        c.drawRoundRect(rf, 8, 8, p);
        text(c, label, x + w / 2f, y + h / 2f, size, color);
    }

    private void checkbox(Canvas c, float x, float y, boolean on, String label) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f);
        p.setColor(on ? C_GREEN : C_GREY);
        rf.set(x, y, x + 24, y + 24);
        c.drawRoundRect(rf, 4, 4, p);
        if (on) {
            p.setStyle(Paint.Style.FILL);
            rf.set(x + 6, y + 6, x + 18, y + 18);
            c.drawRoundRect(rf, 2, 2, p);
        }
        text(c, label, x + 36, y + 12, 17, on ? C_WHITE : C_GREY, Paint.Align.LEFT);
    }




    // ---------- disegno della schermata ----------
    @Override
    protected void onDraw(Canvas c) {
        lastFrameMs = SystemClock.uptimeMillis();
        if (d.rotate180) { c.save(); c.rotate(180, getWidth() / 2f, getHeight() / 2f); }   // PAGES 2/3
        FlightPages.stepNeedles(d);

        final int W = getWidth(), H = getHeight();
        final float dial = Math.min(W, H * 0.78f) * 0.96f;
        sc = dial / 360f;
        ox = (W - dial) / 2f;
        oy = Math.max(0f, (H * 0.86f - dial) / 2f);

        c.save();
        c.translate(ox, oy);
        c.scale(sc, sc);
        // fondo e cornice del quadrante
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.BLACK);
        c.drawCircle(180, 180, 180, p);
        path.reset();
        path.addCircle(180, 180, 180, Path.Direction.CW);
        c.save();
        c.clipPath(path);
        g.begin(c);
        switch (page) {
            case P_COMPASS: NavPages.compass(g, d); break;
            case P_FIELDS: drawFields(c); break;
            case P_HOME: d.navRwyTens = navRunwayTens(); NavPages.goHome(g, d); break;
            case P_NEAREST: drawNearest(c); break;
            case P_METEO: MeteoPages.sensor(g, d); break;
            case P_VARIO: FlightPages.vario(g, d); break;
            case P_ALT: FlightPages.altimeter(g, d, dragGs()); break;
            case P_QFE: FlightPages.qfe(g, d, dragQfe()); break;
            case P_SPEED: FlightPages.gpsSpeed(g, d, dragGs()); break;
            case P_CLOCK: MiscPages.gpsClock(g, d); break;
            case P_TIMER: MiscPages.autoTimer(g, d); break;
            case P_ICT: MiscPages.ict(g, d); break;
            case P_MANUAL: MiscPages.manualTimer(g, d); break;
            case P_FUEL: MiscPages.fuel(g, d, false); break;
            case P_GPSINFO: MiscPages.gpsInfo(g, d, hasBaro); break;
            case P_SETTINGS: drawSettings(c); break;
            case P_QNH: MiscPages.qnh(g, d); break;
            case P_LOG: MiscPages.flightLog(g, d); break;
            case P_SAVEDLOG: MiscPages.savedLog(g, d, logIdx); break;
            case P_SEARCH: drawSearch(c); break;
            case P_FIELDINFO: drawFieldInfo(c); break;
            case P_FUELSET: drawFuelSetup(c); break;
            case P_PAGES: drawPages(c); break;
            case P_AIRDATA: MeteoPages.airData(g, d); break;
            case P_DA: MeteoPages.densityAlt(g, d); break;
            case P_CARB: MeteoPages.carbIce(g, d); break;
            case P_VIS: MeteoPages.visibility(g, d); break;
            case P_LUBBER: NavPages.lubberLine(g, d); break;
            case P_HOMEFIELD: NavPages.homeField(g, d, homeConfirm); break;
            default: break;
        }
        drawLowGs(c);
        drawAlert(c);
        drawLock();
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f);
        p.setColor(C_BEZEL);
        c.drawCircle(180, 180, 178.5f, p);
        c.restore();

        drawFooter(c, W, H, dial);
        if (d.rotate180) c.restore();   // chiude la rotazione di PAGES 2/3
        if (animating) postInvalidateOnAnimation();
    }

    private void drawFooter(Canvas c, int W, int H, float dial) {
        final float u = W / 360f;               // unita' del piede pagina
        float y = oy + dial + 34 * u;
        final String name = page < CYCLE ? NAMES[page] : subName(page);
        text(c, name, W / 2f, y, 20 * u, C_CYAN);
        // pallini delle pagine
        y += 26 * u;
        int on = 0;
        for (int i = 0; i < CYCLE; i++) if (pageOn(i)) on++;
        final float gap = 15 * u;
        float xd = W / 2f - gap * (on - 1) / 2f;
        for (int i = 0; i < CYCLE; i++) {
            if (!pageOn(i)) continue;
            p.setStyle(Paint.Style.FILL);
            p.setColor(i == getPage() ? C_CYAN : C_DGREY);
            c.drawCircle(xd, y, (i == getPage() ? 4.5f : 3.5f) * u, p);
            xd += gap;
        }
        // stato dei sensori
        y += 30 * u;
        String s = (d.gpsValid ? "GPS " + d.satsUsed + "/" + d.satsInView + " sat" : "GPS: attesa fix")
                + "   " + (hasBaro ? (d.baroValid ? "BARO " + String.format(Locale.ROOT, "%.1f hPa", d.pressureHpa) : "BARO ...")
                : "senza barometro: quota GPS");
        if (d.demo) s = "DEMO: volo simulato";
        text(c, s, W / 2f, y, 14 * u, d.demo ? C_YELLOW : C_GREY);
        if (gpsMessage != null && !d.demo) text(c, gpsMessage, W / 2f, y + 22 * u, 14 * u, C_ORANGE);
        if (busyText != null) text(c, busyText, W / 2f, y + 44 * u, 16 * u, C_CYAN);
        else if (toast != null && SystemClock.uptimeMillis() < toastUntil) {
            text(c, toast, W / 2f, y + 44 * u, 16 * u, C_YELLOW);
        }
    }







    private void drawPlane(Canvas c, float x, float y, float s, int color) {
        path.reset();
        final float[] pts = {0, -40, 6, -10, 45, 8, 45, 18, 6, 10, 4, 32, 16, 40, 16, 46, 0, 42,
                -16, 46, -16, 40, -4, 32, -6, 10, -45, 18, -45, 8, -6, -10};
        path.moveTo(x + pts[0] * s, y + pts[1] * s);
        for (int i = 2; i < pts.length; i += 2) path.lineTo(x + pts[i] * s, y + pts[i + 1] * s);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawPath(path, p);
    }





    // ---------- SETTINGS ----------
    private void drawSettings(Canvas c) {
        text(c, "SETTINGS", 180, 40, 22, C_CYAN);
        checkbox(c, 64, 70, d.audioOn, d.audioOn ? "AUDIO ON" : "AUDIO OFF");
        checkbox(c, 64, 108, d.demo, "DEMO (volo simulato)");
        checkbox(c, 64, 146, !d.unitsMeters, "QUOTA IN PIEDI");
        checkbox(c, 64, 184, d.speedKnots, "VELOCITA' IN NODI");
        button(c, 60, 222, 115, 40, "PAGES", C_CYAN, 17);
        button(c, 185, 222, 115, 40, "FILE .cup", C_YELLOW, 17);
        button(c, 60, 270, 115, 40, "CAMPI ITALIA", C_GREEN, 14);
        button(c, 185, 270, 115, 40, "SPAZI AEREI", 0xFFFF6FA0, 14);
        text(c, fields.size() + " campi   " + (airspaces == null ? 0 : airspaces.size()) + " spazi aerei   app 1.6.3", 180, 326, 12, C_GREY);
    }


    // =====================================================================================
    // Pagine aggiunte nella versione 1.1
    // =====================================================================================

    private String subName(int pg) {
        switch (pg) {
            case P_QNH: return "SET QNH";
            case P_LOG: return "FLIGHT LOG";
            case P_SEARCH: return "SEARCH";
            case P_FUELSET: return "FUEL SETUP";
            case P_PAGES: return "PAGES";
            case P_FIELDINFO: return "FIELD INFO";
            case P_AIRDATA: return "AIR DATA";
            case P_DA: return "DENSITY ALTITUDE";
            case P_CARB: return "CARB ICE RISK";
            case P_VIS: return "VISIBILITY";
            case P_LUBBER: return "LUBBER LINE";
            case P_HOMEFIELD: return "HOME FIELD";
            case P_SAVEDLOG: return "SAVED LOGS";
            default: return "";
        }
    }

    private int gotoIdx = -1;
    private int homeRwyCache = 0;
    private long homeRwyMs = 0;
    /** Pista della meta in decine di gradi: il campo del GO TO, oppure il campo entro 2 km da casa (0 = sconosciuta). */
    private int navRunwayTens() {
        int deg = -1;
        if (d.gotoField) {
            if (gotoIdx >= 0 && gotoIdx < fields.size()) deg = fields.get(gotoIdx).rwyDeg;
        } else {
            final long now = SystemClock.uptimeMillis();
            if (now - homeRwyMs < 2000) return homeRwyCache;
            homeRwyMs = now;
            if (d.homeSet && fields.size() > 0) {
                final int[] n = fields.nearest(d.homeLat, d.homeLon, 1);
                if (n.length > 0) {
                    final Airfields.Field f = fields.get(n[0]);
                    if (FlightData.distanceKm(d.homeLat, d.homeLon, f.lat, f.lon) < 2.0) deg = f.rwyDeg;
                }
            }
        }
        int t = deg < 0 ? 0 : Math.round(deg / 10f);
        if (deg >= 0 && t == 0) t = 36;
        if (!d.gotoField) homeRwyCache = t;
        return t;
    }

    private void setGoto(int fi) {
        final Airfields.Field f = fields.get(fi);
        d.gotoField = true;
        d.gotoName = f.name;
        d.gotoLat = f.lat;
        d.gotoLon = f.lon;
        gotoIdx = fi;
        d.lubberLegValid = false;
        page = P_HOME;
        audio.click(1800, 120);
        showToast("GO TO " + f.name);
    }

    private static String distText(double km) {
        return km < 10 ? String.format(Locale.ROOT, "%.1f km", km) : Math.round(km) + " km";
    }

    private String fieldSub(Airfields.Field f) {
        final StringBuilder b = new StringBuilder();
        if (!f.rwyText().isEmpty()) b.append(f.rwyText()).append("  ");
        if (f.rwyLenM > 0) b.append(f.rwyLenM).append(" m  ");
        b.append(f.freq);
        return b.toString().trim();
    }

    /** Triangolo che punta al campo, relativo alla rotta. */
    private void arrow(Canvas c, float x, float y, float relDeg, int color) {
        c.save();
        c.rotate(relDeg, x, y);
        path.reset();
        path.moveTo(x, y - 13); path.lineTo(x + 10, y + 10); path.lineTo(x, y + 5); path.lineTo(x - 10, y + 10); path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawPath(path, p);
        c.restore();
    }

    private float relBearing(double lat, double lon) {
        final double brg = FlightData.bearingDeg(d.lat, d.lon, lat, lon);
        return (float) (((brg - (d.speedKmh > 3 ? d.courseDeg : 0)) + 360) % 360);
    }

    private boolean noFields(Canvas c) {
        if (fields.size() > 0) return false;
        text(c, "nessun campo caricato", 180, 150, 20, C_YELLOW);
        text(c, "SETTINGS -> SCARICA CAMPI ITALIA", 180, 185, 14, C_GREY);
        text(c, "oppure FILE .cup dal telefono", 180, 207, 14, C_GREY);
        return true;
    }

    // ---------- NEAREST FIELDS ----------
    private int[] nearestCache = new int[0];

    private void drawNearest(Canvas c) {
        text(c, "NEAREST FIELDS", 180, 40, 22, C_CYAN);
        if (noFields(c)) return;
        if (!d.gpsValid) { text(c, "attesa GPS", 180, 170, 22, C_YELLOW); return; }
        final int[] all = fields.nearest(d.lat, d.lon, 9);
        nearestCache = all;
        final int[] cols = {C_GREEN, C_YELLOW, C_ORANGE};
        for (int k = 0; k < 3; k++) {
            final int i = nearestScroll + k;
            if (i >= all.length) break;
            final Airfields.Field f = fields.get(all[i]);
            final float y = 92 + k * 72;
            final double km = FlightData.distanceKm(d.lat, d.lon, f.lat, f.lon);
            arrow(c, 56, y, relBearing(f.lat, f.lon), C_WHITE);
            textFitLeft(c, f.name, 80, y - 4, 19, C_WHITE, 160);
            text(c, distText(km), 312, y - 4, 19, cols[Math.min(2, i)], Paint.Align.RIGHT);
            textFitLeft(c, fieldSub(f), 80, y + 20, 13, C_GREY, 230);
        }
        button(c, 118, 296, 124, 34, "SEARCH", C_YELLOW, 16);
    }

    private void textFitLeft(Canvas c, String s, float x, float y, float size, int color, float maxW) {
        tp.setTextSize(size);
        final float w = tp.measureText(s);
        if (w > maxW) size *= maxW / w;
        text(c, s, x, y, size, color, Paint.Align.LEFT);
    }

    private void tapNearest(float x, float y) {
        if (in(x, y, 118, 290, 124, 46)) { query = ""; openSub(P_SEARCH); return; }
        for (int k = 0; k < 3; k++) {
            final int i = nearestScroll + k;
            if (i < nearestCache.length && in(x, y, 20, 60 + k * 72, 320, 66)) { setGoto(nearestCache[i]); return; }
        }
    }

    // ---------- SEARCH (tastiera A-Z) ----------
    static final String[] KROWS = {"ABCDEFGH", "IJKLMNO", "PQRSTU", "VWXYZ"};
    private List<Integer> searchCache = new ArrayList<>();

    private void drawSearch(Canvas c) {
        // casella con la lente
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(0xFF1685FF);
        rf.set(48, 36, 238, 74); c.drawRoundRect(rf, 8, 8, p);
        c.drawCircle(70, 53, 7, p);
        line(c, 75, 58, 81, 64, 0xFF1685FF, 3);
        text(c, query + "_", 92, 55, 20, C_WHITE, Paint.Align.LEFT);
        button(c, 248, 36, 64, 38, "DEL", C_ORANGE, 16);
        if (fields.size() == 0) { text(c, "nessun campo caricato", 180, 120, 16, C_YELLOW); }
        else {
            searchCache = query.isEmpty()
                    ? toList(d.gpsValid ? fields.nearest(d.lat, d.lon, 3) : new int[0])
                    : fields.search(query, d.lat, d.lon, d.gpsValid, 3);
            for (int k = 0; k < searchCache.size(); k++) {
                final Airfields.Field f = fields.get(searchCache.get(k));
                final float y = 96 + k * 24;
                if (k == 0) { p.setStyle(Paint.Style.FILL); p.setColor(0xFF16233A); rf.set(44, y - 11, 316, y + 11); c.drawRect(rf, p); }
                textFitLeft(c, f.name, 52, y, 15, C_WHITE, 180);
                if (d.gpsValid) text(c, distText(FlightData.distanceKm(d.lat, d.lon, f.lat, f.lon)), 308, y, 14, C_GREEN, Paint.Align.RIGHT);
            }
        }
        for (int r = 0; r < KROWS.length; r++) {
            final String row = KROWS[r];
            final float w = 36, gap = 4, total = row.length() * w + (row.length() - 1) * gap;
            final float x0 = 180 - total / 2f, y = 176 + r * 38;
            for (int k = 0; k < row.length(); k++) {
                final float x = x0 + k * (w + gap);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF2A2A2A);
                rf.set(x, y, x + w, y + 32); c.drawRoundRect(rf, 6, 6, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(0xFF9A9A9A);
                c.drawRoundRect(rf, 6, 6, p);
                text(c, String.valueOf(row.charAt(k)), x + w / 2f, y + 16, 17, C_WHITE);
            }
        }
    }

    private static List<Integer> toList(int[] a) {
        final List<Integer> l = new ArrayList<>();
        for (int v : a) l.add(v);
        return l;
    }

    private void tapSearch(float x, float y) {
        if (in(x, y, 248, 30, 70, 50)) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); audio.click(900, 30); return; }
        for (int k = 0; k < searchCache.size(); k++) {
            if (in(x, y, 40, 84 + k * 24, 280, 24)) { setGoto(searchCache.get(k)); return; }
        }
        for (int r = 0; r < KROWS.length; r++) {
            final String row = KROWS[r];
            final float w = 36, gap = 4, total = row.length() * w + (row.length() - 1) * gap;
            final float x0 = 180 - total / 2f, ky = 176 + r * 38;
            for (int k = 0; k < row.length(); k++) {
                if (in(x, y, x0 + k * (w + gap) - 2, ky - 3, w + 4, 38) && query.length() < 14) {
                    query += row.charAt(k);
                    audio.click(1300, 25);
                    return;
                }
            }
        }
    }

    // ---------- FIELDS (mappa dei campi, rotta in alto) ----------
    private int fieldsFocus() {
        if (d.gotoField && gotoIdx >= 0 && gotoIdx < fields.size()) return gotoIdx;
        if (!d.gpsValid || fields.size() == 0) return -1;
        final int[] n = fields.nearest(d.lat, d.lon, 1);
        return n.length > 0 ? n[0] : -1;
    }

    private void drawFields(Canvas c) {
        if (noFields(c)) return;
        if (!d.gpsValid) { text(c, "FIELDS", 180, 60, 22, C_CYAN); text(c, "attesa GPS", 180, 170, 22, C_YELLOW); return; }
        final int focus = fieldsFocus();
        // Vista pista come sullo strumento: entro 5 km dalla pista, con la rotta in alto.
        // Si chiude oltre 5,5 km (isteresi) o se la si e' scacciata con uno swipe.
        if (focus >= 0 && !frRwySuppressed) {
            final Airfields.Field f = fields.get(focus);
            final double km = FlightData.distanceKm(d.lat, d.lon, f.lat, f.lon);
            if (km > 5.5) frRwySuppressed = false;   // allontanandosi la vista pista torna disponibile
            if (km <= 5.0 || (frRwyView && km <= 5.5)) {
                frRwyView = true;
                final float course = d.speedKmh > 3 ? (float) d.courseDeg : 0f;
                final float brg = (float) FlightData.bearingDeg(f.lat, f.lon, d.lat, d.lon);
                final float rwyDeg = f.rwyDeg >= 0 ? f.rwyDeg : 0f;
                final int rwy = f.rwyDeg >= 0 ? ((int) Math.round(f.rwyDeg / 10.0) + 35) % 36 + 1 : 0;
                RunwayView.load(getContext().getAssets());
                g.begin(c);
                RunwayView.draw(g, f.name, f.freq, rwy, rwyDeg, f.rwyLenM, course, brg, true);
                return;
            }
            frRwyView = false;
        }
        if (frAuto) {   // zoom automatico: la scala piu' piccola che contiene il campo vicino (o quello del GO TO)
            double km = 30;
            if (focus >= 0) km = FlightData.distanceKm(d.lat, d.lon, fields.get(focus).lat, fields.get(focus).lon);
            int idx = 0;
            for (int i = 0; i < FR_KM.length; i++) if (FR_KM[i] >= km * 1.25) idx = i;
            frIdx = idx;
        }
        final float R = FR_KM[frIdx];
        final float k = 150f / R;
        final double crs = Math.toRadians(d.speedKmh > 3 ? d.courseDeg : 0);
        final double cosLat = Math.cos(Math.toRadians(d.lat));
        // cerchi della distanza e punti cardinali che girano con la rotta
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(0xFF4A5A6A);
        c.drawCircle(180, 180, 75, p);
        c.drawCircle(180, 180, 150, p);
        final String[] card = {"N", "E", "S", "W"};
        for (int i = 0; i < 4; i++) {
            final float a = (float) (i * 90 - Math.toDegrees(crs));
            text(c, card[i], px(164, a), py(164, a), 17, i == 0 ? C_RED : C_WHITE);
        }
        text(c, (R == Math.round(R) ? String.valueOf((int) R) : String.valueOf(R)) + " km", 180 + 78, 180 + 8, 11, C_GREY, Paint.Align.LEFT);
        // CTR (dal file degli spazi aerei): rosa con bordo blu tratteggiato, come sullo strumento
        if (airspaces != null) {
            for (Airspaces.Area a : airspaces.ctrNear(d.lat, d.lon, R * 1.3)) {
                path.reset();
                for (int i = 0; i < a.lat.length; i++) {
                    final float[] q = project(a.lat[i], a.lon[i], cosLat, crs, k);
                    if (i == 0) path.moveTo(q[0], q[1]); else path.lineTo(q[0], q[1]);
                }
                path.close();
                p.setStyle(Paint.Style.FILL); p.setColor(0x55F3CDD0);
                c.drawPath(path, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(0xFF5B8BDA);
                p.setPathEffect(new android.graphics.DashPathEffect(new float[]{10, 6}, 0));
                c.drawPath(path, p);
                p.setPathEffect(null);
            }
        }
        // linea rossa verso il campo del GO TO
        float gx = 0, gy = 0;
        boolean haveGoto = false;
        if (d.gotoField) {
            final float[] g = project(d.gotoLat, d.gotoLon, cosLat, crs, k);
            gx = g[0]; gy = g[1]; haveGoto = true;
            line(c, 180, 180, gx, gy, C_RED, 3);
        }
        // home (casetta verde)
        if (d.homeSet) {
            final float[] h = project(d.homeLat, d.homeLon, cosLat, crs, k);
            path.reset();
            path.moveTo(h[0], h[1] - 11); path.lineTo(h[0] + 10, h[1] - 2); path.lineTo(h[0] + 7, h[1] - 2);
            path.lineTo(h[0] + 7, h[1] + 9); path.lineTo(h[0] - 7, h[1] + 9); path.lineTo(h[0] - 7, h[1] - 2);
            path.lineTo(h[0] - 10, h[1] - 2); path.close();
            p.setStyle(Paint.Style.FILL); p.setColor(C_GREEN);
            c.drawPath(path, p);
        }
        // campi
        for (int fi : fields.within(d.lat, d.lon, R * 1.2)) {
            final Airfields.Field f = fields.get(fi);
            final float[] q = project(f.lat, f.lon, cosLat, crs, k);
            if (Math.hypot(q[0] - 180, q[1] - 180) > 175) continue;
            final boolean big = fi == focus;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(0xFF2F6DB5);
            c.drawCircle(q[0], q[1], big ? 9 : 7, p);
            if (f.rwyDeg >= 0) {
                final double a = Math.toRadians(f.rwyDeg) - crs;
                final float L = big ? 15 : 11;
                line(c, q[0] - L * (float) Math.sin(a), q[1] + L * (float) Math.cos(a),
                        q[0] + L * (float) Math.sin(a), q[1] - L * (float) Math.cos(a), 0xFF2F6DB5, big ? 4 : 3);
            }
            p.setStyle(Paint.Style.FILL); p.setColor(C_ORANGE);
            c.drawCircle(q[0], q[1], 3.5f, p);
            final String[] nm = splitName(f.name);
            final float tx = q[0] + 14;
            text(c, nm[0], tx, q[1] - (nm[1].isEmpty() ? 0 : 8), big ? 16 : 13, C_WHITE, Paint.Align.LEFT);
            if (!nm[1].isEmpty()) text(c, nm[1], tx, q[1] + 9, big ? 16 : 13, C_WHITE, Paint.Align.LEFT);
        }
        drawPlane(c, 180, 180, 0.42f, C_YELLOW);
        text(c, "FIELDS " + (R == Math.round(R) ? String.valueOf((int) R) : String.valueOf(R)) + " km" + (frAuto ? " AUTO" : ""), 180, 36, 15, C_WHITE);
        // riquadro in basso: distanza del GO TO, altrimenti campo piu' vicino
        p.setStyle(Paint.Style.FILL); p.setColor(0xEE101010);
        rf.set(95, 290, 265, 336); c.drawRoundRect(rf, 8, 8, p);
        if (haveGoto) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(C_ORANGE);
            c.drawRoundRect(rf, 8, 8, p);
            text(c, distText(FlightData.distanceKm(d.lat, d.lon, d.gotoLat, d.gotoLon)), 180, 313, 24, C_ORANGE);
        } else if (focus >= 0) {
            final Airfields.Field f = fields.get(focus);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f); p.setColor(C_GREEN);
            c.drawRoundRect(rf, 8, 8, p);
            textFit(c, f.name, 180, 304, 13, C_GREEN, 160);
            text(c, distText(FlightData.distanceKm(d.lat, d.lon, f.lat, f.lon)) + String.format(Locale.ROOT, "  %03d°",
                    Math.round(FlightData.bearingDeg(d.lat, d.lon, f.lat, f.lon)) % 360), 180, 322, 13, C_WHITE);
        }
    }

    private float[] project(double lat, double lon, double cosLat, double crs, float k) {
        final double e = (lon - d.lon) * 111.32 * cosLat, n = (lat - d.lat) * 110.57;
        final double xr = e * Math.cos(crs) - n * Math.sin(crs);
        final double yr = e * Math.sin(crs) + n * Math.cos(crs);
        return new float[]{(float) (180 + xr * k), (float) (180 - yr * k)};
    }

    /** Testo lungo su due righe, spezzato a uno spazio. */
    private static String[] splitLong(String n, int max) {
        if (n.length() <= max) return new String[]{n, ""};
        int cut = max;
        for (int i = max; i > 6; i--) if (n.charAt(i) == ' ') { cut = i; break; }
        final String r = n.substring(cut).trim();
        return new String[]{n.substring(0, cut).trim(), r.length() > max ? r.substring(0, max) : r};
    }

    /** Nome su due righe ("MILANO" / "LINATE") quando ci sono due parole. */
    private static String[] splitName(String n) {
        n = n.trim();
        int cut = -1;
        for (int i = 1; i < n.length() - 1; i++) {
            final char ch = n.charAt(i);
            if (ch == ' ' || ch == '-' || ch == '_' || ch == '/') { cut = i; break; }
        }
        if (cut < 0) return new String[]{n, ""};
        return new String[]{n.substring(0, cut).trim(), n.substring(cut + 1).trim()};
    }

    // ---------- FIELD INFO ----------
    private void drawFieldInfo(Canvas c) {
        if (infoField < 0 || infoField >= fields.size()) { page = returnPage; return; }
        final Airfields.Field f = fields.get(infoField);
        final String[] nm = splitName(f.name);
        if (nm[1].isEmpty()) textFit(c, nm[0], 180, 70, 32, C_WHITE, 280);
        else { textFit(c, nm[0], 180, 52, 30, C_WHITE, 270); textFit(c, nm[1], 180, 86, 30, C_WHITE, 290); }
        text(c, f.freq.isEmpty() ? "-" : f.freq, 180, 120, 26, C_CYAN);
        line(c, 60, 142, 300, 142, C_ORANGE, 2);
        final String dist = d.gpsValid ? distText(FlightData.distanceKm(d.lat, d.lon, f.lat, f.lon)) : "--";
        String eta = "--";
        if (d.gpsValid && d.speedKmh > 10) {
            final double km = FlightData.distanceKm(d.lat, d.lon, f.lat, f.lon);
            eta = Math.round(km / d.speedKmh * 60.0) + " min";
        }
        final String[] lab = {"RWY", "LENGTH", "DIST", "ETA"};
        final String[] val = {f.rwyText().isEmpty() ? "-" : f.rwyText(), f.rwyLenM > 0 ? f.rwyLenM + " m" : "-", dist, eta};
        for (int i = 0; i < 4; i++) {
            final float y = 174 + i * 36;
            text(c, lab[i], 150, y, 18, C_GREY, Paint.Align.RIGHT);
            text(c, val[i], 164, y, 26, C_WHITE, Paint.Align.LEFT);
        }
        text(c, "Tap to exit", 180, 330, 13, C_GREY);
    }





    // ---------- FUEL SETUP ----------
    static final String[] FS_LAB = {"A BORDO (l)", "SERBATOIO (l)", "CONSUMO (l/h)", "RISERVA (min)", "A TERRA (l)"};

    private String fsValue(int i) {
        switch (i) {
            case 0: return String.valueOf(Math.round(d.fuelLiters));
            case 1: return String.valueOf(d.fuelTankL);
            case 2: return String.format(Locale.ROOT, "%.1f", d.fuelRateLph);
            case 3: return String.valueOf(d.fuelReserveMin);
            default: return String.format(Locale.ROOT, "%.1f", d.fuelGroundL);
        }
    }

    private void drawFuelSetup(Canvas c) {
        text(c, "FUEL SETUP", 180, 36, 20, C_CYAN);
        for (int i = 0; i < FS_LAB.length; i++) {
            final float y = 76 + i * 40;
            text(c, FS_LAB[i], 34, y, 14, C_WHITE, Paint.Align.LEFT);
            button(c, 186, y - 16, 40, 32, "−", C_WHITE, 20);
            text(c, fsValue(i), 263, y, 18, C_YELLOW);
            button(c, 300, y - 16, 40, 32, "+", C_WHITE, 20);
        }
        button(c, 120, 284, 120, 42, "SAVE", C_GREEN, 18);
    }

    private void tapFuelSetup(float x, float y) {
        for (int i = 0; i < FS_LAB.length; i++) {
            final float yy = 76 + i * 40;
            final int dir = in(x, y, 180, yy - 20, 52, 40) ? -1 : (in(x, y, 294, yy - 20, 52, 40) ? 1 : 0);
            if (dir == 0) continue;
            switch (i) {
                case 0: d.fuelLiters = Math.max(0f, Math.min(d.fuelTankL, Math.round(d.fuelLiters) + dir)); break;
                case 1: d.fuelTankL = Math.max(5, Math.min(300, d.fuelTankL + dir * 5)); d.fuelLiters = Math.min(d.fuelLiters, d.fuelTankL); break;
                case 2: d.fuelRateLph = Math.max(1f, Math.min(80f, d.fuelRateLph + dir * 0.5f)); break;
                case 3: d.fuelReserveMin = Math.max(0, Math.min(90, d.fuelReserveMin + dir * 5)); break;
                default: d.fuelGroundL = Math.max(0f, Math.min(10f, d.fuelGroundL + dir * 0.5f)); break;
            }
            d.fuelReserveAlerted = false;
            audio.click(dir > 0 ? 1400 : 1000, 25);
            return;
        }
        if (in(x, y, 120, 284, 120, 42)) { saver.run(); page = returnPage; audio.click(1500, 80); }
    }

    // ---------- PAGES ----------
    private static String shortName(int i) {
        return NAMES[i].replace("AUTOMATIC FLIGHT TIMER", "AUTO TIMER").replace("MANUAL FLIGHT TIMER", "MANUAL TIMER")
                .replace("NEAREST FIELDS", "NEAREST").replace("FUEL ESTIMATE", "FUEL").replace("GO TO HOME", "GO HOME")
                .replace("METEO", "AIR DATA");
    }
    /** Casella con la spunta, come le righe di PAGES 2/3 del firmware. */
    private void pageBox(Canvas c, int x, int y, boolean on, String label, int onColor) {
        final int col = on ? onColor : C_GREY;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f); p.setColor(col);
        rf.set(x, y + 4, x + 22, y + 26); c.drawRoundRect(rf, 4, 4, p);
        rf.set(x + 1, y + 5, x + 21, y + 25); c.drawRoundRect(rf, 3, 3, p);
        if (on) { p.setStyle(Paint.Style.FILL); rf.set(x + 5, y + 9, x + 17, y + 21); c.drawRoundRect(rf, 2, 2, p); }
        g.begin(c);
        g.ui(label, x + 28, y + 15, G.ML, on ? C_WHITE : C_GREY, 0.5f);
    }

    private void drawPages(Canvas c) {
        g.begin(c);
        g.ui(pagesSub == 0 ? "PAGES 1/3" : (pagesSub == 1 ? "PAGES 2/3" : "PAGES 3/3"), 180, 34, G.MC, C_CYAN, 0.62f);
        if (pagesSub == 1) { drawPages2(c); return; }
        if (pagesSub == 2) { drawPages3(c); return; }
        for (int i = 0; i <= CYCLE - 1; i++) {        // 15 pagine + LUBBER LINE (ultima casella)
            final float x = i < 8 ? 26 : 186, y = 50 + (i % 8) * 31;
            final boolean lub = i == CYCLE - 1;
            final boolean on = lub ? d.lubberEdit : pageOn(i);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f); p.setColor(on ? (lub ? C_YELLOW : C_GREEN) : C_GREY);
            rf.set(x, y, x + 20, y + 20); c.drawRoundRect(rf, 3, 3, p);
            if (on) { p.setStyle(Paint.Style.FILL); rf.set(x + 5, y + 5, x + 15, y + 15); c.drawRoundRect(rf, 2, 2, p); }
            textFitLeft(c, lub ? "LUBBER LINE" : shortName(i), x + 27, y + 10, 13, on ? C_WHITE : C_GREY, 124);
        }
        {   // GS 150: fondo scala GS da 0-150 km/h (resta 0-200 se il rosso e' oltre 150)
            final boolean on = d.gs150;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f); p.setColor(on ? C_GREEN : C_GREY);
            rf.set(125, 298, 145, 318); c.drawRoundRect(rf, 3, 3, p);
            if (on) { p.setStyle(Paint.Style.FILL); rf.set(130, 303, 140, 313); c.drawRoundRect(rf, 2, 2, p); }
            textFitLeft(c, "GS 150", 152, 308, 13, on ? C_WHITE : C_GREY, 124);
        }
        text(c, "Swipe to exit", 180, 336, 13, C_WHITE);
    }

    // ---------- PAGES 2/3 e 3/3, stessa disposizione del firmware ----------
    private static final int SEL2_X = 62, SEL2_Y0 = 62, SEL2_ROW_H = 32;
    private static final int SEL2_CTR_X = 170, SEL2_SET_X = 262, SEL2_GS150_X = 222;
    private static final int SLIP_Y = 62, NOALERT_Y = 92;
    /** Le cinque pagine che il firmware mostra in PAGES 2/3, nell'ordine. */
    private static final String[] P2 = {"MANUAL FLIGHT TIMER", "ROTATE DISPLAY 180", "FUEL ESTIMATE", "NEAREST FIELDS", "FIELDS"};

    private int p2PageIndex(int k) {
        final String n = P2[k];
        if (n.equals("ROTATE DISPLAY 180")) return -1;   // non e' una pagina: e' l'impostazione
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(n)) return i;
        return -1;
    }

    private void drawPages2(Canvas c) {
        for (int k = 0; k < P2.length; k++) {
            final int y = SEL2_Y0 + k * SEL2_ROW_H;
            if (P2[k].equals("ROTATE DISPLAY 180")) {
                pageBox(c, SEL2_X, y, d.rotate180, "ROTATE DISPLAY 180", C_GREEN);
                final float w = g.textWidth("ROTATE DISPLAY 180");
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f); p.setColor(d.rotate180 ? C_WHITE : C_GREY);
                c.drawCircle(SEL2_X + 28 + w + 5, y + 7, 3, p);   // simbolo dei gradi
                continue;
            }
            final int i = p2PageIndex(k);
            final boolean on = i >= 0 && pageOn(i);
            pageBox(c, SEL2_X, y, on, P2[k].equals("FIELDS") ? "FIELDS 30 KM" : P2[k], C_GREEN);
            if (P2[k].equals("FUEL ESTIMATE")) {           // SET: impostazioni carburante
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f); p.setColor(C_ORANGE);
                rf.set(SEL2_SET_X, y + 2, SEL2_SET_X + 56, y + 30); c.drawRoundRect(rf, 6, 6, p);
                g.begin(c); g.ui("SET", SEL2_SET_X + 28, y + 16, G.MC, C_ORANGE, 0.5f);
            }
        }
        final int yV = SEL2_Y0 + 5 * SEL2_ROW_H;
        pageBox(c, SEL2_X, yV, !d.vertSwipeOff, "COMPASS VERTICAL SWIPE", C_GREEN);
        final int yA = SEL2_Y0 + 6 * SEL2_ROW_H;
        pageBox(c, SEL2_X, yA, d.arcBlock, "ARCH BLOCK", C_GREEN);
        pageBox(c, SEL2_GS150_X, yA, d.gs150, "GS 150", C_GREEN);
        final int yI = SEL2_Y0 + 7 * SEL2_ROW_H;
        final int ict = indexOfName("ICT");
        pageBox(c, SEL2_X, yI, ict >= 0 && pageOn(ict), "ICT", C_GREEN);
        pageBox(c, SEL2_CTR_X, yI, d.onlyCtr, "ONLY CTR", C_GREEN);
        g.begin(c); g.ui("Swipe to exit", 180, 340, G.MC, C_WHITE, 0.5f);
    }

    private void drawPages3(Canvas c) {
        pageBox(c, SEL2_X, NOALERT_Y, d.alertsMuted, "DON'T SHOW ALERTS", C_GREEN);
        g.begin(c);
        // Sullo strumento qui ci sono anche TURN & SLIP e HARD RESET: il primo ha bisogno
        // del sensore a bordo, il secondo cancella il codice di attivazione del dispositivo.
        g.ui("TURN & SLIP e HARD RESET", 180, 190, G.MC, C_GREY, 0.45f);
        g.ui("solo sullo strumento", 180, 214, G.MC, C_GREY, 0.45f);
        g.ui("Swipe to exit", 180, 340, G.MC, C_WHITE, 0.5f);
    }

    private int indexOfName(String n) {
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(n)) return i;
        return -1;
    }

    private void tapPages2(float x, float y) {
        for (int k = 0; k < P2.length; k++) {
            final int ry = SEL2_Y0 + k * SEL2_ROW_H;
            if (P2[k].equals("FUEL ESTIMATE") && in(x, y, SEL2_SET_X - 6, ry, 68, 32)) { openSub(P_FUELSET); return; }
            if (!in(x, y, SEL2_X - 12, ry, 180, SEL2_ROW_H)) continue;
            if (P2[k].equals("ROTATE DISPLAY 180")) { d.rotate180 = !d.rotate180; }
            else { final int i = p2PageIndex(k); if (i >= 0) d.pagesMask ^= (1L << i); }
            saver.run(); audio.click(1200, 40); return;
        }
        final int yV = SEL2_Y0 + 5 * SEL2_ROW_H;
        if (in(x, y, SEL2_X - 12, yV, 260, SEL2_ROW_H)) { d.vertSwipeOff = !d.vertSwipeOff; saver.run(); audio.click(1200, 40); return; }
        final int yA = SEL2_Y0 + 6 * SEL2_ROW_H;
        if (in(x, y, SEL2_GS150_X - 10, yA, 130, SEL2_ROW_H)) { d.gs150 = !d.gs150; FlightPages.gsRangeIdx = 0; saver.run(); audio.click(1200, 40); return; }
        if (in(x, y, SEL2_X - 12, yA, 150, SEL2_ROW_H)) { d.arcBlock = !d.arcBlock; saver.run(); audio.click(1200, 40); return; }
        final int yI = SEL2_Y0 + 7 * SEL2_ROW_H;
        if (in(x, y, SEL2_CTR_X - 10, yI, 150, SEL2_ROW_H)) { d.onlyCtr = !d.onlyCtr; saver.run(); audio.click(1200, 40); return; }
        if (in(x, y, SEL2_X - 12, yI, 140, SEL2_ROW_H)) { final int i = indexOfName("ICT"); if (i >= 0) { d.pagesMask ^= (1L << i); saver.run(); audio.click(1200, 40); } }
    }

    private void tapPages3(float x, float y) {
        if (in(x, y, SEL2_X - 12, NOALERT_Y, 280, SEL2_ROW_H)) { d.alertsMuted = !d.alertsMuted; saver.run(); audio.click(1200, 40); }
    }

    private void tapPages(float x, float y) {
        if (in(x, y, 110, 14, 140, 40)) {   // clic sul titolo: si passa alla sottopagina successiva
            pagesSub = (pagesSub + 1) % 3;
            audio.click(1200, 40);
            return;
        }
        if (pagesSub == 1) { tapPages2(x, y); return; }
        if (pagesSub == 2) { tapPages3(x, y); return; }
        for (int i = 0; i <= CYCLE - 1; i++) {
            final float bx = i < 8 ? 20 : 180, by = 47 + (i % 8) * 31;
            if (in(x, y, bx, by, 160, 30)) {
                if (i == CYCLE - 1) d.lubberEdit = !d.lubberEdit;
                else d.pagesMask ^= (1L << i);
                saver.run();
                audio.click(1200, 40);
                return;
            }
        }
        if (in(x, y, 110, 293, 140, 30)) { d.gs150 = !d.gs150; FlightPages.gsRangeIdx = 0; saver.run(); audio.click(1200, 40); }
    }

    // ---------- LOW GS e avvisi a tutto schermo ----------
    private void drawLowGs(Canvas c) {
        if (!d.lowGsActive || alert != A_NONE) return;
        if ((SystemClock.uptimeMillis() / 500) % 2 == 0) {
            p.setStyle(Paint.Style.FILL); p.setColor(C_RED);
            rf.set(110, 300, 250, 336); c.drawRoundRect(rf, 8, 8, p);
            text(c, "LOW GS", 180, 318, 22, C_WHITE);
        }
    }

    private void drawAlert(Canvas c) {
        if (alert == A_NONE) return;
        if (SystemClock.uptimeMillis() > alertUntil) { alert = A_NONE; return; }
        p.setStyle(Paint.Style.FILL);
        switch (alert) {
            case A_ICT:
                MiscPages.ictAlert(g);
                break;
            case A_RESERVE:
                MiscPages.fuel(g, d, true);
                break;
            case A_AIRSPACE: {
                if (aspHit == null) break;
                final Airspaces.Area a = aspHit.area;
                final boolean inside = aspHit.level >= 2;
                final int bg = inside ? 0xFFFF0000 : 0xFFFF8C00, fg = inside ? C_WHITE : Color.BLACK;
                p.setColor(bg); c.drawCircle(180, 180, 180, p);
                text(c, "AIRSPACE", 180, 58, 30, fg);
                final String tl = (a.cls.isEmpty() || a.cls.equals(a.type) || a.cls.equals("UNC")) ? a.type : a.type + "  class " + a.cls;
                textFit(c, tl, 180, 104, 24, fg, 280);
                final String[] nm = splitLong(a.name, 18);
                textFit(c, nm[0], 180, 146, 21, fg, 290);
                if (!nm[1].isEmpty()) textFit(c, nm[1], 180, 174, 21, fg, 290);
                textFit(c, Airspaces.fmtLimit(a.lowFt, a.lowRef) + " - " + Airspaces.fmtLimit(a.highFt, a.highRef), 180, 214, 18, fg, 290);
                final String st = inside ? "INSIDE" : (aspHit.vert < 0 && aspHit.distM == 0 ? "BELOW FLOOR"
                        : (aspHit.vert > 0 && aspHit.distM == 0 ? "ABOVE TOP" : String.format(Locale.ROOT, "%.1f km", aspHit.distM / 1000f)));
                text(c, st, 180, 266, 30, fg);
                break;
            }
            case A_SUNSET:
                p.setColor(0xFF1A1030); c.drawCircle(180, 180, 180, p);
                p.setColor(0xFFE0502A); c.drawCircle(180, 205, 46, p);
                p.setColor(0xFF1A1030); rf.set(0, 205, 360, 360); c.drawRect(rf, p);
                line(c, 60, 205, 300, 205, 0xFFFF8E00, 3);
                text(c, "SUNSET", 180, 110, 32, C_ORANGE);
                text(c, alertText, 180, 250, 32, C_WHITE);
                break;
            default: break;
        }
    }
}
