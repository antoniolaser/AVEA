package it.avea.app;

import android.content.res.AssetManager;
import android.graphics.Bitmap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Carattere Adafruit GFX (FreeSansBold 9/12/18/24 pt), gli stessi file che usa LovyanGFX
 * nel firmware. I glifi sono a 1 bit, senza sfumatura, esattamente come sul display.
 *
 * Formato del file .gfx (generato dagli header della libreria):
 *   "GFXF" | first u16 | last u16 | yAdvance u16 | numero glifi u16
 *   per glifo: offset u32, larghezza u8, altezza u8, avanzamento u8, dX i8, dY i8
 *   poi i bitmap a 1 bit impacchettati per riga, uno dopo l'altro
 */
public class GfxFont {

    private final int first, last, yAdvance;
    private final int[] off, w, h, adv, dX, dY;
    private final byte[] bits;
    private final int bitsStart;
    private final Bitmap[] cache;

    private GfxFont(byte[] b) {
        first = u16(b, 4); last = u16(b, 6); yAdvance = u16(b, 8);
        final int n = u16(b, 10);
        off = new int[n]; w = new int[n]; h = new int[n]; adv = new int[n]; dX = new int[n]; dY = new int[n];
        int p = 12;
        for (int i = 0; i < n; i++) {
            off[i] = ((b[p] & 0xFF) << 24) | ((b[p + 1] & 0xFF) << 16) | ((b[p + 2] & 0xFF) << 8) | (b[p + 3] & 0xFF);
            w[i] = b[p + 4] & 0xFF; h[i] = b[p + 5] & 0xFF; adv[i] = b[p + 6] & 0xFF;
            dX[i] = b[p + 7]; dY[i] = b[p + 8];
            p += 9;
        }
        bitsStart = p;
        bits = b;
        cache = new Bitmap[n];
    }

    private static int u16(byte[] b, int p) { return ((b[p] & 0xFF) << 8) | (b[p + 1] & 0xFF); }

    public static GfxFont fromAsset(AssetManager am, String name) {
        try {
            final InputStream in = am.open("fonts/" + name);
            final ByteArrayOutputStream bo = new ByteArrayOutputStream(16 * 1024);
            final byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            in.close();
            final byte[] b = bo.toByteArray();
            if (b.length < 12 || b[0] != 'G' || b[1] != 'F' || b[2] != 'X' || b[3] != 'F') return null;
            return new GfxFont(b);
        } catch (IOException e) {
            return null;
        }
    }

    private int idx(char ch) { return (ch < first || ch > last) ? -1 : (ch - first); }

    /** Larghezza del testo alla scala 1, come textWidth() di LovyanGFX con un font GFX. */
    public float width(String s) {
        float x = 0;
        for (int i = 0; i < s.length(); i++) { final int g = idx(s.charAt(i)); if (g >= 0) x += adv[g]; }
        return x;
    }

    public int height() { return yAdvance; }
    /** Altezza delle maiuscole: serve a centrare come fa il firmware. */
    public int capHeight() { final int g = idx('H'); return g >= 0 ? h[g] : yAdvance / 2; }

    private Bitmap glyph(int g) {
        if (cache[g] == null && w[g] > 0 && h[g] > 0) {
            final Bitmap bm = Bitmap.createBitmap(w[g], h[g], Bitmap.Config.ALPHA_8);
            final byte[] a = new byte[w[g] * h[g]];
            int bit = off[g] * 8;
            for (int y = 0; y < h[g]; y++)
                for (int x = 0; x < w[g]; x++) {
                    final int byteIdx = bitsStart + (bit >> 3);
                    final boolean on = byteIdx < bits.length && (bits[byteIdx] & (0x80 >> (bit & 7))) != 0;
                    a[y * w[g] + x] = on ? (byte) 0xFF : 0;
                    bit++;
                }
            bm.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(a));
            cache[g] = bm;
        }
        return cache[g];
    }

    /** Scrive con la linea di base a baseY e il bordo sinistro a leftX. */
    public void draw(android.graphics.Canvas c, String s, float leftX, float baseY, float sx, float sy, android.graphics.Paint p) {
        float x = leftX;
        final android.graphics.Rect src = new android.graphics.Rect();
        final android.graphics.RectF dst = new android.graphics.RectF();
        for (int i = 0; i < s.length(); i++) {
            final int g = idx(s.charAt(i));
            if (g < 0) continue;
            final Bitmap bm = glyph(g);
            if (bm != null) {
                src.set(0, 0, w[g], h[g]);
                final float gx = x + dX[g] * sx, gy = baseY + dY[g] * sy;
                dst.set(gx, gy, gx + w[g] * sx, gy + h[g] * sy);
                c.drawBitmap(bm, src, dst, p);
            }
            x += adv[g] * sx;
        }
    }
}
