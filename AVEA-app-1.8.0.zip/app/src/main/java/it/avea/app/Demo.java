package it.avea.app;

/**
 * Simulazione di un volo (DEMO): rullaggio, decollo, salita, un giro largo con termiche,
 * discesa, atterraggio e sosta. Poi ricomincia. Genera posizione, velocita' e pressione,
 * cosi' filtro, variometro, timer e log lavorano come in volo.
 */
public class Demo {
    private final double lat0, lon0;
    private final float fieldM = 110f;
    private double lat, lon;
    private float courseDeg = 0f, speedKmh = 0f, altM = 110f;
    private double t = 0;

    public Demo(double startLat, double startLon) {
        lat0 = startLat; lon0 = startLon;
        lat = lat0; lon = lon0;
        altM = fieldM;
    }

    public static final double CYCLE_S = 420;   // durata di un ciclo completo

    /** Avanza di dt secondi. */
    public void step(double dt) {
        t += dt;
        if (t >= CYCLE_S) { t = 0; lat = lat0; lon = lon0; courseDeg = 0; altM = fieldM; }
        float targetKmh;
        float vz;            // m/s
        float turnDegS = 0;
        if (t < 10) {                       // fermo
            targetKmh = 0; vz = 0;
        } else if (t < 30) {                // rullaggio e corsa di decollo
            targetKmh = (float) ((t - 10) / 20 * 95); vz = 0;
        } else if (t < 120) {               // salita
            targetKmh = 110; vz = 3.0f;
        } else if (t < 300) {               // giro largo con termiche e discendenze
            targetKmh = (float) (120 + 70 * Math.sin((t - 120) / 180 * Math.PI)); // fino a ~190 km/h
            vz = (float) (2.5 * Math.sin((t - 120) / 9.0) + 1.2 * Math.sin((t - 120) / 3.7));
            turnDegS = 2.0f;
        } else if (t < 370) {               // discesa verso il campo
            targetKmh = 100; vz = -4.5f; turnDegS = 1.0f;
            if (t > 345 && t < 352) vz = -6.0f;   // breve discesa forte: allarme
        } else if (t < 390) {               // atterraggio e frenata
            targetKmh = (float) Math.max(0, 80 - (t - 370) * 5); vz = 0;
            altM = fieldM;
        } else {                            // fermo a terra
            targetKmh = 0; vz = 0; altM = fieldM;
        }
        speedKmh += (targetKmh - speedKmh) * (float) Math.min(1.0, dt * 0.8);
        altM = Math.max(fieldM, altM + vz * (float) dt);
        courseDeg = (courseDeg + turnDegS * (float) dt + 360f) % 360f;
        final double distM = speedKmh / 3.6 * dt;
        final double br = Math.toRadians(courseDeg);
        lat += distM * Math.cos(br) / 111320.0;
        lon += distM * Math.sin(br) / (111320.0 * Math.cos(Math.toRadians(lat)));
    }

    public double lat() { return lat; }
    public double lon() { return lon; }
    public float speedKmh() { return speedKmh; }
    public float courseDeg() { return courseDeg; }
    public float altM() { return altM; }

    /** Pressione che corrisponde alla quota simulata, con un po' di rumore come un barometro vero. */
    public float pressureHpa(float qnh) {
        final float noise = (float) ((Math.random() - 0.5) * 0.04);   // circa +-0.17 m
        return FlightData.altitudeToPressure(altM, qnh) + noise;
    }
}
