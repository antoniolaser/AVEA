# AVEA app

App Android che ripete sul telefono le pagine dello strumento AVEA.

## Come si crea l'APK con GitHub

1. Crea un repository (consigliato **privato**) e carica questo progetto, oppure carica direttamente il file `progetto.zip` nella pagina principale: il workflow lo scompatta da solo.
2. Vai in **Actions** e lancia *Crea APK* (parte anche da sola a ogni push su `main`).
3. A fine compilazione trovi `AVEA.apk` sia negli **Artifacts** della run sia nella pagina **Releases**, da cui si scarica direttamente dal telefono.

## Chiave di firma: i quattro Secrets

La chiave **non sta nel repository**, e non deve starci mai: chi la ottiene può firmare un APK qualsiasi e farlo installare come se fosse un aggiornamento ufficiale di AVEA.

Il file `avea.jks` va tenuto da parte, al sicuro e con una copia di scorta: se lo perdi, gli APK nuovi non si installeranno più sopra quelli già sui telefoni, e chi ha l'app dovrà disinstallarla e reinstallarla.

In *Settings → Secrets and variables → Actions* del repository crea questi quattro Secrets:

| Secret | Contenuto |
|---|---|
| `AVEA_KEYSTORE_BASE64` | il file `avea.jks` convertito in base64 |
| `AVEA_STORE_PASSWORD` | password del keystore |
| `AVEA_KEY_ALIAS` | alias della chiave (`avea`) |
| `AVEA_KEY_PASSWORD` | password della chiave |

Per ottenere il base64 della chiave:

```
base64 -w0 avea.jks > avea.b64      # Linux
certutil -encode avea.jks avea.b64  # Windows
```

e incolla il contenuto del file nel Secret.

Senza i Secrets la compilazione funziona lo stesso, ma l'APK esce firmato con la chiave di debug: va bene per provare, non per aggiornare un'installazione esistente.

### Compilare in locale

Metti accanto a `settings.gradle` un file `keystore.properties` (è già nel `.gitignore`):

```
storeFile=/percorso/di/avea.jks
storePassword=...
keyAlias=avea
keyPassword=...
```

## Caratteri e immagini

In `app/src/main/assets` ci sono i **caratteri veri dello strumento**, estratti dagli header Arduino, non delle imitazioni con i font di sistema:

- `UiFont32.vlw`, `UiFont24.vlw`, `VarioNumbers80.vlw`, `ClockFont60/48/22.vlw` — formato VLW, letti da `VlwFont.java`
- `FreeSansBold9/12/18/24pt7b.gfx` — i font Adafruit GFX di LovyanGFX, letti da `GfxFont.java`
- `img/logo.png`, `img/airplane.png`, `img/vis*.png` — logo, sagoma dell'aereo e icone di visibilità

È questo che rende le scritte identiche a quelle del display: cambiando i glifi cambiano larghezze e posizioni di ogni etichetta.
